<?php
/**
 * Banner Three Widget
 */

namespace Elementor;
class Gunter_Banner_Three extends Widget_Base {

	public function get_name() {
        return 'Gunter_Banner_Three';
    }

	public function get_title() {
        return __( 'Banner Three', 'gunter-toolkit' );
    }

	public function get_icon() {
        return 'eicon-banner';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'Gunter_Banner_Three_Area',
			[
				'label' => __( 'Gunter Banner Controls', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

            $this->add_control(
                'version',
                [
                    'label' => __( 'Choose Version', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'light'         => __( 'Light', 'gunter-toolkit' ),
                        'dark'          => __( 'Dark', 'gunter-toolkit' ),
                    ],
                    'default' => 'dark',
                ]
            );

            $this->add_control(
                'title',
                [
                    'label' => __( 'Title', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('We Provide Best SEO Services', 'gunter-toolkit'),
                ]
            );

            $this->add_control(
                'desc',
                [
                    'label' => __( 'Content', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => __('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Risus commodo viverra maecenas accumsan lacus vel facilisis.', 'gunter-toolkit'),
                ]
            );

            $this->add_control(
                'image',
                [
                    'label' => __( 'Choose Banner Image', 'gunter-toolkit' ),
                    'type' => Controls_Manager::MEDIA,
                ]
            );

            $this->add_control(
                'button_text',
                [
                    'label' => __( 'Button Text', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Get Started', 'gunter-toolkit'),
                ]
            );

            $this->add_control(
                'link_type',
                [
                    'label' => esc_html__( 'Link Type', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'label_block' => true,
                    'options' => [
                        '1'  => esc_html__( 'Link To Page', 'gunter-toolkit' ),
                        '2' => esc_html__( 'External Link', 'gunter-toolkit' ),
                    ],
                ]
            );

            $this->add_control(
                'link_to_page',
                [
                    'label' => esc_html__( 'Link Page', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'label_block' => true,
                    'options' => gunter_toolkit_pages_list_el(),
                    'condition' => [
                        'link_type' => '1',
                    ],
                ]
            );

            $this->add_control(
                'ex_link',
                [
                    'label'=>esc_html__('External Link', 'gunter-toolkit'),
                    'type'=>Controls_Manager:: URL,
                    'condition' => [
                        'link_type' => '2',
                    ],
                ]
            );

            $this->add_control(
                'right_button_text',
                [
                    'label' => __( 'Right Button Text', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('About Us', 'gunter-toolkit'),
                ]
            );

            $this->add_control(
                'right_link_type',
                [
                    'label' => esc_html__( 'Link Type', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'label_block' => true,
                    'options' => [
                        '1'  => esc_html__( 'Link To Page', 'gunter-toolkit' ),
                        '2' => esc_html__( 'External Link', 'gunter-toolkit' ),
                    ],
                ]
            );

            $this->add_control(
                'right_link_to_page',
                [
                    'label' => esc_html__( 'Link Page', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'label_block' => true,
                    'options' => gunter_toolkit_pages_list_el(),
                    'condition' => [
                        'link_type' => '1',
                    ],
                ]
            );

            $this->add_control(
                'right_ex_link',
                [
                    'label'=>esc_html__('External Link', 'gunter-toolkit'),
                    'type'=>Controls_Manager:: URL,
                    'condition' => [
                        'link_type' => '2',
                    ],
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
			'banner_style',
			[
				'label' => __( 'Style', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

            $this->add_control(
                'background_color',
                [
                    'label' => __( 'Background Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .hero-banner' => 'background-color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'title_color',
                [
                    'label' => __( 'Title Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .hero-banner-content h1' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'title_size',
                [
                    'label' => __( 'Title Font Size', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 70,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .hero-banner-content h1' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'content_color',
                [
                    'label' => __( 'Content Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .hero-banner-content p' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'content_size',
                [
                    'label' => __( 'Content Font Size', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 50,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .hero-banner-content p' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );
        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        global $opt_name;
		if( isset( $opt_name['enable_lazyloader'] ) ):
			$is_lazyloader = $opt_name['enable_lazyloader'];
		else:
			$is_lazyloader = true;
		endif;

        // Inline Editing
        $this-> add_inline_editing_attributes('title','none');
        $this-> add_inline_editing_attributes('desc','none');

        // Get started button link
        $link = '';
        if( $settings['link_type'] == 1 ){
            $link = get_page_link($settings['link_to_page']);
        } else {
            $link = $settings['ex_link']['url'];
        }

        // About us button link
        $right_link = '';
        if( $settings['right_link_type'] == 1 ){
            $right_link = get_page_link($settings['right_link_to_page']);
        } else {
            $right_link = $settings['right_ex_link']['url'];
        }

        // dark and light version
        $dark = '';
        if( $settings['version'] == 'dark' ):
            $dark = ' uk-dark';
        endif;

        ?>
        <div id="home" class="hero-banner <?php echo esc_attr( $dark ); ?>">
            <div class="uk-container">
                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
                    <div class="item">
                        <div class="hero-banner-content">
                            <h1 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo wp_kses_post( $settings['title'] ); ?></h1>
                            <p <?php echo $this-> get_render_attribute_string('desc'); ?>><?php echo wp_kses_post( $settings['desc'] ); ?></p>

                            <div class="btn-box">
                                <?php if( $settings['button_text'] != '' ): ?>
                                    <a href="<?php echo esc_url( $link ); ?>" class="uk-button uk-button-default"><?php echo wp_kses_post( $settings['button_text'] ); ?></a>
                                <?php endif; ?>

                                <?php if( $settings['right_button_text'] != '' ): ?>
                                    <a href="<?php echo esc_url( $right_link ); ?>" class="uk-button-optional"><?php echo wp_kses_post( $settings['right_button_text'] ); ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="item">
                        <?php if( $settings['image']['url'] != '' ): ?>
                            <div class="hero-banner-image uk-text-center">
                                <?php if( $is_lazyloader == true ): ?>
                                    <img class="smartify" sm-src="<?php echo esc_url( $settings['image']['url'] ); ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <?php else: ?>
                                    <img src="<?php echo esc_url( $settings['image']['url'] ); ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Banner_Three );