<?php
/**
 * Pricing Plan Widget
 */

namespace Elementor;
class Gunter_Pricing extends Widget_Base {

	public function get_name() {
        return 'Pricing';
    }

	public function get_title() {
        return __( 'Pricing', 'gunter-toolkit' );
    }

	public function get_icon() {
        return 'eicon-price-list';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'pricing_section',
			[
				'label' => __( 'Pricing Control', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );
            $this->add_control(
                'icon',
                [
                    'label' => __( 'Icon Class Name', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                ]
            );
            $this->add_control(
                'icon_shape',
                [
                    'label' => __( 'Icon Shape', 'gunter-toolkit' ),
                    'type' => Controls_Manager::MEDIA,
                ]
            );
            $this->add_control(
                'title',
                [
                    'label' => __( 'Title', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Starter Plan', 'gunter-toolkit'),
                ]
            );
            $this->add_control(
                'price',
                [
                    'label' => __( 'Price', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('$49.99', 'gunter-toolkit'),
                ]
            );
            $this->add_control(
                'period',
                [
                    'label' => __( 'Period', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Per Month', 'gunter-toolkit'),
                ]
            );
            $this->add_control(
                'button_text',
                [
                    'label' => __( 'Button Text', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Book Now', 'gunter-toolkit'),
                ]
            );
            $this->add_control(
                'button_link',
                [
                    'label' => __( 'Button Link', 'gunter-toolkit' ),
                    'type' => Controls_Manager::URL,
                ]
            );

            $repeater = new Repeater();

            $repeater->add_control(
                'feature_title',
                [
                    'type'    => Controls_Manager::TEXT,
                    'label'   => esc_html__( 'Feature Title', 'gunter-toolkit' ),
                    'default' => __('10GB Bandwidth Internet', 'gunter-toolkit'),
                ]
            );

            $this->add_control(
                'features',
                [
                    'label'   => esc_html__( 'Add new feature', 'gunter-toolkit' ),
                    'type' => Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
			'pricing_style',
			[
				'label' => __( 'Style', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

            $this->add_control(
                'color',
                [
                    'label' => __( 'Main Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .single-pricing-box .pricing-header .icon' => 'color: {{VALUE}} !important',
                    ],
                ]
            );

            $this->add_responsive_control(
                'title_size',
                [
                    'label' => __( 'Title Font Size', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 5,
                            'max' => 40,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-pricing-box .pricing-header h3' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

        $this->end_controls_section();
    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        $this-> add_inline_editing_attributes('title','none');
        ?>
            <div class="single-pricing-box">
                <div class="pricing-header">
                    <div class="icon">
                        <i class="<?php echo esc_attr( $settings['icon'] );?>"></i>
                        <?php if( $settings['icon_shape']['url'] != '' ): ?>
                            <img src="<?php echo esc_url( $settings['icon_shape']['url'] ); ?>" alt="<?php echo esc_attr__( 'Shape', 'gunter-toolkit' ); ?>">
                        <?php endif; ?>
                    </div>
                    <h3><?php echo wp_kses_post( $settings['title'] ); ?></h3>
                </div>

                <div class="pricing-features">
                    <ul>
                        <?php foreach( $settings['features'] as $item ): ?>
                            <li><?php echo wp_kses_post($item['feature_title']); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <div class="price">
                    <?php echo wp_kses_post( $settings['price'] ); ?>
                    <span><?php echo wp_kses_post( $settings['period'] ); ?></span>
                </div>

                <?php if( $settings['button_text'] != '' ): ?>
                    <a href="<?php echo esc_url( $settings['button_link']['url'] ); ?>" class="uk-button uk-button-default"><?php echo wp_kses_post( $settings['button_text'] ); ?></a>
                <?php endif; ?>
            </div>
        <?php
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Pricing );