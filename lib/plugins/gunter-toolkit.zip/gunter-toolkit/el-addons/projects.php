<?php
/**
 * Projects Widget
 */

namespace Elementor;
class Gunter_Projects extends Widget_Base {

	public function get_name() {
        return 'Projects';
    }

	public function get_title() {
        return __( 'Projects', 'gunter-toolkit' );
    }

	public function get_icon() {
        return 'eicon-rating';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'projects_section',
			[
				'label' => __( 'Projects Control', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

            $this->add_control(
                'card_style',
                [
                    'label' => __( 'Select Style', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        1   => __( 'With Slider', 'gunter-toolkit' ),
                        2   => __( 'Without Slider One', 'gunter-toolkit' ),
                        3   => __( 'Without Slider Two', 'gunter-toolkit' ),
                        4   => __( 'Without Slider Three', 'gunter-toolkit' ),
                    ],
                    'default' => 1,
                ]
            );

            $this->add_control(
                'cat', [
                    'label' => esc_html__( 'Category', 'gunter-toolkit' ),
                    'description' => esc_html__( 'Enter the category slugs separated by commas (Eg. cat1, cat2)', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'label_block' => true,
                ]
            );

            $this->add_control(
                'version',
                [
                    'label' => __( 'Select Version', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'dark'   => __( 'Dark', 'gunter-toolkit' ),
                        'light'   => __( 'Light', 'gunter-toolkit' ),
                    ],
                    'default' => 'dark',
                    'condition' => [
                        'card_style' => '1',
                    ],
                ]
            );

            $this->add_control(
                'pagination',
                [
                    'label' => __( 'Show Pagination', 'gunter-toolkit' ),
                    'description' => __( 'Pagination Not Working On Home Page!', 'gunter-toolkit' ),
                    'type' =>Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'gunter-toolkit' ),
                    'label_off' => __( 'Hide', 'gunter-toolkit' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                    'condition' => [
                        'card_style' => '2',
                    ],
                ]
            );

            $this->add_control(
                'link',
                [
                    'label' => __( 'Link', 'gunter-toolkit' ),
                    'type' =>Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'gunter-toolkit' ),
                    'label_off' => __( 'Hide', 'gunter-toolkit' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );

            $this->add_control(
                'order',
                [
                    'label' => __( 'Project Order By', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'DESC'      => __( 'DESC', 'gunter-toolkit' ),
                        'ASC'       => __( 'ASC', 'gunter-toolkit' ),
                    ],
                    'default' => 'DESC',
                ]
            );

            $this->add_control(
                'count',
                [
                    'label' => __( 'Post Per Page', 'gunter-toolkit' ),
                    'type' => Controls_Manager::NUMBER,
                    'default' => 4,
                ]
            );

        $this->end_controls_section();
    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        global $opt_name;
		if( isset( $opt_name['enable_lazyloader'] ) ):
			$is_lazyloader = $opt_name['enable_lazyloader'];
		else:
			$is_lazyloader = true;
        endif;
        ?>

        <?php if( $settings['card_style']  == 1 ):

            // Project Query
            if (!empty($settings['cat'])) {
                $work_array = new \WP_Query(array(
                    'post_type' => 'project',
                    'posts_per_page' => $settings['count'],
                    'order' => $settings['order'],
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'project_cat',
                            'field'    => 'slug',
                            'terms'    => explode( ',', str_replace( ' ', '', $settings['cat'])),
                        ),
                    ),
                ));
            } else {
                $work_array = new \WP_Query(array(
                    'post_type' => 'project',
                    'posts_per_page' => $settings['count'],
                    'order' => $settings['order'],
                ));
            }

            if( $settings['count'] == 1 || $settings['count'] == 2 ) { ?>
            <div class="uk-container">
                <?php if( $settings['count'] == 2 ){ ?>
                    <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s uk-flex-center"> <?php
                } else { ?>
                    <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s uk-flex-center"> <?php
                }
            } else { ?>
            <div class="project-slides owl-carousel owl-theme"> <?php
            } ?>
                <?php

                $dark_class = '';
                if( $settings['version'] == 'dark' ):
                    $dark_class = 'owl-dark';
                endif;

                while($work_array->have_posts()):
                    $work_array->the_post();

                    // Post Link
                    if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
                        $post_link = get_the_permalink();
                    } else {
                        $post_link = get_field('external_link');
                    }

                    // ACF Fields
                    $icon = get_field('project_icon');

                    // Category List
                    $project_category = get_the_terms(get_the_ID(), 'project_cat');

                    if($project_category && ! is_wp_error( $project_category )) {
                        $project_cat_list = array();

                        foreach($project_category as $category) {
                        $project_cat_list[] = '<li>'.$category->name.'</li>';
                        $project_cat_slug[] = $category->slug;
                        }
                        $project_assigned_cat = join( " ", $project_cat_list );
                        $project_assigned_slug = join( " ", $project_cat_slug );
                    } else {
                        $project_assigned_cat = '';
                        $project_assigned_slug = '';
                    }

                ?>
                    <div class="single-projects <?php echo esc_attr( $dark_class ); ?>">
                        <?php if( $settings['link'] == 'yes' ): ?>
                            <a href="<?php echo esc_url( $post_link ); ?>" class="project-img">
                                <?php if( $is_lazyloader == true ): ?>
                                    <img class="smartify" sm-src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')); ?>" alt="<?php the_title(); ?>">
                                <?php else: ?>
                                    <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')); ?>" alt="<?php the_title(); ?>">
                                <?php endif; ?>
                            </a>
                        <?php else: ?>
                            <div class="project-img">
                                <?php if( $is_lazyloader == true ): ?>
                                    <img class="smartify" sm-src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')); ?>" alt="<?php the_title(); ?>">
                                <?php else: ?>
                                    <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')); ?>" alt="<?php the_title(); ?>">
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <div class="project-content">
                            <?php if( $settings['link'] == 'yes' ): ?>
                                <h3><a href="<?php echo esc_url( $post_link ); ?>"><?php the_title(); ?></a></h3>
                            <?php else: ?>
                                <h3><?php the_title(); ?></h3>
                            <?php endif; ?>
                            <ul>
                                <?php echo wp_kses_post($project_assigned_cat, 'gunter-toolkit'); ?>
                            </ul>
                        </div>
                    </div>
                <?php endwhile; ?>
                <?php wp_reset_query(); ?>

            <?php if( $settings['count'] == 1 || $settings['count'] == 2 ) { ?>
            </div>
            <?php } ?>
            </div>
        <?php endif; ?>

        <?php if( $settings['card_style']  == 2 ): ?>
            <div class="project-area uk-project uk-section">
                <div class="uk-container">
                    <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s">

                    <?php
                    $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

                    if (!empty($settings['cat'])) {
                        $work_array = new \WP_Query(array(
                            'post_type' => 'project',
                            'posts_per_page' => $settings['count'],
                            'order' => $settings['order'],
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'project_cat',
                                    'field'    => 'slug',
                                    'terms'    => explode( ',', str_replace( ' ', '', $settings['cat'])),
                                ),
                            ),
                            'paged' => get_query_var('paged') ? get_query_var('paged') : 1
                        ));
                    } else {
                        $work_array = new \WP_Query(array(
                            'post_type' => 'project',
                            'posts_per_page' => $settings['count'],
                            'order' => $settings['order'],
                            'paged' => get_query_var('paged') ? get_query_var('paged') : 1
                        ));
                    }

                    while($work_array->have_posts()): $work_array->the_post();

                        // Post Link
                        if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
                            $post_link = get_the_permalink();
                        } else {
                            $post_link = get_field('external_link');
                        }

                        $idd = get_the_ID();
                        $work_category = get_the_terms(get_the_ID(), 'project_cat');

                            if($work_category && ! is_wp_error( $work_category )) {
                                $work_cat_list = array();

                                foreach($work_category as $category) {
                                $work_cat_list[] = '<li>'.$category->name.'</li>';
                                $work_cat_slug[] = $category->slug;
                                }
                                $work_assaigned_cat = join( " ", $work_cat_list );
                                $work_assaigned_slug = join( " ", $work_cat_slug );
                            } else {
                                $work_assaigned_cat = '';
                                $work_assaigned_slug = '';
                            }
                            ?>
                        <div class="single-projects single-project-two">
                            <?php if( $settings['link'] == 'yes' ): ?>
                                <a href="<?php echo esc_url( $post_link ); ?>" class="project-img">
                                    <?php if( $is_lazyloader == true ): ?>
                                        <img class="smartify" sm-src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')); ?>" alt="<?php the_title(); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')); ?>" alt="<?php the_title(); ?>">
                                    <?php endif; ?>
                                </a>
                            <?php else: ?>
                                <div class="project-img">
                                    <?php if( $is_lazyloader == true ): ?>
                                        <img class="smartify" sm-src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')); ?>" alt="<?php the_title(); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')); ?>" alt="<?php the_title(); ?>">
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>

                            <div class="project-content">
                                <?php if( $settings['link'] == 'yes' ): ?>
                                    <h3><a href="<?php echo esc_url( $post_link ); ?>"><?php the_title(); ?></a></h3>
                                <?php else: ?>
                                    <h3><?php the_title(); ?></h3>
                                <?php endif; ?>
                                <ul><?php echo wp_kses_post($work_assaigned_cat, 'gunter-toolkit'); ?></ul>
                            </div>
                        </div><?php
                    endwhile;
                    ?>
                    </div>

                    <?php
                    $pagin    = 999999999;
                    $pageLinks  =  paginate_links( array(
                        "base"      => str_replace( $pagin, "%#%", get_pagenum_link( $pagin ) ),
                        "format"    => "?paged=%#%",
                        "current"   => max( 1, get_query_var("paged") ),
                        "total"     => $work_array->max_num_pages,
                        "prev_text" => __("<span class='flaticon-back'></span>","gunter-toolkit"),
                        "next_text" => __("<span class='flaticon-right'>","gunter-toolkit"),
                        "type"      => "list",
                    ) );

                if(!is_front_page() && !is_home() && $settings['pagination'] == 'yes'){
                    ?>
                    <div class="custom-pagination-area">
                        <?php echo wp_kses_post($pageLinks, 'gunter-toolkit'); ?>
                    </div><?php
                }
                wp_reset_query();
                ?>

                </div>
            </div>
        <?php endif; ?>

        <?php if( $settings['card_style']  == 3 ): ?>
            <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s">
                <?php
                    // Project Query
                    if (!empty($settings['cat'])) {
                        $work_array = new \WP_Query(array(
                            'post_type' => 'project',
                            'posts_per_page' => $settings['count'],
                            'order' => $settings['order'],
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'project_cat',
                                    'field'    => 'slug',
                                    'terms'    => explode( ',', str_replace( ' ', '', $settings['cat'])),
                                ),
                            ),
                        ));
                    } else {
                        $work_array = new \WP_Query(array(
                            'post_type' => 'project',
                            'posts_per_page' => $settings['count'],
                            'order' => $settings['order'],
                        ));
                    }

                    while($work_array->have_posts()): $work_array->the_post();

                        // Post Link
                        if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
                            $post_link = get_the_permalink();
                        } else {
                            $post_link = get_field('external_link');
                        }

                        $idd = get_the_ID();
                        $work_category = get_the_terms(get_the_ID(), 'project_cat');

                        if($work_category && ! is_wp_error( $work_category )) {
                            $work_cat_list = array();

                            foreach($work_category as $category) {
                            $work_cat_list[] = '<li>'.$category->name.'</li>';
                            $work_cat_slug[] = $category->slug;
                            }
                            $work_assaigned_cat = join( " ", $work_cat_list );
                            $work_assaigned_slug = join( " ", $work_cat_slug );
                        } else {
                            $work_assaigned_cat = '';
                            $work_assaigned_slug = '';
                        }
                    ?>
                    <div class="item">
                        <div class="single-project-box">
                            <a href="<?php echo esc_url( $post_link ); ?>" class="project-img">
                                <?php if( $is_lazyloader == true ): ?>
                                    <img class="smartify" sm-src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')); ?>" alt="<?php the_title_attribute(); ?>">
                                <?php else: ?>
                                    <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')); ?>" alt="<?php the_title_attribute(); ?>">
                                <?php endif; ?>
                            </a>

                            <div class="project-content">
                                <?php if( $settings['link'] == 'yes' ): ?>
                                    <h3><a href="<?php echo esc_url( $post_link ); ?>"><?php the_title(); ?></a></h3>
                                <?php else: ?>
                                    <h3><?php the_title(); ?></h3>
                                <?php endif; ?>
                                <ul><?php echo wp_kses_post($work_assaigned_cat, 'gunter-toolkit'); ?></ul>
                                <?php if( $settings['link'] == 'yes' ): ?>
                                    <a href="<?php echo esc_url( $post_link ); ?>" class="details-btn"><i uk-icon="plus"></i></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
                <?php wp_reset_query(); ?>
            </div>
        <?php endif; ?>

        <?php if( $settings['card_style']  == 4 ):
            // Project Query
            if (!empty($settings['cat'])) {
                $work_array = new \WP_Query(array(
                    'post_type' => 'project',
                    'posts_per_page' => $settings['count'],
                    'order' => $settings['order'],
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'project_cat',
                            'field'    => 'slug',
                            'terms'    => explode( ',', str_replace( ' ', '', $settings['cat'])),
                        ),
                    ),
                ));
            } else {
                $work_array = new \WP_Query(array(
                    'post_type' => 'project',
                    'posts_per_page' => $settings['count'],
                    'order' => $settings['order'],
                ));
            }
            ?>
            <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-2@s">
                <?php
                $i = 1;
                while($work_array->have_posts()): $work_array->the_post();

                    // Post Link
                    if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
                        $post_link = get_the_permalink();
                    } else {
                        $post_link = get_field('external_link');
                    }
                    $top_title = get_field( 'project_top_title' );

                    $idd = get_the_ID();
                    if( $i == 1 || $i == 2 ): ?>
                        <div class="uk-item">
                            <div class="single-project-item">
                                <a href="<?php echo esc_url( $post_link ); ?>" class="image">
                                    <?php if( $is_lazyloader == true ): ?>
                                        <img class="smartify" sm-src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image_full')); ?>" alt="<?php the_title_attribute(); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image_full')); ?>" alt="<?php the_title_attribute(); ?>">
                                    <?php endif; ?>
                                </a>

                                <div class="content">
                                    <a href="<?php echo esc_url( $post_link ); ?>" class="category"><?php echo wp_kses_post( $top_title ); ?></a>
                                    <h3><a href="<?php echo esc_url( $post_link ); ?>"><?php the_title(); ?></a></h3>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php $i++; endwhile; ?>
                <?php wp_reset_query(); ?>
            </div>

            <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s">
                <?php
                $i = 1;
                while($work_array->have_posts()): $work_array->the_post();

                    // Post Link
                    if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
                        $post_link = get_the_permalink();
                    } else {
                        $post_link = get_field('external_link');
                    }
                    $top_title = get_field( 'project_top_title' );

                    $idd = get_the_ID();
                    if( $i != 1 && $i != 2 ): ?>
                        <div class="uk-item">
                            <div class="single-project-item">
                                <a href="<?php echo esc_url( $post_link ); ?>" class="image">
                                    <?php if( $is_lazyloader == true ): ?>
                                        <img class="smartify" sm-src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image_two')); ?>" alt="<?php the_title_attribute(); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image_two')); ?>" alt="<?php the_title_attribute(); ?>">
                                    <?php endif; ?>
                                </a>

                                <div class="content">
                                    <a href="<?php echo esc_url( $post_link ); ?>" class="category"><?php echo wp_kses_post( $top_title ); ?></a>
                                    <h3><a href="<?php echo esc_url( $post_link ); ?>"><?php the_title(); ?></a></h3>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php $i++; endwhile; ?>
                <?php wp_reset_query(); ?>

            </div>

        <?php endif; ?>
        <?php
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Projects );