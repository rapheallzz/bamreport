<?php
/**
 * Services ARea Widget
 */

namespace Elementor;
class Gunter_Services_Area extends Widget_Base {

	public function get_name() {
        return 'Gunter_Services_Area';
    }

	public function get_title() {
        return __( 'Services Area', 'gunter-toolkit' );
    }

	public function get_icon() {
        return ' eicon-archive';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'services_section',
			[
				'label' => __( 'Services Area Control', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );
            $this->add_control(
                'title',
                [
                    'label' => __( 'Section Title', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                ]
            );

            $this->add_control(
                'shape',
                [
                    'label'   => esc_html__( 'Icon Shape Image', 'gunter-toolkit' ),
                    'type' => Controls_Manager::MEDIA,
                ]
            );

            $repeater = new Repeater();

            $repeater->add_control(
                'title',
                [
                    'type'    => Controls_Manager::TEXT,
                    'label'   => esc_html__( 'Title', 'gunter-toolkit' ),
                    'default' => esc_html__('Business Planning', 'gunter-toolkit'),
                ]
            );
            $repeater->add_control(
                'description',
                [
                    'type'    => Controls_Manager::TEXTAREA,
                    'label'   => esc_html__( 'Description', 'gunter-toolkit' ),
                    'default' => esc_html__('Risus commodo maecenas accumsan lacus vel facilisis. Lorem ipsum dolor consectetur adipiscing elit.', 'gunter-toolkit'),
                ]
            );
            $repeater->add_control(
                'font-type',
                [
                    'label' => __( 'Font Type', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'fontawesome'      => __( 'Font Awesome', 'gunter-toolkit' ),
                        'custom_class'     => __( 'Font Class Name', 'gunter-toolkit' ),
                    ],
                    'default' => 'fontawesome',
                ]
            );
            $repeater->add_control(
                'font-awesome',
                [
                    'label' => __( 'Font Awesome Icon', 'gunter-toolkit' ),
                    'type' => Controls_Manager::ICON,
                    'condition' => [
                        'font-type' => ['fontawesome'],
                    ],
                ]
            );
            $repeater->add_control(
                'custom_icon',
                [
                    'label' => __( 'Font Class Name', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'condition' => [
                        'font-type' => ['custom_class'],
                    ],
                ]
            );

            $this->add_control(
                'items',
                [
                    'label'   => esc_html__( 'Add Item', 'gunter-toolkit' ),
                    'type' => Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
			'counter_style',
			[
				'label' => __( 'Style', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

            $this->add_control(
                'sec_title_color',
                [
                    'label' => __( 'Section Title Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .featured-services-area .section-title p' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'section_title_size',
                [
                    'label' => __( 'Section Title Font Size', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 70,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .featured-services-area .section-title p' => 'font-size: {{SIZE}}px;',
                    ],
                ]
        );
            $this->add_control(
				'title_color',
				[
					'label' => __( 'Title Color', 'gunter-toolkit' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .single-featured-services-box h3' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_responsive_control(
				'title_size',
				[
					'label' => __( 'Title Font Size', 'gunter-toolkit' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 70,
							'step' => 1,
						],
					],
					'devices' => [ 'desktop', 'tablet', 'mobile' ],
					'selectors' => [
						'{{WRAPPER}} .single-featured-services-box h3' => 'font-size: {{SIZE}}px;',
					],
				]
            );

            $this->add_control(
				'icon_color',
				[
					'label' => __( 'Icon Color', 'gunter-toolkit' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .single-featured-services-box .icon' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_responsive_control(
				'icon_size',
				[
					'label' => __( 'Icon Font Size', 'gunter-toolkit' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 70,
							'step' => 1,
						],
					],
					'devices' => [ 'desktop', 'tablet', 'mobile' ],
					'selectors' => [
						'{{WRAPPER}} .single-featured-services-box .icon' => 'font-size: {{SIZE}}px;',
					],
				]
            );

            $this->add_control(
                'counter_color',
                [
                    'label' => __( 'Content Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .single-featured-services-box p' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
				'content_size',
				[
					'label' => __( 'Content Font Size', 'gunter-toolkit' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 70,
							'step' => 1,
						],
					],
					'devices' => [ 'desktop', 'tablet', 'mobile' ],
					'selectors' => [
						'{{WRAPPER}} .single-featured-services-box p' => 'font-size: {{SIZE}}px;',
					],
				]
			);

        $this->end_controls_section();
    }

	protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <div class="featured-services-area uk-featured-services uk-section">
            <div class="uk-container">
                <?php if( $settings['title'] != '' ): ?>
                    <div class="uk-section-title section-title">
                        <p><?php echo wp_kses_post( $settings['title'] ); ?></p>
                    </div>
                <?php endif; ?>

                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s">
                    <?php foreach( $settings['items'] as $item ):
                        // Icon Class
                        if( $item['font-type'] == 'fontawesome' ):
                            $icon = $item['font-awesome'];
                        else:
                            $icon = $item['custom_icon'];
                        endif;
                        ?>
                        <div class="uk-item">
                            <div class="single-featured-services-box">
                                    <?php if( $icon != '' ): ?>
                                    <div class="icon">
                                        <i class="<?php echo esc_attr( $icon ); ?>"></i>
                                    </div>
                                <?php endif; ?>

                                <h3><?php echo wp_kses_post( $item['title'] ); ?></h3>
                                <div class="bar"></div>
                                <p><?php echo wp_kses_post( $item['description'] ); ?></p>

                                <?php if( $settings['shape']['url'] != '' ): ?>
                                    <div class="bg-shape"><img src="<?php echo esc_url( $settings['shape']['url'] ); ?>" alt="<?php echo esc_attr( $item['title'] ); ?>"></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Services_Area );