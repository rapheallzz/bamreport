<?php
/**
 * Testimonial Widget
 */

namespace Elementor;
class Gunter_Testimonial_Two extends Widget_Base {

	public function get_name() {
        return 'TestimonialTwo';
    }

	public function get_title() {
        return __( 'Testimonials Two', 'gunter-toolkit' );
    }

	public function get_icon() {
        return 'eicon-testimonial-carousel';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );
            $this->add_control(
                'card_style',
                [
                    'label' => __( 'Version', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'dark'      => __( 'Dark', 'gunter-toolkit' ),
                        'light'     => __( 'Light', 'gunter-toolkit' ),
                    ],
                    'default' => 'dark',
                ]
            );

            $this->add_control(
                'shape',
                [
                    'label' => __( 'Image Shape', 'gunter-toolkit' ),
                    'type' =>Controls_Manager::MEDIA,
                ]
            );

            $repeater = new Repeater();

            $repeater->add_control(
                'image',
                [
                    'label' => esc_html__('Image', 'gunter-toolkit'),
                    'type' => Controls_Manager::MEDIA,
                    'label_block' => true,
                ]
            );
            $repeater->add_control(
                'name',
                [
                    'label' => esc_html__('Name', 'gunter-toolkit'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Steven Smith', 'gunter-toolkit'),
                    'label_block' => true,
                ]
            );
            $repeater->add_control(
                'designation',
                [
                    'label' => esc_html__('Designation', 'gunter-toolkit'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('CTO at Envato', 'gunter-toolkit'),
                    'label_block' => true,
                ]
            );
            $repeater->add_control(
                'feedback',
                [
                    'label' => esc_html__('Feedback', 'gunter-toolkit'),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum  ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed tempor incididunt ut labore et dolore.', 'gunter-toolkit'),
                    'label_block' => true,
                ]
            );

            $this->add_control(
                'testimonial_items',
                [
                    'label' => esc_html__('Slider Item', 'gunter-toolkit'),
                    'type' => Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                ]
            );
        $this->end_controls_section();
    }

	protected function render() {

        $settings       = $this->get_settings_for_display();

        global $opt_name;
		if( isset( $opt_name['enable_lazyloader'] ) ):
			$is_lazyloader = $opt_name['enable_lazyloader'];
		else:
			$is_lazyloader = true;
        endif;

        $slider         = $settings['testimonial_items'];
        $card_style     = $settings['card_style'];

        $dark_class = '';
        if($card_style == 'dark'){
            $dark_class = 'uk-dark';
        }

        ?>
            <div class="testimonials-section uk-testimonials uk-section <?php echo $dark_class; ?>">
                <div class="uk-container">
                    <div class="testimonials-slides owl-carousel owl-theme">
                        <?php foreach( $slider as $item ): ?>
                            <div class="single-testimonials-box">
                                <?php if( $item['image']['url'] != '' ): ?>
                                    <div class="user-image">
                                        <img src="<?php echo esc_url( $item['image']['url'] ); ?>" class="user" alt="<?php echo esc_attr( $item['name'] ); ?>">

                                        <?php if( $settings['shape']['url'] != '' ): ?>
                                            <img src="<?php echo esc_url( $settings['shape']['url'] ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>" class="shape">
                                        <?php endif ?>
                                    </div>
                                <?php endif ?>

                                <p><?php echo wp_kses_post( $item['feedback'] ); ?></p>
                                <div class="user-info">
                                    <h3><?php echo wp_kses_post( $item['name'] ); ?></h3>
                                    <span><?php echo wp_kses_post( $item['designation'] ); ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php
	}

}
Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Testimonial_Two );