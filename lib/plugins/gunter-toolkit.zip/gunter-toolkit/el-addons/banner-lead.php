<?php
/**
 * Banner Widget
 */

namespace Elementor;
class Gunter_Lead_Banner extends Widget_Base {

	public function get_name() {
        return 'Gunter_Lead_Banner';
    }

	public function get_title() {
        return __( 'Banner With Form', 'gunter-toolkit' );
    }

	public function get_icon() {
        return 'eicon-call-to-action';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'Gunter_Lead_Banner_Area',
			[
				'label' => __( 'Banner Controls', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

            $this->add_control(
                'card_style',
                [
                    'label' => __( 'Form Position', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'left'         => __( 'Left', 'gunter-toolkit' ),
                        'right'         => __( 'Right', 'gunter-toolkit' ),
                    ],
                    'default' => 'right',
                ]
            );

            $this->add_control(
                'version',
                [
                    'label' => __( 'Choose Version', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'light'         => __( 'Light', 'gunter-toolkit' ),
                        'dark'          => __( 'Dark', 'gunter-toolkit' ),
                    ],
                    'default' => 'dark',
                ]
            );

            $this->add_control(
                'title',
                [
                    'label' => __( 'Title', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Focused on targets', 'gunter-toolkit'),
                ]
            );

            $this->add_control(
                'desc',
                [
                    'label' => __( 'Content', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => __('We have designed our services to make your online business easy and successful! Our experienced team always dedicated and serious to confirm you get the best!', 'gunter-toolkit'),
                ]
            );

            $this->add_control(
                'shortcode',
                [
                    'label' => __( 'Form Shortcode', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                ]
            );

            $this->add_control(
                'button_text',
                [
                    'label' => __( 'Button Text', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Get Started', 'gunter-toolkit'),
                ]
            );

            $this->add_control(
                'link_type',
                [
                    'label' => esc_html__( 'Link Type', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'label_block' => true,
                    'options' => [
                        '1'  => esc_html__( 'Link To Page', 'gunter-toolkit' ),
                        '2' => esc_html__( 'External Link', 'gunter-toolkit' ),
                    ],
                ]
            );

            $this->add_control(
                'link_to_page',
                [
                    'label' => esc_html__( 'Link Page', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'label_block' => true,
                    'options' => gunter_toolkit_pages_list_el(),
                    'condition' => [
                        'link_type' => '1',
                    ],
                ]
            );

            $this->add_control(
                'ex_link',
                [
                    'label'=>esc_html__('External Link', 'gunter-toolkit'),
                    'type'=>Controls_Manager:: URL,
                    'condition' => [
                        'link_type' => '2',
                    ],
                ]
            );

            $this->add_control(
                'video_button_text',
                [
                    'label' => __( 'Video Button Text', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Watch Video', 'gunter-toolkit'),
                ]
            );
            $this->add_control(
                'video_button_link',
                [
                    'label'=>esc_html__('Video Button Link', 'gunter-toolkit'),
                    'type'=>Controls_Manager:: URL,
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
			'banner_style',
			[
				'label' => __( 'Style', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

            $this->add_control(
                'title_color',
                [
                    'label' => __( 'Title Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .main-banner-content h2' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'title_size',
                [
                    'label' => __( 'Title Font Size', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 70,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .main-banner-content h2' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'content_color',
                [
                    'label' => __( 'Content Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .main-banner-content p' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'content_size',
                [
                    'label' => __( 'Content Font Size', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 50,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .main-banner-content p' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );
        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        // Inline Editing
        $this-> add_inline_editing_attributes('title','none');
        $this-> add_inline_editing_attributes('desc','none');

        // Get started button link
        $link = '';
        if( $settings['link_type'] == 1 ){
            $link = get_page_link($settings['link_to_page']);
        } else {
            $link = $settings['ex_link']['url'];
        }

        // dark and light version
        $class = '';
        if( $settings['version'] == 'dark' ):
            $class = 'uk-dark';
        else:
            $class = 'light-banner';
        endif;

        ?>
        <?php if( $settings['card_style'] == 'right' ): ?>
            <div class="uk-banner main-banner lead-generation-banner <?php echo esc_attr( $class ); ?>">
                <div class="d-table">
                    <div class="d-table-cell">
                        <div class="uk-container">
                            <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
                                <div clss="item">
                                    <div class="main-banner-content">
                                        <h2 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo wp_kses_post( $settings['title'] ); ?></h2>
                                        <p <?php echo $this-> get_render_attribute_string('desc'); ?>><?php echo wp_kses_post( $settings['desc'] ); ?></p>

                                        <?php if( $settings['button_text'] != '' ): ?>
                                            <a href="<?php echo esc_url( $link ); ?>" class="uk-button uk-button-default"><?php echo wp_kses_post( $settings['button_text'] ); ?></a>
                                        <?php endif; ?>

                                        <?php if( $settings['video_button_text'] != '' ): ?>
                                            <a href="<?php echo esc_url( $settings['video_button_link']['url'] ); ?>" class="video-btn popup-youtube"><span data-uk-icon="play"></span> <?php echo wp_kses_post( $settings['video_button_text'] ); ?></a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div clss="item">
                                    <div class="lead-generation-form">
                                        <?php echo do_shortcode($settings['shortcode']); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php elseif( $settings['card_style'] == 'left' ): ?>
            <div class="uk-banner main-banner lead-generation-banner form-left light-form-left <?php echo esc_attr( $class ); ?>">
                <div class="d-table">
                    <div class="d-table-cell">
                        <div class="uk-container">
                            <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">

                                <div class="item">
                                    <div class="lead-generation-form">
                                        <?php echo do_shortcode($settings['shortcode']); ?>
                                    </div>
                                </div>

                                <div class="item">
                                    <div class="main-banner-content">
                                        <h2 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo wp_kses_post( $settings['title'] ); ?></h2>
                                        <p <?php echo $this-> get_render_attribute_string('desc'); ?>><?php echo wp_kses_post( $settings['desc'] ); ?></p>

                                        <?php if( $settings['button_text'] != '' ): ?>
                                            <a href="<?php echo esc_url( $link ); ?>" class="uk-button uk-button-default"><?php echo wp_kses_post( $settings['button_text'] ); ?></a>
                                        <?php endif; ?>

                                        <?php if( $settings['video_button_text'] != '' ): ?>
                                            <a href="<?php echo esc_url( $settings['video_button_link']['url'] ); ?>" class="video-btn popup-youtube"><span data-uk-icon="play"></span> <?php echo wp_kses_post( $settings['video_button_text'] ); ?></a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Lead_Banner );