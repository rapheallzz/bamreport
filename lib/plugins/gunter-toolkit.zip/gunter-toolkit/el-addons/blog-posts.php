<?php
/**
 * Blog Post Widget
 */

namespace Elementor;
class Gunter_Blog_Post extends Widget_Base {

	public function get_name() {
        return 'Gunter_Blog_Post';
    }

	public function get_title() {
        return __( 'Blog Post', 'gunter-toolkit' );
    }

	public function get_icon() {
        return 'eicon-posts-grid';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'blog_section',
			[
				'label' => __( 'Blog Post', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

            $this->add_control(
                'style',
                [
                    'label' => __( 'Style', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        '1'      => __( 'One', 'gunter-toolkit' ),
                        '2'       => __( 'Two', 'gunter-toolkit' ),
                    ],
                    'default' => '1',
                ]
            );

            $this->add_control(
                'cat', [
                    'label' => esc_html__( 'Category', 'gunter-toolkit' ),
                    'description' => esc_html__( 'Enter the category slugs separated by commas (Eg. cat1, cat2)', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'label_block' => true,
                ]
            );

            $this->add_control(
                'order',
                [
                    'label' => __( 'Post Order By', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'DESC'      => __( 'DESC', 'gunter-toolkit' ),
                        'ASC'       => __( 'ASC', 'gunter-toolkit' ),
                    ],
                    'default' => 'DESC',
                ]
            );

            $this->add_control(
                'count',
                [
                    'label' => __( 'Post Per Page', 'gunter-toolkit' ),
                    'type' => Controls_Manager::NUMBER,
                    'default' => 4,
                ]
            );

            $this->add_control(
                'read_more_text',
                [
                    'label' => __( 'Post Read More Text', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Read More', 'gunter-toolkit'),
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
			'post_style',
			[
				'label' => __( 'Style', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

        $this->add_responsive_control(
			'title_size',
			[
				'label' => __( 'Title Font Size', 'gunter-toolkit' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 40,
						'step' => 1,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'selectors' => [
					'{{WRAPPER}} .blog-slides .single-blog-post .blog-post-content h3' => 'font-size: {{SIZE}}px;',
				],
			]
        );

        $this->add_control(
			'title_color',
			[
				'label' => __( 'Title Color', 'gunter-toolkit' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .uk-dark .single-blog-post .blog-post-content h3 a' => 'color: {{VALUE}}',
				],
			]
        );

        $this->end_controls_section();

    }

	protected function render() {
        $settings = $this->get_settings_for_display();

        global $opt_name;
		if( isset( $opt_name['enable_lazyloader'] ) ):
			$is_lazyloader = $opt_name['enable_lazyloader'];
		else:
			$is_lazyloader = true;
        endif;

        if (!empty($settings['cat'])) {
            $post_array = new \WP_Query(array(
                'post_type' => 'post',
                'posts_per_page'=> $settings['count'],
                'order' => $settings['order'],
                'ignore_sticky_posts' => 1,
                'category_name' =>$settings['cat'],
            ));
        }else {
            $post_array = new \WP_Query(array(
                'post_type' => 'post',
                'ignore_sticky_posts' => 1,
                'posts_per_page' => $settings['count'],
                'order' =>  $settings['order'],
            ));
        }

        if( $settings['style'] == '1' ):
            if( $settings['count'] == 1 || $settings['count'] == 2 ) { ?>
                <div class="uk-container">
                    <?php if( $settings['count'] == 2 ){ ?>
                        <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s uk-flex-center"> <?php
                    } else { ?>
                        <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s uk-flex-center"> <?php
                    }
                } else { ?>
                <div class="blog-slides owl-carousel owl-theme">
            <?php } ?>
                    <?php while($post_array->have_posts()): $post_array->the_post();  $idd = get_the_ID(); ?>
                        <div class="single-blog-post">
                            <div class="blog-post-image">
                                <a href="<?php the_permalink(); ?>">
                                    <?php if( $is_lazyloader == true ): ?>
                                        <img class="smartify" sm-src="<?php echo esc_url(get_the_post_thumbnail_url($idd, 'gunter_news_image')) ?>" alt="<?php the_title(); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo esc_url(get_the_post_thumbnail_url($idd, 'gunter_news_image')) ?>" alt="<?php the_title(); ?>">
                                <?php endif; ?>
                                </a>
                            </div>

                            <div class="blog-post-content">
                                <?php if( isset( $opt_name['is_post_meta'] ) && $opt_name['is_post_meta'] == true ) { ?>
                                    <span class="date"><?php the_date( 'j F' ); ?></span>
                                <?php } ?>
                                <h3><a href="<?php the_permalink(); ?>"><?php echo wp_trim_words( get_the_title(), 9, ' ' ); ?></a></h3>
                                <a href="<?php the_permalink(); ?>" class="read-more"><?php echo wp_kses_post( $settings['read_more_text'] ); ?></a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                    <?php wp_reset_postdata(); ?>
            <?php if( $settings['count'] == 1 || $settings['count'] == 2 ) { ?>
                </div>
            <?php } ?>
                </div>
        <?php endif; ?>

        <?php if( $settings['style'] == '2' ): ?>
            <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s">
                <?php while($post_array->have_posts()): $post_array->the_post();  $idd = get_the_ID(); ?>
                    <div class="uk-item">
                        <div class="single-blog-post-item">
                                <a href="<?php the_permalink(); ?>" class="post-image">
                                    <?php if( $is_lazyloader == true ): ?>
                                        <img class="smartify" sm-src="<?php echo esc_url(get_the_post_thumbnail_url($idd, 'gunter_news_image')) ?>" alt="<?php the_title(); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo esc_url(get_the_post_thumbnail_url($idd, 'gunter_news_image')) ?>" alt="<?php the_title(); ?>">
                                <?php endif; ?>
                            <div class="post-content">
                                <?php
                                $posttags = get_the_tags();
                                $count = 0; $sep = '';
                                if ( $posttags ) {
                                    foreach( $posttags as $tag ) {
                                        $count++;
                                        echo '<a class="category" href="'.get_tag_link($tag->term_id).'">'.$tag->name.'</a>';
                                        if( $count > 0 ) break;
                                    }
                                }
                                ?>
                                <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
                <?php wp_reset_postdata(); ?>
            </div>
        <?php endif; ?>

    <?php
    }
}

Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Blog_Post );