<?php
/**
 * Separator Widget
 */

namespace Elementor;
class Gunter_Separator extends Widget_Base {

	public function get_name() {
        return 'Separator';
    }

	public function get_title() {
        return __( 'Separator', 'gunter-toolkit' );
    }

	public function get_icon() {
        return 'eicon-divider-shape';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'Gunter_Separator',
			[
				'label' => __( 'Separator Control', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

            $this->add_control(
                'style',
                [
                    'label' => __( 'Select Style', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        1      => __( 'One', 'gunter-toolkit' ),
                        2     => __( 'Two', 'gunter-toolkit' ),
                    ],
                    'default' => 1,
                ]
            );

            $this->add_control(
                'section_version',
                [
                    'label' => __( 'Select Version', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'dark'      => __( 'Dark', 'gunter-toolkit' ),
                        'light'     => __( 'Light', 'gunter-toolkit' ),
                    ],
                    'default' => 'dark',
                ]
            );

            $this->add_control(
                'main_color',
                [
                    'label' => __( 'Main Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .br-line' => 'background: {{VALUE}}',
                        '{{WRAPPER}} .uk-border' => 'background-color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'height',
                [
                    'label' => __( 'Height', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 500,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .br-line, .uk-border' => 'height: {{SIZE}}px;',
                    ],
                ]
            );

        $this->end_controls_section();
    }

	protected function render() {

        $settings = $this->get_settings_for_display();
        $dark = 'uk-dark';
        ?>
            <?php if( $settings['style'] == 1 ): ?>
                <div class="separate <?php if( $settings['section_version'] == 'dark' ): echo esc_attr( $dark ); endif; ?>">
                    <div class="br-line"></div>
                </div>
            <?php endif; ?>

            <?php if( $settings['style'] == 2 ): ?>
                <div class="uk-border">
                    <div class="uk-container">
                        <div class="uk-border"></div>
                    </div>
                </div>
            <?php endif; ?>
        <?php
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Separator );