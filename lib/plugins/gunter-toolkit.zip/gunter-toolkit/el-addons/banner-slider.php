<?php
/**
 * Banner Slider Widget
 */

namespace Elementor;
class Gunter_Slider extends Widget_Base {

	public function get_name() {
        return 'Gunter_Slider';
    }

	public function get_title() {
        return __( 'Banner Slider', 'gunter-toolkit' );
    }

	public function get_icon() {
        return 'eicon-slides';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'Gunter_Slider_Area',
			[
				'label' => __( 'Gunter Banner Slider Controls', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );
            $this->add_control(
                'section_version',
                [
                    'label' => __( 'Select Version', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'dark'      => __( 'Dark', 'gunter-toolkit' ),
                        'light'     => __( 'Light', 'gunter-toolkit' ),
                    ],
                    'default' => 'dark',
                ]
            );

            $repeater = new Repeater();

            $repeater->add_control(
                'title',
                [
                    'label' => esc_html__( 'Title', 'tryo-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Innovation for success', 'gunter-toolkit'),
                ]
            );

            $repeater->add_control(
                'description',
                [
                    'label' => esc_html__( 'Description', 'tryo-toolkit' ),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => __('We trust on innovation and that help us to succeed in future! Our team is innovative and interested to learn your project to offer the best solutions from out of the box!', 'gunter-toolkit'),
                ]
            );

            $repeater->add_control(
                'image',
                [
                    'label' => esc_html__( 'Slider Image', 'tryo-toolkit' ),
                    'type' => Controls_Manager::MEDIA,
                    'label_block' => true,
                ]
            );

            $repeater->add_control(
                'button_text',
                [
                    'label' => __( 'Button Text', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Get Started', 'gunter-toolkit'),
                ]
            );

            $repeater->add_control(
                'button_link',
                [
                    'label' => __( 'Button Link', 'gunter-toolkit' ),
                    'type' => Controls_Manager::URL,
                ]
            );

            $repeater->add_control(
                'video_button_text',
                [
                    'label' => __( 'Video Button Text', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Watch Video', 'gunter-toolkit'),
                ]
            );

            $repeater->add_control(
                'video_button_link',
                [
                    'label' => __( 'Button Link', 'gunter-toolkit' ),
                    'type' => Controls_Manager::URL,
                ]
            );

            $this->add_control(
                'sliders',
                [
                    'label' => esc_html__( 'Add Slider item', 'tryo-toolkit' ),
                    'type' => Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
			'slider_style',
			[
				'label' => __( 'Style', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );
            $this->add_control(
                'main',
                [
                    'label' => __( 'Section Main Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .main-banner-content h2::before, .main-banner-content .uk-button::before, .main-banner-content .uk-button::after' => 'background: {{VALUE}}',
                        '{{WRAPPER}} .main-banner-content .uk-button-default, .main-banner-slider button.owl-next, .main-banner-slider button.owl-prev' => 'background-color: {{VALUE}} !important',
                        '{{WRAPPER}} .main-banner-content .uk-button-default, .main-banner-content .video-btn .uk-icon' => 'border-color: {{VALUE}}',
                        '{{WRAPPER}} .main-banner-content .video-btn .uk-icon, .main-banner-content .video-btn:hover' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'title_color',
                [
                    'label' => __( 'Title Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .main-banner-content h2' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'title_size',
                [
                    'label' => __( 'Title Font Size', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 100,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .main-banner-content h2' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'content_color',
                [
                    'label' => __( 'Description Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .main-banner-content p' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'content_size',
                [
                    'label' => __( 'Description Font Size', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 50,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .main-banner-content p' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_responsive_control(
                'button_size',
                [
                    'label' => __( 'Button Text Font Size', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 50,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .main-banner-content .uk-button, .main-banner-content .video-btn' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        $dark = 'uk-dark';

        ?>
        <div class="main-banner-slider <?php if( $settings['section_version'] == 'dark' ){ echo esc_attr( $dark ); } ?> owl-carousel owl-theme">
            <?php foreach( $settings['sliders'] as $item ): ?>
                <div class="uk-banner main-banner" style="background-image:url(<?php echo esc_url( $item['image']['url'] ); ?>);">
                    <div class="d-table">
                        <div class="d-table-cell">
                            <div class="uk-container">
                                <div class="main-banner-content">
                                    <h2><?php echo wp_kses_post( $item['title'] ); ?></h2>
                                    <p><?php echo wp_kses_post( $item['description'] ); ?></p>
                                    <div class="banner-btn">
                                        <?php if( $item['button_text'] != '' ): ?>
                                            <a href="<?php echo esc_url( $item['button_link']['url'] ); ?>" class="uk-button uk-button-default"><?php echo wp_kses_post( $item['button_text'] ); ?></a>
                                        <?php endif; ?>
                                        <?php if( $item['video_button_text'] != '' ): ?>
                                            <a href="<?php echo esc_url( $item['video_button_link']['url'] ); ?>" class="video-btn popup-youtube">
                                                <span data-uk-icon="play"></span>
                                                <?php echo wp_kses_post( $item['video_button_text'] ); ?>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Slider );