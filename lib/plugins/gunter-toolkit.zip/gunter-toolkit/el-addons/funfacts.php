<?php
/**
 * Funfacts Widget
 */

namespace Elementor;
class Gunter_Funfacts extends Widget_Base {

	public function get_name() {
        return 'Gunter_Funfacts';
    }

	public function get_title() {
        return __( 'Funfacts', 'gunter-toolkit' );
    }

	public function get_icon() {
        return 'eicon-counter';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'funfacts_section',
			[
				'label' => __( 'Funfacts Control', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );
            $this->add_control(
                'background_image',
                [
                    'label' => __( 'Background Image', 'gunter-toolkit' ),
                    'type' => Controls_Manager::MEDIA,
                ]
            );

            $repeater = new Repeater();

            $repeater->add_control(
                'number',
                [
                    'type'    => Controls_Manager::NUMBER,
                    'label'   => esc_html__( 'Ending Number', 'gunter-toolkit' ),
                    'default' => 499,
                ]
            );

            $repeater->add_control(
                'title',
                [
                    'type'    => Controls_Manager::TEXT,
                    'label'   => esc_html__( 'Title', 'gunter-toolkit' ),
                    'default' => esc_html__('Satisfied Clients', 'gunter-toolkit'),
                ]
            );

            $repeater->add_control(
                'font-type',
                [
                    'label' => __( 'Font Type', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'fontawesome'      => __( 'Font Awesome', 'gunter-toolkit' ),
                        'custom_class'     => __( 'Uikit Font Class Name', 'gunter-toolkit' ),
                    ],
                    'default' => 'fontawesome',
                ]
            );
            $repeater->add_control(
                'font-awesome',
                [
                    'label' => __( 'Font Awesome Icon', 'gunter-toolkit' ),
                    'type' => Controls_Manager::ICON,
                    'condition' => [
                        'font-type' => ['fontawesome'],
                    ],
                ]
            );
            $repeater->add_control(
                'custom_icon',
                [
                    'label' => __( 'Uikit Font Class Name', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'condition' => [
                        'font-type' => ['custom_class'],
                    ],
                ]
            );
            $this->add_control(
                'items',
                [
                    'label'   => esc_html__( 'Add Counter Item', 'gunter-toolkit' ),
                    'type' => Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
			'counter_style',
			[
				'label' => __( 'Style', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

            $this->add_control(
                'counter_color',
                [
                    'label' => __( 'Number Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .funfacts-box h3' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
				'number_size',
				[
					'label' => __( 'Number Font Size', 'gunter-toolkit' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 70,
							'step' => 1,
						],
					],
					'devices' => [ 'desktop', 'tablet', 'mobile' ],
					'selectors' => [
						'{{WRAPPER}} .funfacts-box h3' => 'font-size: {{SIZE}}px;',
					],
				]
			);

            $this->add_control(
				'title_color',
				[
					'label' => __( 'Title Color', 'gunter-toolkit' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .funfacts-box p' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_responsive_control(
				'title_size',
				[
					'label' => __( 'Title Font Size', 'gunter-toolkit' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 70,
							'step' => 1,
						],
					],
					'devices' => [ 'desktop', 'tablet', 'mobile' ],
					'selectors' => [
						'{{WRAPPER}} .funfacts-box p' => 'font-size: {{SIZE}}px;',
					],
				]
            );

            $this->add_control(
				'icon_color',
				[
					'label' => __( 'Icon Color', 'gunter-toolkit' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .single-funfacts .icon' => 'color: {{VALUE}}',
					],
				]
			);

			$this->add_responsive_control(
				'icon_size',
				[
					'label' => __( 'Icon Font Size', 'gunter-toolkit' ),
					'type' => Controls_Manager::SLIDER,
					'size_units' => [ 'px' ],
					'range' => [
						'px' => [
							'min' => 1,
							'max' => 70,
							'step' => 1,
						],
					],
					'devices' => [ 'desktop', 'tablet', 'mobile' ],
					'selectors' => [
						'{{WRAPPER}} .single-funfacts .icon' => 'font-size: {{SIZE}}px;',
					],
				]
			);

        $this->end_controls_section();
    }

	protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <div class="funfacts-area uk-section uk-funfacts" style="background-image:url(<?php echo esc_url( $settings['background_image']['url'] ); ?>);">
            <div class="uk-container">
                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-4@m uk-child-width-1-2@s">
                    <?php foreach( $settings['items'] as $item ): ?>
                        <?php

                        // Icon Class
                        if( $item['font-type'] == 'fontawesome' ):
                            $icon = $item['font-awesome'];
                        else:
                            $icon = $item['custom_icon'];
                        endif;
                        ?>
                        <div class="item">
                            <div class="single-funfacts">
                                <div class="icon">
                                    <?php if( $item['font-type'] == 'fontawesome' ): ?>
                                        <i class="<?php echo esc_attr( $icon ); ?>"></i>
                                    <?php else: ?>
                                        <i uk-icon="<?php echo esc_attr( $icon ); ?>"></i>
                                    <?php endif; ?>
                                </div>
                                <h3 class="odometer" data-count="<?php echo esc_attr( $item['number'] ); ?>">00</h3>
                                <p><?php echo wp_kses_post( $item['title'] ); ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php
	}}

Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Funfacts );