<?php
/**
 * Feature Box Widget
 */

namespace Elementor;
class Gunter_Feature_Box extends Widget_Base {

	public function get_name() {
        return 'Feature_Box';
    }

	public function get_title() {
        return __( 'FeatureBox', 'gunter-toolkit' );
    }

	public function get_icon() {
        return 'eicon-favorite';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'Gunter_Feature_Box',
			[
				'label' => __( 'Feature Box Control', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

            $this->add_control(
                'active',
                [
                    'label' => __( 'Enable Active Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => __( 'Yes', 'gunter-toolkit' ),
                    'label_off' => __( 'No', 'gunter-toolkit' ),
                    'return_value' => 'yes',
                    'default' => 'no',
                ]
            );

            $this->add_control(
                'icon_type',
                [
                    'label' => __( 'Icon Type', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'fi'        => __( 'Flat Icon', 'gunter-toolkit' ),
                        'fa'        => __( 'Font Awesome', 'gunter-toolkit' ),
                    ],
                    'default' => 'fi',
                ]
            );

            $this->add_control(
                'fl_icon',
                [
                    'label' => __( 'Flat Icon', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'flaticon-quality'              => 'Quality',
                        'flaticon-domain-registration'  => 'Domain Registration',
                        'flaticon-targeting'            => 'Targeting',
                        'flaticon-search-engine'        => 'Search Engine',
                        'flaticon-idea'                 => 'Idea',
                        'flaticon-pay-per-click'        => 'Pay Per Click',
                        'flaticon-analytics-1'          => 'Analytics 1',
                        'flaticon-analytics-2'          => 'Analytics 2',
                        'flaticon-link'                 => 'Link',
                        'flaticon-translation'          => 'Translation',
                        'flaticon-bug'                  => 'Bug',
                        'flaticon-mail'                 => 'Mail',
                        'flaticon-magnifying-glass'     => 'Magnifying Glass',
                        'flaticon-think'                => 'Think',
                        'flaticon-shout'                => 'Shout',
                        'flaticon-ux-design'            => 'UX Design',
                        'flaticon-camera'               => 'Camera',
                        'flaticon-data'                 => 'Data',
                        'flaticon-chat'                 => 'Chat',
                        'flaticon-stats'                => 'Stats',
                        'flaticon-project'              => 'Project',
                        'flaticon-quote'                => 'Quote',
                        'flaticon-facebook'             => 'Facebook',
                        'flaticon-instagram'            => 'Instagram',
                        'flaticon-twitter'              => 'Twitter',
                        'flaticon-linkedin'             => 'Linkedin',
                        'flaticon-down-arrow'           => 'Down Arrow',
                        'flaticon-back'                 => 'Back',
                        'flaticon-multimedia'           => 'Multimedia',
                        'flaticon-search'               => 'Search',
                        'flaticon-edit'                 => 'Edit',
                        'flaticon-plus'                 => 'Plus',
                        'flaticon-line'                 => 'Line',
                        'flaticon-tick'                 => 'Tick',
                        'flaticon-chevron'              => 'Chevron',
                    ],
                    'default' => 'flaticon-quality',
                    'condition' => [
                        'icon_type' => 'fi',
                    ],
                ]
            );

            $this->add_control(
                'fa_icon',
                [
                    'label' => __( 'Font Awesome', 'gunter-toolkit' ),
                    'type' => Controls_Manager::ICON,
                    'condition' => [
                        'icon_type' => 'fa'
                    ]
                ]
            );

            $this->add_control(
                'title',
                [
                    'label' => __( 'Title', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Email Marketing', 'gunter-toolkit'),
                ]
            );

            $this->add_control(
                'desc',
                [
                    'label' => __( 'Description', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => esc_html__("Risus commodo maecenas accumsan lacus vel facilisis. Lorem ipsum dolor consectetur adipiscing elit.", "gunter-toolkit"),
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
			'style',
			[
				'label' => __( 'Style', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

            $this->add_control(
                'show_shape',
                [
                    'label' => __( 'Shape Images', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'gunter-toolkit' ),
                    'label_off' => __( 'Hide', 'gunter-toolkit' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );

            $this->add_control(
                'show_hover_shape',
                [
                    'label' => __( 'Hover Shape Images', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'gunter-toolkit' ),
                    'label_off' => __( 'Hide', 'gunter-toolkit' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );

            $this->add_control(
                'main_color',
                [
                    'label' => __( 'Main Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .single-features-box .icon' => 'color: {{VALUE}}',
                        '{{WRAPPER}} .single-features-box .bar' => 'background: {{VALUE}}',
                        '{{WRAPPER}} .single-features-box:hover, .single-features-box.active' => 'background-color: {{VALUE}} !important',
                    ],
                ]
            );

            $this->add_responsive_control(
                'title_font_size',
                [
                    'label' => __( 'Title Font Size', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 100,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-features-box h3' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'title_color',
                [
                    'label' => __( 'Title Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .single-features-box h3' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'desc_font_size',
                [
                    'label' => __( 'Description Font Size', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 50,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-features-box p' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'desc_title_color',
                [
                    'label' => __( 'Description Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .single-features-box p' => 'color: {{VALUE}}',
                    ],
                ]
            );

        $this->end_controls_section();
    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        global $opt_name;
		if( isset( $opt_name['enable_lazyloader'] ) ):
			$is_lazyloader = $opt_name['enable_lazyloader'];
		else:
			$is_lazyloader = true;
		endif;

        $this-> add_inline_editing_attributes('title','none');
        $this-> add_inline_editing_attributes('desc','none');

        $active_class = 'active';

        // Icon
        if( $settings['icon_type'] == 'fi' ):
            $icon = $settings['fl_icon'];
        else:
            $icon = $settings['fa_icon'];
        endif;

        ?>

        <div class="single-features-box <?php if( $settings['active'] == 'yes' ): echo esc_attr( $active_class ); endif; ?>">
            <div class="icon">
                <i class="<?php echo esc_attr( $icon ); ?>"></i>
            </div>
            <h3 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo wp_kses_post( $settings['title'] ); ?></h3>
            <div class="bar"></div>
            <p <?php echo $this-> get_render_attribute_string('desc'); ?>><?php echo wp_kses_post( $settings['desc'] ); ?></p>

            <?php if( $settings['show_shape'] == 'yes' ): ?>
                <div class="dot-img">
                    <?php if( $is_lazyloader == true ): ?>
                        <img class="smartify color-dot" sm-src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/dot.png') ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                        <img class="smartify white-dot" sm-src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/white-dot.png') ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                    <?php else: ?>
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/dot.png') ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>" class="color-dot">
                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/white-dot.png') ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>" class="white-dot">
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php if( $settings['show_hover_shape'] == 'yes' ): ?>
                <div class="animation-img">
                    <?php if( $is_lazyloader == true ): ?>
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape1.svg'); ?>" alt="<?php echo esc_attr__( 'shape-image', 'gunter-toolkit'); ?>">
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg'); ?>" alt="<?php echo esc_attr__( 'shape-image', 'gunter-toolkit'); ?>">
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape3.svg'); ?>" alt="<?php echo esc_attr__( 'shape-image', 'gunter-toolkit'); ?>">
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape1.svg'); ?>" alt="<?php echo esc_attr__( 'shape-image', 'gunter-toolkit'); ?>">
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg'); ?>" alt="<?php echo esc_attr__( 'shape-image', 'gunter-toolkit'); ?>">
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape3.svg'); ?>" alt="<?php echo esc_attr__( 'shape-image', 'gunter-toolkit'); ?>">
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape1.svg'); ?>" alt="<?php echo esc_attr__( 'shape-image', 'gunter-toolkit'); ?>">
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg'); ?>" alt="<?php echo esc_attr__( 'shape-image', 'gunter-toolkit'); ?>">
                        <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape3.svg'); ?>" alt="<?php echo esc_attr__( 'shape-image', 'gunter-toolkit'); ?>">
                    <?php else: ?>
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape1.svg'); ?>" alt="<?php echo esc_attr__( 'shape-image', 'gunter-toolkit'); ?>">
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg'); ?>" alt="<?php echo esc_attr__( 'shape-image', 'gunter-toolkit'); ?>">
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape3.svg'); ?>" alt="<?php echo esc_attr__( 'shape-image', 'gunter-toolkit'); ?>">
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape1.svg'); ?>" alt="<?php echo esc_attr__( 'shape-image', 'gunter-toolkit'); ?>">
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg'); ?>" alt="<?php echo esc_attr__( 'shape-image', 'gunter-toolkit'); ?>">
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape3.svg'); ?>" alt="<?php echo esc_attr__( 'shape-image', 'gunter-toolkit'); ?>">
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape1.svg'); ?>" alt="<?php echo esc_attr__( 'shape-image', 'gunter-toolkit'); ?>">
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape2.svg'); ?>" alt="<?php echo esc_attr__( 'shape-image', 'gunter-toolkit'); ?>">
                        <img src="<?php echo esc_url(get_template_directory_uri().'/assets/img/shape3.svg'); ?>" alt="<?php echo esc_attr__( 'shape-image', 'gunter-toolkit'); ?>">
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
	}}

Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Feature_Box );