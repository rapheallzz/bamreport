<?php
/**
 * Work Process Widget
 */

namespace Elementor;
class Gunter_Work_Process extends Widget_Base {

	public function get_name() {
        return 'Gunter_Work_Process';
    }

	public function get_title() {
        return __( 'Work Process', 'gunter-toolkit' );
    }

	public function get_icon() {
        return 'eicon-animation';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'Gunter_Work_Process',
			[
				'label' => __( 'Work Process Control', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
            'shape_image',
            [
                'label' => __( 'Shape Images', 'gunter-toolkit' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'gunter-toolkit' ),
                'label_off' => __( 'Hide', 'gunter-toolkit' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'icon_type',
            [
                'label' => __( 'Icon Type', 'holab-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'font-awesome'   => __( 'Font Awesome', 'holab-toolkit' ),
                    'uikit'         => __( 'Uikit Icon Class Name', 'holab-toolkit' ),
                ],
                'default' => 'font-awesome',
            ]
        );
        $repeater->add_control(
            'fa_icon',
            [
                'label' => __( 'Font-Awesome', 'gunter-toolkit' ),
                'type' => Controls_Manager::ICON,
                'condition' => [
                    'icon_type' => ['font-awesome'],
                ],
            ]
        );
        $repeater->add_control(
            'uikit_icon',
            [
                'label' => __( 'Uikit Icon Class Name', 'gunter-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'condition' => [
                    'icon_type' => ['uikit'],
                ],
            ]
        );
        $repeater->add_control(
            'title',
            [
                'label' => __( 'Title', 'gunter-toolkit' ),
                'type' => Controls_Manager::TEXT,
            ]
        );
        $repeater->add_control(
            'content',
            [
                'label' => __( 'Content', 'gunter-toolkit' ),
                'type' => Controls_Manager::TEXTAREA,
            ]
        );

        $this->add_control(
            'card_item',
            [
                'label' => esc_html__('Card Item', 'gunter-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
        );

        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        global $opt_name;
		if( isset( $opt_name['enable_lazyloader'] ) ):
			$is_lazyloader = $opt_name['enable_lazyloader'];
		else:
			$is_lazyloader = true;
		endif;

        ?>
        <div class="uk-container">
            <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-4@m uk-child-width-1-2@s">
                <?php foreach( $settings['card_item'] as $item ): ?>
                    <div class="item">
                        <div class="single-process-box">
                            <div class="icon">
                                <?php if( $item['icon_type'] == 'uikit'): ?>
                                    <i uk-icon="<?php echo esc_attr( $item['uikit_icon'] ); ?>"></i>
                                <?php else: ?>
                                    <i class="<?php echo esc_attr( $item['fa_icon'] ); ?>"></i>
                                <?php endif; ?>
                            </div>
                            <h3><?php echo wp_kses_post( $item['title'] ); ?></h3>
                            <p><?php echo wp_kses_post( $item['content'] ); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
                <div class="item">
                    <div class="process-arrow-icon">
                        <?php if( $is_lazyloader == true ): ?>
                            <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/arrow.png'); ?>" alt="image">
                        <?php else: ?>
                            <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/arrow.png'); ?>" alt="image">
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Work_Process );