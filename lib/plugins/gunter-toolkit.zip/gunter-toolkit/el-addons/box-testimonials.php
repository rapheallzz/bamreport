<?php
/**
 * Testimonial Box Widget
 */

namespace Elementor;
class Gunter_Testimonial_Box extends Widget_Base {

	public function get_name() {
        return 'Testimonial_Box';
    }

	public function get_title() {
        return __( 'Testimonial Box', 'gunter-toolkit' );
    }

	public function get_icon() {
        return 'eicon-testimonial';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'Gunter_Testimonial_Box',
			[
				'label' => __( 'Testimonial Box Control', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );
            $this->add_control(
                'card_style',
                [
                    'label' => __( 'Select Style', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        '1'   => __( 'Style One', 'gunter-toolkit' ),
                        '2'   => __( 'Style Two', 'gunter-toolkit' ),
                    ],
                    'default' => '1',
                ]
            );

            $this->add_control(
                'image',
                [
                    'label' => __( 'Client Image', 'gunter-toolkit' ),
                    'type' => Controls_Manager::MEDIA,
                ]
            );

            $this->add_control(
                'name',
                [
                    'label' => __( 'Name', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('David Warner', 'gunter-toolkit'),
                ]
            );

            $this->add_control(
                'designation',
                [
                    'label' => __( 'Designation', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Founder & Team Lead', 'gunter-toolkit'),
                ]
            );
            $this->add_control(
                'feedback',
                [
                    'label' => __( 'Feedback', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => esc_html__('It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.', 'gunter-toolkit'),
                ]
            );
        $this->end_controls_section();

        $this->start_controls_section(
			'style',
			[
				'label' => __( 'Style', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

            $this->add_responsive_control(
                'name_font_size',
                [
                    'label' => __( 'Name Font Size', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 100,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .testimonials-item .quotation-profile .profile-info h3, .single-feedback-item .client-info h3' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'name_color',
                [
                    'label' => __( 'Name Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .testimonials-item .quotation-profile .profile-info h3, .single-feedback-item .client-info h3' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'desc_font_size',
                [
                    'label' => __( 'Feedback Font Size', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 50,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .testimonials-item .testimonials-single-item p, .single-feedback-item p' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'desc_title_color',
                [
                    'label' => __( 'Feedback Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .testimonials-item .testimonials-single-item p, .single-feedback-item p' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'designation_color',
                [
                    'label' => __( 'Designation Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .testimonials-item .quotation-profile .profile-info span, .single-feedback-item .client-info span' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'designation_font_size',
                [
                    'label' => __( 'Designation Font Size', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 50,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .testimonials-item .quotation-profile .profile-info span, .single-feedback-item .client-info span' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

        $this->end_controls_section();
    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        global $opt_name;
		if( isset( $opt_name['enable_lazyloader'] ) ):
			$is_lazyloader = $opt_name['enable_lazyloader'];
		else:
			$is_lazyloader = true;
		endif;

        $this-> add_inline_editing_attributes('name','none');
        $this-> add_inline_editing_attributes('feedback','none');
        $this-> add_inline_editing_attributes('designation','none');

        ?>

        <?php if( $settings['card_style'] == '1' ): ?>
            <div class="testimonials-item">
                <div class="testimonials-single-item">
                    <p <?php echo $this-> get_render_attribute_string('feedback'); ?>><?php echo wp_kses_post( $settings['feedback'] ); ?></p>
                </div>

                <div class="quotation-profile">
                    <?php if( $settings['image']['url'] != '' ): ?>
                        <?php if( $is_lazyloader == true ): ?>
                            <img class="smartify" sm-src="<?php echo esc_url( $settings['image']['url'] ); ?>" alt="<?php echo esc_attr( $settings['name'] ); ?>">
                        <?php else: ?>
                            <img src="<?php echo esc_url( $settings['image']['url'] ); ?>" alt="<?php echo esc_attr( $settings['name'] ); ?>">
                        <?php endif; ?>
                    <?php endif; ?>

                    <div class="profile-info">
                        <h3 <?php echo $this-> get_render_attribute_string('name'); ?>><?php echo wp_kses_post( $settings['name'] ); ?></h3>
                        <span <?php echo $this-> get_render_attribute_string('designation'); ?>><?php echo wp_kses_post( $settings['designation'] ); ?></span>
                    </div>
                </div>
            </div>
        <?php elseif( $settings['card_style'] == '2' ): ?>
            <div class="single-feedback-item">
                <i class="flaticon-quote"></i>
                <p <?php echo $this-> get_render_attribute_string('feedback'); ?>><?php echo wp_kses_post( $settings['feedback'] ); ?></p>
                <div class="client-info">
                    <?php if( $settings['image']['url'] != '' ): ?>
                        <?php if( $is_lazyloader == true ): ?>
                            <img class="smartify" sm-src="<?php echo esc_url( $settings['image']['url'] ); ?>" alt="<?php echo esc_attr( $settings['name'] ); ?>">
                        <?php else: ?>
                            <img src="<?php echo esc_url( $settings['image']['url'] ); ?>" alt="<?php echo esc_attr( $settings['name'] ); ?>">
                        <?php endif; ?>
                    <?php endif; ?>
                    <h3 <?php echo $this-> get_render_attribute_string('name'); ?>><?php echo wp_kses_post( $settings['name'] ); ?></h3>
                    <span <?php echo $this-> get_render_attribute_string('designation'); ?>><?php echo wp_kses_post( $settings['designation'] ); ?></span>
                </div>
            </div>
        <?php endif; ?>
        <?php
	}}

Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Testimonial_Box );