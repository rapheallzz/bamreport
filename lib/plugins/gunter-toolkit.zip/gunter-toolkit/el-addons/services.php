<?php
/**
 * Services Widget
 */

namespace Elementor;
class Gunter_Services extends Widget_Base {

	public function get_name() {
        return 'Services';
    }

	public function get_title() {
        return __( 'Services', 'gunter-toolkit' );
    }

	public function get_icon() {
        return 'eicon-tools';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'services_section',
			[
				'label' => __( 'Services', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

            $this->add_control(
                'card_style',
                [
                    'label' => __( 'Select Style', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        1   => __( 'Style One', 'gunter-toolkit' ),
                        2   => __( 'Style Two', 'gunter-toolkit' ),
                        3   => __( 'Style Three', 'gunter-toolkit' ),
                        4  => __( 'Style Four', 'gunter-toolkit' ),
                        5  => __( 'Style Five', 'gunter-toolkit' ),
                        6  => __( 'Style Six', 'gunter-toolkit' ),
                    ],
                    'default' => 1,
                ]
            );

            $this->add_control(
                'top_title',
                [
                    'label' => __( 'Top Title', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __( 'WHAT WE DO', 'gunter-toolkit'  ),
                    'condition' => [
                        'card_style' => ['5','6'],
                    ],
                ]
            );

            $this->add_control(
                'title',
                [
                    'label' => __( 'Title', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __( 'Our Services', 'gunter-toolkit'  ),
                    'condition' => [
                        'card_style' => ['5','6'],
                    ],
                ]
            );

            $this->add_control(
                'image',
                [
                    'label' => __( 'Section Image', 'gunter-toolkit' ),
                    'type' => Controls_Manager::MEDIA,
                    'condition' => [
                        'card_style' => ['5','6'],
                    ],
                ]
            );

            $this->add_control(
                'cat_name',
                [
                    'label' => __( 'Choose Category', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => gunter_toolkit_get_page_services_cat_el(),
                ]
            );

            $this->add_control(
                'read_more',
                [
                    'label' => __( 'Read More Text', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __( 'Read More', 'gunter-toolkit'  ),
                    'condition' => [
                        'card_style' => '2',
                    ],
                ]
            );

            $this->add_control(
                'pagination',
                [
                    'label' => __( 'Show Pagination', 'gunter-toolkit' ),
                    'description' => __( 'Pagination Not Working On Home Page!', 'gunter-toolkit' ),
                    'type' =>Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'gunter-toolkit' ),
                    'label_off' => __( 'Hide', 'gunter-toolkit' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                    'condition' => [
                        'card_style' => '2',
                    ],
                ]
            );

            $this->add_control(
                'hover_animation',
                [
                    'label' => __( 'Show Hover Animation Images', 'gunter-toolkit' ),
                    'type' =>Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'gunter-toolkit' ),
                    'label_off' => __( 'Hide', 'gunter-toolkit' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                    'condition' => [
                        'card_style' => '2',
                    ],
                ]
            );

            $this->add_control(
                'link',
                [
                    'label' => __( 'Link', 'gunter-toolkit' ),
                    'type' =>Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'gunter-toolkit' ),
                    'label_off' => __( 'Hide', 'gunter-toolkit' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                    'condition' => [
                        'card_style' => '1',
                    ],
                ]
            );

            $this->add_control(
                'order',
                [
                    'label' => __( 'Services Order By', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'DESC'      => __( 'DESC', 'gunter-toolkit' ),
                        'ASC'       => __( 'ASC', 'gunter-toolkit' ),
                    ],
                    'default' => 'DESC',
                ]
            );

            $this->add_control(
                'count',
                [
                    'label' => __( 'Post Per Page', 'gunter-toolkit' ),
                    'type' => Controls_Manager::NUMBER,
                    'default' => 4,
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
			'service_style',
			[
				'label' => __( 'Style', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );

            $this->add_control(
                'title_color',
                [
                    'label' => __( 'Title Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .single-services h3, .single-services-box h3 a, .services-box .content h3' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'title_size',
                [
                    'label' => __( 'Title Font Size', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 100,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-services h3, .single-services-box h3, .services-box .content h3' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
                'content_color',
                [
                    'label' => __( 'Content Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .single-services-box p, .single-services-box p, .services-box .hover-content .inner p' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'content_size',
                [
                    'label' => __( 'Content Font Size', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 50,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-services-box p, .single-services-box p, .services-box .hover-content .inner p' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        global $opt_name;
		if( isset( $opt_name['enable_lazyloader'] ) ):
			$is_lazyloader = $opt_name['enable_lazyloader'];
		else:
			$is_lazyloader = true;
        endif;

        $args = array(
            'post_type'         => 'service',
            'posts_per_page'    => $settings['count'],
            'order'             => $settings['order'],
            'paged' => get_query_var('paged') ? get_query_var('paged') : 1
        );
        // Services Query
        if( $settings['cat_name'] != '' ) {
            $args = array(
                'post_type'     => 'service',
                'posts_per_page'=> $settings['count'],
                'order'         => $settings['order'],
                'tax_query'     => array(
                    array(
                        'taxonomy'      => 'service_cat',
                        'field'         => 'slug',
                        'terms'         => $settings['cat_name'],
                        'hide_empty'    => false
                    )
                ),
                'paged' => get_query_var('paged') ? get_query_var('paged') : 1
            );
        } else {
            $args = array(
                'post_type'         => 'service',
                'posts_per_page'    => $settings['count'],
                'order'             => $settings['order'],
                'paged' => get_query_var('paged') ? get_query_var('paged') : 1
            );
        }
        $services_array = new \WP_Query( $args );
        ?>

        <?php if( $settings['card_style']  == 1 ): ?>
            <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s">
                <?php
                while($services_array->have_posts()):  $services_array->the_post();

                    // ACF Fields
                    $act = get_field( "service_card_active" );
                    $icon = get_field( "select_flat_icon" );

                    // Post Link
                    if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
                        $post_link = get_the_permalink();
                    } else {
                        $post_link = get_field('external_link');
                    }

                    $active_class = '';
                    if( !$act == false ):
                        $active_class = 'active';
                    endif;
                    ?>
                    <div class="item">
                        <div class="single-services <?php echo esc_attr( $active_class ); ?>">
                            <div class="icon">
                                <i class="<?php echo esc_attr( $icon ); ?>"></i>
                            </div>
                            <h3><?php the_title(); ?></h3>
                            <?php if( $settings['link'] == 'yes' ): ?>
                                <i class="flaticon-right link-btn"></i>
                                <a href="<?php echo esc_url( $post_link ); ?>" class="link uk-position-cover"></a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endwhile; ?>
                <?php wp_reset_query(); ?>
            </div>
        <?php endif; ?>

        <?php if( $settings['card_style']  == 2 ): ?>
            <div class="services-area uk-services uk-section">
                <div class="uk-container">
                    <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s">
                    <?php

                    while($services_array->have_posts()): $services_array->the_post();
                        $idd = get_the_ID();
                        $title = get_the_title($idd);
                        $act = get_field( "service_card_active" );
                        $icon = get_field( "select_flat_icon" );

                        // Post Link
                        if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
                            $post_link = get_the_permalink();
                        } else {
                            $post_link = get_field('external_link');
                        }

                        if(!$title == ''){ ?>
                            <div class="item">
                                <div class="single-services-box">
                                    <div class="icon">
                                        <i class="<?php echo esc_attr( $icon); ?>"></i>
                                    </div>
                                    <h3><a href="<?php echo esc_url( $post_link ); ?>"><?php echo wp_kses_post( get_the_title($idd)); ?></a></h3>
                                    <div class="bar"></div>
                                    <p><?php echo wp_kses_post(get_the_excerpt()); ?></p><?php
                                    if($settings['read_more']){ ?>
                                        <a href="<?php echo esc_url( $post_link ); ?>" class="link-btn"><span><?php echo wp_kses_post($settings['read_more'], 'gunter-toolkit'); ?></span> <i class="flaticon-right"></i></a><?php
                                    }

                                    if($settings['hover_animation'] == 'yes'){ ?>
                                        <div class="animation-img">
                                            <?php if( $is_lazyloader == true ): ?>
                                                <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape1.svg'); ?>" alt="<?php echo esc_attr__('shape-image'); ?>">
                                                <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape2.svg'); ?>" alt="<?php echo esc_attr__('shape-image'); ?>">
                                                <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape3.svg'); ?>" alt="<?php echo esc_attr__('shape-image'); ?>">
                                                <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape1.svg'); ?>" alt="<?php echo esc_attr__('shape-image'); ?>">
                                                <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape2.svg'); ?>" alt="<?php echo esc_attr__('shape-image'); ?>">
                                                <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape3.svg'); ?>" alt="<?php echo esc_attr__('shape-image'); ?>">
                                                <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape1.svg'); ?>" alt="<?php echo esc_attr__('shape-image'); ?>">
                                                <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape2.svg'); ?>" alt="<?php echo esc_attr__('shape-image'); ?>">
                                                <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape3.svg'); ?>" alt="<?php echo esc_attr__('shape-image'); ?>">
                                            <?php else: ?>
                                                <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape1.svg'); ?>" alt="<?php echo esc_attr__('shape-image'); ?>">
                                                <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape2.svg'); ?>" alt="<?php echo esc_attr__('shape-image'); ?>">
                                                <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape3.svg'); ?>" alt="<?php echo esc_attr__('shape-image'); ?>">
                                                <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape1.svg'); ?>" alt="<?php echo esc_attr__('shape-image'); ?>">
                                                <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape2.svg'); ?>" alt="<?php echo esc_attr__('shape-image'); ?>">
                                                <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape3.svg'); ?>" alt="<?php echo esc_attr__('shape-image'); ?>">
                                                <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape1.svg'); ?>" alt="<?php echo esc_attr__('shape-image'); ?>">
                                                <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape2.svg'); ?>" alt="<?php echo esc_attr__('shape-image'); ?>">
                                                <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape3.svg'); ?>" alt="<?php echo esc_attr__('shape-image'); ?>">
                                            <?php endif; ?>
                                        </div><?php
                                    } ?>
                                </div>
                            </div><?php
                        }
                        endwhile;
                        ?>
                    </div><?php
                    $pagin    = 999999999;
                    $pageLinks  =  paginate_links( array(
                        "base"      => str_replace( $pagin, "%#%", get_pagenum_link( $pagin ) ),
                        "format"    => "?paged=%#%",
                        "current"   => max( 1, get_query_var("paged") ),
                        "total"     => $services_array->max_num_pages,
                        "prev_text" => __("<span class='flaticon-back'></span>","gunter-toolkit"),
                        "next_text" => __("<span class='flaticon-right'>","gunter-toolkit"),
                        "type"      => "list",
                    ) );

                if(!is_front_page() && !is_home() && $settings['pagination'] == 'yes'){
                    ?>
                    <div class="custom-pagination-area">
                        <?php echo wp_kses_post($pageLinks, 'gunter-toolkit'); ?>
                    </div><?php
                }
                wp_reset_query();
                ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if( $settings['card_style']  == 3 ): ?>
            <div class="uk-container">
                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s">
                    <?php
                    while($services_array->have_posts()): $services_array->the_post();
                        $idd = get_the_ID();
                        $title = get_the_title($idd);
                        $act = get_field( "service_card_active" );
                        $icon = get_field( "select_flat_icon" );

                        // Post Link
                        if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
                            $post_link = get_the_permalink();
                        } else {
                            $post_link = get_field('external_link');
                        }
                    ?>
                        <div class="item">
                            <div class="services-box">
                                <?php the_post_thumbnail( 'gunter_service_single' ); ?>

                                <div class="content">
                                    <div class="icon">
                                        <i class="<?php echo esc_attr( $icon); ?>"></i>
                                    </div>
                                    <h3><?php echo wp_kses_post( get_the_title($idd)); ?></h3>
                                </div>

                                <div class="hover-content">
                                    <div class="d-table">
                                        <div class="d-table-cell">
                                            <div class="inner">
                                                <div class="icon">
                                                    <i class="<?php echo esc_attr( $icon); ?>"></i>
                                                </div>
                                                <h3><?php echo wp_kses_post( get_the_title($idd)); ?></h3>
                                                <p><?php the_excerpt(); ?></p>
                                                <a href="<?php echo esc_url( $post_link ); ?>" class="details-btn"><i class="flaticon-right"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                    <?php wp_reset_query(); ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if( $settings['card_style']  == 4 ): ?>
            <div class="uk-container">
                <div class="services-slides owl-carousel owl-theme">
                    <?php
                    while($services_array->have_posts()): $services_array->the_post();
                        $idd   = get_the_ID();
                        $title = get_the_title($idd);
                        $act   = get_field( "service_card_active" );
                        $icon  = get_field( "select_flat_icon" );

                        // Post Link
                        if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
                            $post_link = get_the_permalink();
                        } else {
                            $post_link = get_field('external_link');
                        }
                    ?>
                        <div class="services-box">
                            <?php the_post_thumbnail( 'gunter_service_single' ); ?>

                            <div class="content">
                                <div class="icon">
                                    <i class="<?php echo esc_attr( $icon); ?>"></i>
                                </div>
                                <h3><?php echo wp_kses_post( get_the_title($idd)); ?></h3>
                            </div>

                            <div class="hover-content">
                                <div class="d-table">
                                    <div class="d-table-cell">
                                        <div class="inner">
                                            <div class="icon">
                                                <i class="<?php echo esc_attr( $icon); ?>"></i>
                                            </div>
                                            <h3><?php echo wp_kses_post( get_the_title($idd)); ?></h3>
                                            <p><?php the_excerpt(); ?></p>
                                            <a href="<?php echo esc_url( $post_link ); ?>" class="details-btn"><i class="flaticon-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                    <?php wp_reset_query(); ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if( $settings['card_style']  == 5 ): ?>
            <div class="what-we-do-section uk-what-we-do">
                <div class="uk-container-expand">
                    <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
                        <div class="item">
                            <?php if( $settings['image']['url'] != '' ): ?>
                                <div class="what-we-do-image" style="background-image:url(<?php echo esc_url( $settings['image']['url']  );  ?>);">
                                    <img src="<?php echo esc_url( $settings['image']['url']  );  ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="item">
                            <div class="what-we-do-content">
                                <div class="content">
                                    <div class="uk-section-title section-title">
                                        <span><?php echo wp_kses_post( $settings['top_title'] ); ?></span>
                                        <h2><?php echo wp_kses_post( $settings['title'] ); ?></h2>
                                        <div class="bar"></div>
                                    </div>
                                    <?php
                                    while($services_array->have_posts()): $services_array->the_post();
                                        $idd   = get_the_ID();
                                        $title = get_the_title($idd);
                                        $act   = get_field( "service_card_active" );
                                        $icon  = get_field( "select_flat_icon" );

                                        // Post Link
                                        if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
                                            $post_link = get_the_permalink();
                                        } else {
                                            $post_link = get_field('external_link');
                                        }
                                    ?>
                                        <div class="single-services">
                                            <div class="icon">
                                                <i class="<?php echo esc_attr( $icon); ?>"></i>
                                            </div>
                                            <h3><?php echo wp_kses_post( get_the_title($idd)); ?></h3>
                                            <i class="flaticon-right link-btn"></i>
                                            <a href="<?php echo esc_url( $post_link ); ?>" class="link uk-position-cover"></a>
                                        </div>
                                    <?php endwhile; ?>
                                    <?php wp_reset_query(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if( $settings['card_style']  == 6 ): ?>
            <div class="experience-area uk-experience">
                <div class="uk-container-expand">
                    <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
                        <div class="item">
                            <div class="experience-content">
                                <div class="content">
                                    <div class="uk-section-title section-title">
                                        <span><?php echo wp_kses_post( $settings['top_title'] ); ?></span>
                                        <h2><?php echo wp_kses_post( $settings['title'] ); ?></h2>
                                        <div class="bar"></div>
                                    </div>

                                    <?php
                                    while($services_array->have_posts()): $services_array->the_post();
                                        $idd   = get_the_ID();
                                        $title = get_the_title($idd);
                                        $act   = get_field( "service_card_active" );
                                        $icon  = get_field( "select_flat_icon" );

                                        // Post Link
                                        if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
                                            $post_link = get_the_permalink();
                                        } else {
                                            $post_link = get_field('external_link');
                                        }
                                    ?>
                                        <div class="single-experience-box">
                                            <div class="icon">
                                                <i class="<?php echo esc_attr( $icon); ?>"></i>
                                            </div>
                                            <h3><?php echo wp_kses_post( get_the_title($idd)); ?></h3>
                                            <p><?php the_excerpt(); ?></p>
                                        </div>
                                    <?php endwhile; ?>
                                    <?php wp_reset_query(); ?>

                                </div>
                            </div>
                        </div>

                        <div class="item">
                            <?php if( $settings['image']['url'] != '' ): ?>
                                <div class="experience-image" style="background-image:url(<?php echo esc_url( $settings['image']['url']  );  ?>);">
                                    <img src="<?php echo esc_url( $settings['image']['url']  );  ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Services );