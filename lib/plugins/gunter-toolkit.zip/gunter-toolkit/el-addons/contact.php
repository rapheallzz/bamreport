<?php
/**
 * Contact Widget
 */

namespace Elementor;
class Gunter_Contact extends Widget_Base {

	public function get_name() {
        return 'Contact';
    }

	public function get_title() {
        return __( 'Contact', 'gunter-toolkit' );
    }

	public function get_icon() {
        return 'eicon-handle';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'Gunter_Contact',
			[
				'label' => __( 'Gunter Contact', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
            $this->add_control(
                'version',
                [
                    'label' => __( 'Select Version', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'dark'      => __( 'Dark', 'gunter-toolkit' ),
                        'light'     => __( 'Light', 'gunter-toolkit' ),
                    ],
                    'default' => 'dark',
                ]
            );

            $this->add_control(
                'location_one',
                [
                    'label' => __( 'Location One Title', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('New York', 'gunter-toolkit'),
                ]
            );
            $this->add_control(
                'location_one_link',
                [
                    'label' => __( 'Location One Link', 'gunter-toolkit' ),
                    'type' => Controls_Manager::URL,
                ]
            );
            $this->add_control(
                'location_one_desc',
                [
                    'label' => __( 'Location One Short Content', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('198 Collective Street', 'gunter-toolkit'),
                ]
            );

            $this->add_control(
                'location_two',
                [
                    'label' => __( 'Location Two Title', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('London', 'gunter-toolkit'),
                ]
            );
            $this->add_control(
                'location_two_link',
                [
                    'label' => __( 'Location Two Link', 'gunter-toolkit' ),
                    'type' => Controls_Manager::URL,
                ]
            );
            $this->add_control(
                'location_two_desc',
                [
                    'label' => __( 'Location Two Short Content', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('357/71 Collective Street', 'gunter-toolkit'),
                ]
            );

            $this->add_control(
                'contact_form',
                [
                    'label'=>esc_html__('Contact From 7 Shortcode', 'gunter-toolkit'),
                    'type'=>Controls_Manager:: TEXT,
                ]
            );

        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        global $opt_name;
		if( isset( $opt_name['enable_lazyloader'] ) ):
			$is_lazyloader = $opt_name['enable_lazyloader'];
		else:
			$is_lazyloader = true;
		endif; ?>

        <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
            <div class="item">
                <div class="map-img">
                    <?php if( $settings['version'] == 'dark' ): ?>
                        <?php if( $is_lazyloader == true ): ?>
                            <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/map2.png'); ?>" alt="<?php echo esc_attr__('map', 'gunter-toolkit'); ?>">
                        <?php else: ?>
                            <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/map2.png'); ?>" alt="<?php echo esc_attr__('map', 'gunter-toolkit'); ?>">
                        <?php endif; ?>
                    <?php else:?>
                        <?php if( $is_lazyloader == true ): ?>
                            <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/map.png'); ?>" alt="<?php echo esc_attr__('map', 'gunter-toolkit'); ?>">
                        <?php else: ?>
                            <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/map.png'); ?>" alt="<?php echo esc_attr__('map', 'gunter-toolkit'); ?>">
                        <?php endif; ?>
                    <?php endif;?>

                    <?php if( $settings['location_one'] != '' &&   $settings['location_one_desc'] != '' ): ?>
                        <div class="location uk-location1">
                            <a href="<?php echo esc_url( $settings['location_one_link']['url'] ); ?>" class="active">
                                <div class="location-info">
                                    <h5><?php echo wp_kses_post( $settings['location_one'] ); ?></h5>
                                    <span><?php echo wp_kses_post( $settings['location_one_desc'] ); ?></span>
                                </div>
                            </a>
                        </div>
                    <?php endif; ?>

                    <?php if( $settings['location_two'] != '' &&   $settings['location_two_desc'] != '' ): ?>
                        <div class="location uk-location2">
                            <a href="<?php echo esc_url( $settings['location_two_link']['url'] ); ?>">
                                <div class="location-info">
                                    <h5><?php echo wp_kses_post( $settings['location_two'] ); ?></h5>
                                    <span><?php echo wp_kses_post( $settings['location_two_desc'] ); ?></span>
                                </div>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="item">
                <?php echo do_shortcode( $settings['contact_form'] ); ?>
            </div>
        </div>
        <?php
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Contact );