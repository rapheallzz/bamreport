<?php
/**
 * Partner Widget
 */

namespace Elementor;
class Gunter_Partner extends Widget_Base {

	public function get_name() {
        return 'Gunter_Partner';
    }

	public function get_title() {
        return __( 'Partner', 'gunter-toolkit' );
    }

	public function get_icon() {
        return 'eicon-logo';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'Gunter_Partner',
			[
				'label' => __( 'Partner Control', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

        $this->add_control(
            'style',
            [
                'label' => __( 'Select Style', 'gunter-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    1      => __( 'One', 'gunter-toolkit' ),
                    2     => __( 'Two', 'gunter-toolkit' ),
                ],
                'default' => 1,
            ]
        );

        $this->add_control(
            'top_title',
            [
                'label' => __( 'Top Title', 'gunter-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'OUR CLIENTS', 'gunter-toolkit'  ),
                'condition' => [
                    'style' => ['2'],
                ],
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => __( 'Title', 'gunter-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'Clients We Work', 'gunter-toolkit'  ),
                'condition' => [
                    'style' => ['2'],
                ],
            ]
        );

        $this->add_control(
            'version',
            [
                'label' => __( 'Version', 'gunter-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'dark'      => __( 'Dark', 'gunter-toolkit' ),
                    'light'     => __( 'Light', 'gunter-toolkit' ),
                ],
                'default' => 'dark',
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'logo',
            [
                'label' => __( 'Partner Logo', 'gunter-toolkit' ),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'link',
            [
                'label' => __( 'Link', 'gunter-toolkit' ),
                'type' => Controls_Manager::URL,
                'show_external' => true,
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        $this->add_control(
            'partner_item',
            [
                'label' => esc_html__('Partner Item', 'gunter-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
        );

        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        global $opt_name;
		if( isset( $opt_name['enable_lazyloader'] ) ):
			$is_lazyloader = $opt_name['enable_lazyloader'];
		else:
			$is_lazyloader = true;
		endif;

        $version = '';
        if( $settings['version'] == 'dark' ):
            $version = 'uk-dark';
        endif;

        ?>
        <?php if( $settings['style'] == 1 ): ?>
            <div class="partner-area uk-section uk-padding-remove-top <?php echo esc_attr( $version ); ?>">
                <div class="uk-container">
                    <div class="partner-slides owl-carousel owl-theme">

                        <?php foreach( $settings['partner_item'] as $item ): ?>
                            <div class="item">
                                <a href="<?php echo esc_url( $item['link']['url'] ); ?>">
                                    <?php if( $is_lazyloader == true ): ?>
                                        <img src="<?php echo esc_url( $item['logo']['url'] ); ?>" alt="<?php echo esc_attr__( 'Partner Logo', 'gunter-toolkit' ); ?>" />
                                    <?php else: ?>
                                        <img src="<?php echo esc_url( $item['logo']['url'] ); ?>" alt="<?php echo esc_attr__( 'Partner Logo', 'gunter-toolkit' ); ?>" />
                                    <?php endif; ?>
                                </a>
                            </div>
                        <?php endforeach; ?>

                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if( $settings['style'] == 2 ): ?>
            <div class="partner-area-two uk-partner uk-section bg-f5e7da">
                <div class="uk-container">
                    <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-2@s">
                        <div class="item">
                            <div class="uk-section-title section-title">
                                <span><?php echo wp_kses_post( $settings['top_title'] ); ?></span>
                                <h2><?php echo wp_kses_post( $settings['title'] ); ?></h2>
                                <div class="bar"></div>
                            </div>
                        </div>

                        <div class="item">
                            <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s">
                                <?php foreach( $settings['partner_item'] as $item ): ?>
                                    <div class="item">
                                        <div class="partner-item">
                                            <?php if( $is_lazyloader == true ): ?>
                                                <img src="<?php echo esc_url( $item['logo']['url'] ); ?>" alt="<?php echo esc_attr__( 'Partner Logo', 'gunter-toolkit' ); ?>" />
                                            <?php else: ?>
                                                <img src="<?php echo esc_url( $item['logo']['url'] ); ?>" alt="<?php echo esc_attr__( 'Partner Logo', 'gunter-toolkit' ); ?>" />
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Partner );