<?php
/**
 * Testimonial Slider Widget
 */

namespace Elementor;
class Gunter_Testimonial_Slider extends Widget_Base {

	public function get_name() {
        return 'Testimonial_Slider';
    }

	public function get_title() {
        return __( 'Testimonial Slider', 'gunter-toolkit' );
    }

	public function get_icon() {
        return 'eicon-testimonial-carousel';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );
            $this->add_control(
                'card_style',
                [
                    'label' => __( 'Version', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'dark'      => __( 'Dark', 'gunter-toolkit' ),
                        'light'     => __( 'Light', 'gunter-toolkit' ),
                    ],
                    'default' => 'dark',
                ]
            );

            $this->add_control(
                'top_title',
                [
                    'label' => __( 'Top Title', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Testimonials', 'gunter-toolkit'),
                ]
            );
            $this->add_control(
                'title',
                [
                    'label' => __( 'Title', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('What Clients Say About Us', 'gunter-toolkit'),
                ]
            );

            $repeater = new Repeater();

            $repeater->add_control(
                'image',
                [
                    'label' => esc_html__('Image', 'gunter-toolkit'),
                    'type' => Controls_Manager::MEDIA,
                ]
            );
            $repeater->add_control(
                'name',
                [
                    'label' => esc_html__('Name', 'gunter-toolkit'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Alister Cook', 'gunter-toolkit'),
                    'label_block' => true,
                ]
            );
            $repeater->add_control(
                'designation',
                [
                    'label' => esc_html__('Designation', 'gunter-toolkit'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('CTO at Envato', 'gunter-toolkit'),
                    'label_block' => true,
                ]
            );
            $repeater->add_control(
                'feedback',
                [
                    'label' => esc_html__('Feedback', 'gunter-toolkit'),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis.', 'gunter-toolkit'),
                    'label_block' => true,
                ]
            );

            $this->add_control(
                'testimonial_items',
                [
                    'label' => esc_html__('Slider Item', 'gunter-toolkit'),
                    'type' => Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                ]
            );
        $this->end_controls_section();
    }

	protected function render() {

        $settings       = $this->get_settings_for_display();

        global $opt_name;
		if( isset( $opt_name['enable_lazyloader'] ) ):
			$is_lazyloader = $opt_name['enable_lazyloader'];
		else:
			$is_lazyloader = true;
        endif;

        $slider         = $settings['testimonial_items'];
        $card_style     = $settings['card_style'];

        $dark_class = '';
        if($card_style == 'dark'){
            $dark_class = 'uk-dark';
        }

        $count = 0;
        foreach ( $slider as $value ) {
            $count++;
        } ?>

        <div class="feedback-section uk-section <?php echo esc_attr($dark_class); ?>">
            <div class="uk-container">
                <div class="uk-grid" uk-grid>
                    <div class="uk-width-1-3@m">
                        <div class="uk-section-title section-title">
                            <span><?php echo wp_kses_post( $settings['top_title'] ); ?></span>
                            <h2><?php echo wp_kses_post( $settings['title'] ); ?></h2>
                            <div class="bar"></div>
                        </div>
                    </div>

                    <div class="uk-width-expand@m">
                        <?php if( $count == 1 ) { ?>
                        <div> <?php
                        } elseif( $count == 2 ) { ?>
                        <div class="uk-container">
                            <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s"> <?php
                        } else { ?>
                        <div class="feedback-slides-two owl-carousel owl-theme">
                            <?php } ?>
                                <?php foreach( $slider as $item ): ?>
                                    <?php if( $count == 2 ) { ?>
                                        <div class="col-lg-4 col-sm-6"> <?php
                                    } ?>
                                            <div class="single-feedback-item">
                                                <i class="flaticon-quote"></i>
                                                <p><?php echo wp_kses_post( $item['feedback'] ); ?></p>
                                                <div class="client-info">
                                                    <?php if( $is_lazyloader == true ): ?>
                                                        <img class="smartify" sm-src="<?php echo esc_url( $item['image']['url'] ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>">
                                                    <?php else: ?>
                                                        <img src="<?php echo esc_url( $item['image']['url'] ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>">
                                                    <?php endif; ?>
                                                    <h3><?php echo wp_kses_post( $item['name'] ); ?></h3>
                                                    <span><?php echo wp_kses_post( $item['designation'] ); ?></span>
                                                </div>
                                            </div>
                                    <?php if( $count == 2 ) { ?>
                                        </div> <?php
                                    } ?>
                                <?php endforeach; ?>
                            </div>
                        <?php if( $count == 2 ) { ?>
                        </div><?php
                        } ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
	}

}
Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Testimonial_Slider );