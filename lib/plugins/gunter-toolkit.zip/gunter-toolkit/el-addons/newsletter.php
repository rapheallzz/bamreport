<?php
/**
 * Newsletter Widget
 */

namespace Elementor;
class Gunter_Newsletter extends Widget_Base {

	public function get_name() {
        return 'Gunter_Newsletter';
    }

	public function get_title() {
        return __( 'Newsletter', 'gunter-toolkit' );
    }

	public function get_icon() {
        return 'eicon-email-field';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'Gunter_Newsletter',
			[
				'label' => __( 'Gunter Newsletter', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

            $this->add_control(
                'style',
                [
                    'label' => __( 'Style', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        '1'         => __( 'One', 'gunter-toolkit' ),
                        '2'         => __( 'Two', 'gunter-toolkit' ),
                    ],
                    'default' => '1',
                ]
            );

            $this->add_control(
                'select_mod',
                [
                    'label' => esc_html__( 'Newsletter Option', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'mailchimp'             => esc_html__( 'Mailchimp', 'gunter-toolkit' ),
                        'newsletter'            => esc_html__( 'Newsletter Plugin', 'gunter-toolkit' ),
                    ],
                    'default' => 'newsletter',
                ]
            );

            $this->add_control(
                'action_url', [
                    'label' => esc_html__( 'Action URL', 'gunter-toolkit' ),
                    'description' => __( 'Enter here your MailChimp action URL. <a href="https://www.docs.envytheme.com/docs/gunter-theme-documentation/tips-guides-troubleshoots/get-mailchimp-newsletter-form-action-url/" target="_blank"> How to </a>', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'label_block' => true,
                    'condition' => [
                        'select_mod' => 'mailchimp',
                    ]
                ]
            );

            $this->add_control(
                'image',
                [
                    'label' => __( 'Section Image', 'gunter-toolkit' ),
                    'type' => Controls_Manager::MEDIA,
                    'condition' => [
                        'style' => ['2'],
                    ],
                ]
            );

            $this->add_control(
                'version',
                [
                    'label' => __( 'Version', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'dark'      => __( 'Dark', 'gunter-toolkit' ),
                        'light'     => __( 'Light', 'gunter-toolkit' ),
                    ],
                    'default' => 'dark',
                ]
            );

            $this->add_control(
                'top_title', [
                    'label' => __( 'Top Title', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __( 'Newsletter' , 'gunter-toolkit' ),
                    'label_block' => true,
                    'condition' => [
                        'style' => ['2'],
                    ],
                ]
            );

            $this->add_control(
                'title', [
                    'label' => __( 'Title', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __( 'SUBSCRIBE TO OUR NEWSLETTER' , 'gunter-toolkit' ),
                    'label_block' => true,
                ]
            );

            $this->add_control(
                'desc', [
                    'label' => __( 'Content', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.' , 'gunter-toolkit' ),
                    'label_block' => true,
                    'condition' => [
                        'style' => ['2'],
                    ],
                ]
            );

            $this->add_control(
                'placeholder_text', [
                    'label' => __( 'Placeholder Text', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __( 'hello@gunter.com' , 'gunter-toolkit' ),
                    'label_block' => true,
                ]
            );

            $this->add_control(
                'button_text', [
                    'label' => __( 'Button text', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __( 'Subscribe Now' , 'gunter-toolkit' ),
                    'label_block' => true,
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
			'newsletter_style',
			[
				'label' => __( 'Style', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );
            $this->add_control(
                'title_color',
                [
                    'label' => __( 'Title Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .subscribe-area h3, .newsletter-content h2' => 'color: {{VALUE}}',
                    ],
                ]

            );

            $this->add_responsive_control(
                'title_size',
                [
                    'label' => __( 'Title Font Size', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 80,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .subscribe-area h3, .newsletter-content h2' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

            $this->add_control(
				'show_shape',
				[
					'label' => __( 'Shape Images', 'gunter-toolkit' ),
					'type' => Controls_Manager::SWITCHER,
					'label_on' => __( 'Show', 'gunter-toolkit' ),
					'label_off' => __( 'Hide', 'gunter-toolkit' ),
					'return_value' => 'yes',
					'default' => 'yes',
				]
			);

        $this->end_controls_section();
    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        global $opt_name;
		if( isset( $opt_name['enable_lazyloader'] ) ):
			$is_lazyloader = $opt_name['enable_lazyloader'];
		else:
			$is_lazyloader = true;
		endif;

        // Inline Editing
        $this-> add_inline_editing_attributes('title','none');

        $dark = '';
        if( $settings['version'] == 'dark' ):
            $dark = 'uk-dark';
        endif;

        ?>

        <?php if( $settings['style'] == '1' ): ?>
            <div class="subscribe-area uk-section uk-subscribe bg-gray <?php echo esc_attr( $dark ); ?>">
                <div class="uk-container">
                    <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
                        <div class="item">
                            <h3 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo wp_kses_post( $settings['title'] ); ?></h3>
                        </div>

                        <div class="item">

                            <?php if( $settings['select_mod'] == 'mailchimp' ): ?>
                                <form class="mailchimp newsletter-form" method="post">
                                    <input type="email" class="uk-input memail" placeholder="<?php echo esc_attr( $settings['placeholder_text'] ); ?>" name="EMAIL" required>
                                        <?php if( $settings['button_text'] != '' ): ?>
                                            <button type="submit" class="uk-button uk-button-default"><?php echo wp_kses_post( $settings['button_text'] ); ?></button>
                                        <?php endif; ?>
                                    <p class="mchimp-errmessage" style="display: none;"></p>
                                    <p class="mchimp-sucmessage" style="display: none;"></p>
                                </form>

                                <script>
                                    ;(function($){
                                        "use strict";
                                        $(document).ready(function () {
                                            // MAILCHIMP
                                            if ($(".mailchimp").length > 0) {
                                                $(".mailchimp").ajaxChimp({
                                                    callback: mailchimpCallback,
                                                    url: "<?php echo esc_js($settings['action_url']) ?>"
                                                });
                                            }
                                            if ($(".mailchimp_two").length > 0) {
                                                $(".mailchimp_two").ajaxChimp({
                                                    callback: mailchimpCallback,
                                                    url: "<?php echo esc_js($settings['action_url']) ?>" //Replace this with your own mailchimp post URL. Don't remove the "". Just paste the url inside "".
                                                });
                                            }
                                            $(".memail").on("focus", function () {
                                                $(".mchimp-errmessage").fadeOut();
                                                $(".mchimp-sucmessage").fadeOut();
                                            });
                                            $(".memail").on("keydown", function () {
                                                $(".mchimp-sucmessage").fadeOut();
                                                $(".mchimp-sucmessage").fadeOut();
                                            });
                                            $(".memail").on("click", function () {
                                                $(".memail").val("");
                                            });

                                            function mailchimpCallback(resp) {
                                                if (resp.result === "success") {
                                                    $(".mchimp-errmessage").html(resp.msg).fadeIn(1000);
                                                    $(".mchimp-sucmessage").fadeOut(500);
                                                } else if (resp.result === "error") {
                                                    $(".mchimp-errmessage").html(resp.msg).fadeIn(1000);
                                                }
                                            }
                                        });
                                    })(jQuery)
                                </script>
                            <?php else: ?>
                                <form class="newsletter-form" method="post" action="<?php echo home_url(); ?>/?na=s" onsubmit="return newsletter_check(this)">
                                    <input type="email" class="uk-input" placeholder="<?php echo esc_attr( $settings['placeholder_text'] ); ?>" name="ne" required="" autocomplete="off">
                                        <?php if( $settings['button_text'] != '' ): ?>
                                            <button type="submit" class="uk-button uk-button-default"><?php echo wp_kses_post( $settings['button_text'] ); ?></button>
                                        <?php endif; ?>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <?php if( $settings['show_shape'] == 'yes' ): ?>
                    <div class="shape">
                        <?php if( $is_lazyloader == true ): ?>
                            <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/footer-shape1.png').'" alt="'.esc_attr( $settings['title'] ); ?>">
                        <?php else: ?>
                            <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/footer-shape1.png').'" alt="'.esc_attr( $settings['title'] ); ?>">
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if( $settings['style'] == '2' ): ?>
            <div class="uk-newsletter newsletter-area" style="background-image:url(<?php echo esc_url( $settings['image']['url'] ); ?>);">
                <div class="uk-container">
                    <div class="newsletter-content">
                        <span class="sub-title"><?php echo wp_kses_post( $settings['top_title'] ); ?></span>
                        <h2><?php echo wp_kses_post( $settings['title'] ); ?></h2>
                        <p><?php echo wp_kses_post( $settings['desc'] ); ?></p>

                        <?php if( $settings['select_mod'] == 'mailchimp' ): ?>

                            <form class="mailchimp newsletter-form" method="post">
                                <input type="email" class="uk-input" placeholder="<?php echo esc_attr( $settings['placeholder_text'] ); ?>" name="EMAIL" required="" autocomplete="off">

                                <?php if( $settings['button_text'] != '' ): ?>
                                    <button type="submit" class="memail uk-button uk-button-default"><?php echo wp_kses_post( $settings['button_text'] ); ?></button>
                                <?php endif; ?>
                                <p class="mchimp-errmessage" style="display: none;"></p>
                                <p class="mchimp-sucmessage" style="display: none;"></p>

                                <script>
                                    ;(function($){
                                        "use strict";
                                        $(document).ready(function () {
                                            // MAILCHIMP
                                            if ($(".mailchimp").length > 0) {
                                                $(".mailchimp").ajaxChimp({
                                                    callback: mailchimpCallback,
                                                    url: "<?php echo esc_js($settings['action_url']) ?>"
                                                });
                                            }
                                            if ($(".mailchimp_two").length > 0) {
                                                $(".mailchimp_two").ajaxChimp({
                                                    callback: mailchimpCallback,
                                                    url: "<?php echo esc_js($settings['action_url']) ?>" //Replace this with your own mailchimp post URL. Don't remove the "". Just paste the url inside "".
                                                });
                                            }
                                            $(".memail").on("focus", function () {
                                                $(".mchimp-errmessage").fadeOut();
                                                $(".mchimp-sucmessage").fadeOut();
                                            });
                                            $(".memail").on("keydown", function () {
                                                $(".mchimp-errmessage").fadeOut();
                                                $(".mchimp-sucmessage").fadeOut();
                                            });
                                            $(".memail").on("click", function () {
                                                $(".memail").val("");
                                            });

                                            function mailchimpCallback(resp) {
                                                if (resp.result === "success") {
                                                    $(".mchimp-sucmessage").html(resp.msg).fadeIn(1000);
                                                    $(".mchimp-sucmessage").fadeOut(500);
                                                } else if (resp.result === "error") {
                                                    $(".mchimp-errmessage").html(resp.msg).fadeIn(1000);
                                                }
                                            }
                                        });
                                    })(jQuery)
                                </script>
                            </form>

                        <?php else: ?>
                            <form class="newsletter-form" method="post" action="<?php echo home_url(); ?>/?na=s" onsubmit="return newsletter_check(this)">
                                <input type="email" class="uk-input" placeholder="<?php echo esc_attr( $settings['placeholder_text'] ); ?>" name="ne" required="" autocomplete="off">

                                <?php if( $settings['button_text'] != '' ): ?>
                                    <button type="submit" class="uk-button uk-button-default"><?php echo wp_kses_post( $settings['button_text'] ); ?></button>
                                <?php endif; ?>
                            </form>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Newsletter );