<?php
/**
 * About Us Widget
 */

namespace Elementor;
class Gunter_About_Us extends Widget_Base {

	public function get_name() {
        return 'Gunter_About_Us';
    }

	public function get_title() {
        return __( 'About Us', 'gunter-toolkit' );
    }

	public function get_icon() {
        return 'eicon-info-circle-o';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'Gunter_About_Us_Area',
			[
				'label' => __( 'Gunter About Us Controls', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

            $this->add_control(
                'select_style',
                [
                    'label' => __( 'Select Style', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        '1'      => __( 'Style One', 'gunter-toolkit' ),
                        '2'     => __( 'Style Two', 'gunter-toolkit' ),
                    ],
                    'default' => '1',
                ]
            );

            $this->add_control(
                'section_version',
                [
                    'label' => __( 'Select Version', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'dark'      => __( 'Dark', 'gunter-toolkit' ),
                        'light'     => __( 'Light', 'gunter-toolkit' ),
                    ],
                    'default' => 'dark',
                ]
            );

            $this->add_control(
                'top_title',
                [
                    'label' => __( 'Top Title', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('About Us', 'gunter-toolkit'),
                ]
            );

            $this->add_control(
                'title',
                [
                    'label' => __( 'Title', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Leading the way in Creative Digital Agency', 'gunter-toolkit'),
                ]
            );

            $this->add_control(
				'icon',
				[
					'label' => esc_html__( 'Button Icon', 'gunter-toolkit' ),
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'options' => gunter_icons(),
				]
            );

            $this->add_control(
                'content',
                [
                    'label' => __( 'Content', 'gunter-toolkit' ),
                    'type' => Controls_Manager::WYSIWYG,
                ]
            );

            $this->add_control(
                'about_image',
                [
                    'label' => __( 'About Image One', 'gunter-toolkit' ),
                    'type' => Controls_Manager::MEDIA,
                ]
            );
            $this->add_control(
                'about_image2',
                [
                    'label' => __( 'About Image Two', 'gunter-toolkit' ),
                    'type' => Controls_Manager::MEDIA,
                ]
            );

            $this->add_control(
                'button_text',
                [
                    'label' => __( 'Button Text', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('More About Us', 'gunter-toolkit'),
                ]
            );

            $this->add_control(
                'button_link',
                [
                    'label' => __( 'Button Link', 'gunter-toolkit' ),
                    'type' => Controls_Manager::URL,
                ]
            );


        $this->end_controls_section();

        $this->start_controls_section(
			'about_style',
			[
				'label' => __( 'Style', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
        );
            $this->add_control(
                'shape_image',
                [
                    'label' => __( 'Shape Images', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'gunter-toolkit' ),
                    'label_off' => __( 'Hide', 'gunter-toolkit' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );

            $this->add_control(
                'main_color',
                [
                    'label' => __( 'Section Main Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .section-title .bar, .uk-button::before, .uk-button::after' => 'background: {{VALUE}}',
                        '{{WRAPPER}} .about-text .icon' => 'color: {{VALUE}}',
                        '{{WRAPPER}} .uk-button-default' => 'border-color: {{VALUE}}',
                        '{{WRAPPER}} .uk-button-default, .about-img .uk-button' => 'background-color: {{VALUE}}',
                        '{{WRAPPER}} .uk-button::before' => 'background: {{VALUE}}',
                    ],
                ]
            );

            $this->add_control(
                'top_title_color',
                [
                    'label' => __( 'Top Title Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .section-title span' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'top_title_size',
                [
                    'label' => __( 'Top Title Font Size', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 70,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .section-title span' => 'font-size: {{SIZE}}px;',
                    ],
                    'condition' => [
                        'card_style' => '1',
                    ]
                ]
            );

            $this->add_control(
                'title_color',
                [
                    'label' => __( 'Title Color', 'gunter-toolkit' ),
                    'type' => Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .section-title h2' => 'color: {{VALUE}}',
                    ],
                ]
            );

            $this->add_responsive_control(
                'title_size',
                [
                    'label' => __( 'Title Font Size', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px' ],
                    'range' => [
                        'px' => [
                            'min' => 1,
                            'max' => 70,
                            'step' => 1,
                        ],
                    ],
                    'devices' => [ 'desktop', 'tablet', 'mobile' ],
                    'selectors' => [
                        '{{WRAPPER}} .section-title h2' => 'font-size: {{SIZE}}px;',
                    ],
                ]
            );

        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();
        $dark = 'uk-dark';

        global $opt_name;
		if( isset( $opt_name['enable_lazyloader'] ) ):
			$is_lazyloader = $opt_name['enable_lazyloader'];
		else:
			$is_lazyloader = true;
		endif; ?>

        <?php if( $settings['select_style'] == '1' ): ?>
            <div class="uk-about about-area uk-section <?php if( $settings['section_version'] == 'dark'): echo esc_attr( $dark ); endif; ?>">
                <div class="uk-container">
                    <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
                        <div class="item">
                            <div class="about-content">
                                <div id="about" class="uk-section-title section-title">
                                    <span><?php echo wp_kses_post( $settings['top_title'] ); ?></span>
                                    <h2><?php echo wp_kses_post( $settings['title'] ); ?></h2>
                                    <div class="bar"></div>
                                </div>

                                <div class="about-text">
                                    <div class="icon">
                                        <i class="<?php echo esc_attr( $settings['icon'] ); ?>"></i>
                                    </div>
                                    <?php echo $settings['content'] ?>
                                </div>
                            </div>
                        </div>

                        <div class="item">
                            <div class="about-img">
                                <?php if( $settings['about_image']['url'] != '' ): ?>
                                    <?php if( $is_lazyloader == true ): ?>
                                        <img class="smartify about-img1" sm-src="<?php echo esc_url( $settings['about_image']['url'] ); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo esc_url( $settings['about_image']['url'] ); ?>" class="about-img1">
                                    <?php endif; ?>

                                <?php endif; ?>

                                <?php if( $settings['about_image2']['url'] != '' ): ?>
                                    <?php if( $is_lazyloader == true ): ?>
                                        <img class="smartify about-img2" sm-src="<?php echo esc_url( $settings['about_image2']['url'] ); ?>" alt="<?php echo esc_attr( $settings['top_title'] ); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo esc_url( $settings['about_image2']['url'] ); ?>" class="about-img2" alt="<?php echo esc_attr( $settings['top_title'] ); ?>">
                                    <?php endif; ?>
                                <?php endif; ?>

                                <?php if( $settings['shape_image'] == 'yes' ): ?>
                                    <?php if( $is_lazyloader == true ): ?>
                                        <img class="smartify shape-img" sm-src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/1.png'); ?>" alt="<?php echo esc_attr__( 'shape', 'gunter-toolkit' ); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/1.png'); ?>" class="shape-img" alt="<?php echo esc_attr__( 'shape', 'gunter-toolkit' ); ?>">
                                    <?php endif; ?>
                                <?php endif; ?>

                                <?php if( $settings['button_text'] != '' ): ?>
                                    <a href="<?php echo esc_url( $settings['button_link']['url'] ); ?>" class="uk-button uk-button-default lax" data-lax-translate-x="vh 100, -elh -100" data-lax-anchor="self"><?php echo wp_kses_post( $settings['button_text'] ); ?><i class="flaticon-right"></i></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php elseif( $settings['select_style'] == '2' ): ?>
            <div id="about" class="uk-about about-area uk-section <?php if( $settings['section_version'] == 'dark'): echo esc_attr( $dark ); endif; ?>">
                <div class="uk-container">
                    <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
                        <div class="item">
                            <div class="about-image">
                                <?php if( $settings['about_image']['url'] != '' ): ?>
                                    <?php if( $is_lazyloader == true ): ?>
                                        <img class="smartify about-img1" sm-src="<?php echo esc_url( $settings['about_image']['url'] ); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo esc_url( $settings['about_image']['url'] ); ?>" class="about-img1">
                                    <?php endif; ?>
                                <?php endif; ?>

                                <?php if( $settings['about_image2']['url'] != '' ): ?>
                                    <?php if( $is_lazyloader == true ): ?>
                                        <img class="smartify about-img2" sm-src="<?php echo esc_url( $settings['about_image2']['url'] ); ?>" alt="<?php echo esc_attr( $settings['top_title'] ); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo esc_url( $settings['about_image2']['url'] ); ?>" class="about-img2" alt="<?php echo esc_attr( $settings['top_title'] ); ?>">
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="item">
                            <div class="about-content">
                                <div class="uk-section-title section-title">
                                    <span><?php echo wp_kses_post( $settings['top_title'] ); ?></span>
                                    <h2><?php echo wp_kses_post( $settings['title'] ); ?></h2>
                                    <div class="bar"></div>
                                </div>

                                <div class="about-text">
                                    <div class="icon">
                                        <i class="<?php echo esc_attr( $settings['icon'] ); ?>"></i>
                                    </div>
                                    <?php echo $settings['content'] ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="shape-circle-img1">
                    <?php if( $settings['shape_image'] == 'yes' ): ?>
                        <?php if( $is_lazyloader == true ): ?>
                            <img class="smartify" sm-src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape-img1.png'); ?>" alt="<?php echo esc_attr__( 'shape', 'gunter-toolkit' ); ?>">
                        <?php else: ?>
                            <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/shape-img1.png'); ?>" alt="<?php echo esc_attr__( 'shape', 'gunter-toolkit' ); ?>">
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
        <?php
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Gunter_About_Us );