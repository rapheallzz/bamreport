<?php
/**
 * Why Choose Us Widget
 */

namespace Elementor;
class Gunter_Why_choose_Us extends Widget_Base {

	public function get_name() {
        return 'Gunter_Why_choose_Us';
    }

	public function get_title() {
        return __( 'Why Choose Us', 'gunter-toolkit' );
    }

	public function get_icon() {
        return 'eicon-posts-ticker';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'Gunter_Why_choose_Us',
			[
				'label' => __( 'Why Choose Us Control', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );
        $this->add_control(
            'version',
            [
                'label' => __( 'Choose Version', 'gunter-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'light'         => __( 'Light', 'gunter-toolkit' ),
                    'dark'          => __( 'Dark', 'gunter-toolkit' ),
                ],
                'default' => 'dark',
            ]
        );
        $this->add_control(
            'top_title',
            [
                'label' => __( 'Top Title', 'gunter-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'default' => __('Why Choose Us', 'gunter-toolkit'),
            ]
        );
        $this->add_control(
            'title',
            [
                'label' => __( 'Title', 'gunter-toolkit' ),
                'type' => Controls_Manager::TEXT,
                'default' => __('We Are Dynamic & Special for SEO', 'gunter-toolkit'),
            ]
        );
        $this->add_control(
            'image',
            [
                'label' => __( 'Image', 'gunter-toolkit' ),
                'type' => Controls_Manager::MEDIA,
            ]
        );
        $repeater = new Repeater();

        $repeater->add_control(
            'icon_type',
            [
                'label' => __( 'Icon Type', 'holab-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'font-awesome'   => __( 'Font Awesome', 'holab-toolkit' ),
                    'flat-icon'         => __( 'Flat Icon', 'holab-toolkit' ),
                ],
                'default' => 'font-awesome',
            ]
        );
        $repeater->add_control(
            'fa_icon',
            [
                'label' => __( 'Font-Awesome', 'gunter-toolkit' ),
                'type' => Controls_Manager::ICON,
                'condition' => [
                    'icon_type' => ['font-awesome'],
                ],
            ]
        );
        $repeater->add_control(
            'flat_icon',
            [
                'label' => __( 'Flat Icon', 'gunter-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'flaticon-quality'              => 'Quality',
                    'flaticon-plan'                 => 'Plan',
                    'flaticon-domain-registration'  => 'Domain Registration',
                    'flaticon-targeting'            => 'Targeting',
                    'flaticon-search-engine'        => 'Search Engine',
                    'flaticon-idea'                 => 'Idea',
                    'flaticon-pay-per-click'        => 'Pay Per Click',
                    'flaticon-analytics-1'          => 'Analytics 1',
                    'flaticon-analytics-2'          => 'Analytics 2',
                    'flaticon-link'                 => 'Link',
                    'flaticon-translation'          => 'Translation',
                    'flaticon-bug'                  => 'Bug',
                    'flaticon-mail'                 => 'Mail',
                    'flaticon-magnifying-glass'     => 'Magnifying Glass',
                    'flaticon-think'                => 'Think',
                    'flaticon-shout'                => 'Shout',
                    'flaticon-ux-design'            => 'UX Design',
                    'flaticon-camera'               => 'Camera',
                    'flaticon-data'                 => 'Data',
                    'flaticon-chat'                 => 'Chat',
                    'flaticon-stats'                => 'Stats',
                    'flaticon-project'              => 'Project',
                    'flaticon-quote'                => 'Quote',
                    'flaticon-facebook'             => 'Facebook',
                    'flaticon-instagram'            => 'Instagram',
                    'flaticon-twitter'              => 'Twitter',
                    'flaticon-linkedin'             => 'Linkedin',
                    'flaticon-down-arrow'           => 'Down Arrow',
                    'flaticon-back'                 => 'Back',
                    'flaticon-multimedia'           => 'Multimedia',
                    'flaticon-search'               => 'Search',
                    'flaticon-edit'                 => 'Edit',
                    'flaticon-plus'                 => 'Plus',
                    'flaticon-line'                 => 'Line',
                    'flaticon-tick'                 => 'Tick',
                    'flaticon-chevron'              => 'Chevron',
                ],
                'default' => 'flaticon-quality',
                'condition' => [
                    'icon_type' => ['flat-icon'],
                ],
            ]
        );
        $repeater->add_control(
            'title',
            [
                'label' => __( 'Title', 'gunter-toolkit' ),
                'type' => Controls_Manager::TEXT,
            ]
        );
        $repeater->add_control(
            'content',
            [
                'label' => __( 'Content', 'gunter-toolkit' ),
                'type' => Controls_Manager::TEXTAREA,
            ]
        );

        $this->add_control(
            'card_item',
            [
                'label' => esc_html__('Card Item', 'gunter-toolkit'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
        );

        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        global $opt_name;
		if( isset( $opt_name['enable_lazyloader'] ) ):
			$is_lazyloader = $opt_name['enable_lazyloader'];
		else:
			$is_lazyloader = true;
		endif;

        // Inline Editing
        $this-> add_inline_editing_attributes('top_title','none');
        $this-> add_inline_editing_attributes('title','none');

        // dark and light version
        $dark = '';
        if( $settings['version'] == 'dark' ):
            $dark = ' uk-dark';
        endif;

        ?>
         <div class="why-choose-us-section uk-why-choose-us uk-section <?php echo esc_attr( $dark ); ?>">
            <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-2@s">
                <div class="item">
                    <div class="why-choose-us-content">
                        <div class="uk-section-title section-title">
                        <span <?php echo $this-> get_render_attribute_string('top_title'); ?>><?php echo wp_kses_post( $settings['top_title'] ); ?></span>
                        <h2 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo wp_kses_post( $settings['title'] ); ?></h2>

                            <div class="bar"></div>
                        </div>

                        <ul class="why-choose-us-text">
                            <?php foreach( $settings['card_item'] as $item ): ?>
                                <li>
                                    <div class="icon">
                                        <?php if( $item['icon_type'] == 'flat-icon'): ?>
                                            <i class="<?php echo esc_attr( $item['flat_icon'] ); ?>"></i>
                                        <?php else: ?>
                                            <i class="<?php echo esc_attr( $item['fa_icon'] ); ?>"></i>
                                        <?php endif; ?>
                                    </div>
                                    <h3><?php echo wp_kses_post( $item['title'] ); ?></h3>
                                    <p><?php echo wp_kses_post( $item['content'] ); ?></p>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>

                <div class="item">
                    <div class="why-choose-us-image uk-text-center">
                        <?php if( $settings['image']['url'] != '' ): ?>
                            <?php if( $is_lazyloader == true ): ?>
                                <img class="smartify" sm-src="<?php echo esc_url( $settings['image']['url'] ); ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                            <?php else: ?>
                                <img src="<?php echo esc_url( $settings['image']['url'] ); ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Why_choose_Us );