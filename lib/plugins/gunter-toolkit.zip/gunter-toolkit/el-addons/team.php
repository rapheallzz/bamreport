<?php
/**
 * Team Widget
 */
namespace Elementor;
class Gunter_Team extends Widget_Base{
    public function get_name(){
        return "Gunter_Team";
    }
    public function get_title(){
        return "Team";
    }
    public function get_icon(){
        return "eicon-gallery-group";
    }
    public function get_categories(){
        return ['gunter-elements'];
    }
    protected function register_controls(){

    $this->start_controls_section(
        'Gunter_Team',
        [
            'label' => __( 'Gunter Team', 'gunter-toolkit' ),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]
    );

        $this->add_control(
            'choose_type',
            [
                'label' => esc_html__( 'Choose Style', 'gunter-toolkit' ),
                'type' => Controls_Manager::SELECT,
                'label_block' => true,
                'options' => [
                    1   => esc_html__( 'Style Slider', 'gunter-toolkit' ),
                    2   => esc_html__( 'Style Card One', 'gunter-toolkit' ),
                    3   => esc_html__( 'Style Card Two', 'gunter-toolkit' ),
                ],
                'default' => 1,
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'member_img',
            [
                'label' => esc_html__( 'Image', 'gunter-toolkit' ),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
            ]
        );
        $repeater->add_control(
            'name',
            [
                'label' => esc_html__( 'Member Name', 'gunter-toolkit' ),
                'type' => Controls_Manager::TEXT,
            ]
        );
        $repeater->add_control(
            'designation',
            [
                'label' => esc_html__( 'Designation', 'gunter-toolkit' ),
                'type' => Controls_Manager::TEXT,
            ]
        );
        $repeater->add_control(
            'icon1',
            [
                'label' => esc_html__( 'Social Icon One', 'gunter-toolkit' ),
                'type' => Controls_Manager::ICON,
            ]
        );
        $repeater->add_control(
            'url1',
            [
                'label' => esc_html__( 'Social Link One', 'gunter-toolkit' ),
                'type' => Controls_Manager::URL,
            ]
        );

        $repeater->add_control(
            'icon2',
            [
                'label' => esc_html__( 'Social Icon Two', 'gunter-toolkit' ),
                'type' => Controls_Manager::ICON,
            ]
        );
        $repeater->add_control(
            'url2',
            [
                'label' => esc_html__( 'Social Link Two', 'gunter-toolkit' ),
                'type' => Controls_Manager::URL,
            ]
        );

        $repeater->add_control(
            'icon3',
            [
                'label' => esc_html__( 'Social Icon Three', 'gunter-toolkit' ),
                'type' => Controls_Manager::ICON,
            ]
        );
        $repeater->add_control(
            'url3',
            [
                'label' => esc_html__( 'Social Link Three', 'gunter-toolkit' ),
                'type' => Controls_Manager::URL,
            ]
        );

        $repeater->add_control(
            'icon4',
            [
                'label' => esc_html__( 'Social Icon Four', 'gunter-toolkit' ),
                'type' => Controls_Manager::ICON,
            ]
        );
        $repeater->add_control(
            'url4',
            [
                'label' => esc_html__( 'Social Link Four', 'gunter-toolkit' ),
                'type' => Controls_Manager::URL,
            ]
        );

        $this->add_control(
            'teams',
            [
                'label' => esc_html__( 'Add Member', 'gunter-toolkit' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            ]
        );
    $this-> end_controls_section();

    // Start Style content controls
    $this-> start_controls_section(
        'style',
        [
            'label'=>esc_html__('Style', 'gunter-toolkit'),
            'tab'=> Controls_Manager::TAB_STYLE,
        ]
    );

        $this->add_control(
            'name_color',
            [
                'label' => esc_html__( 'Member Name Color', 'gunter-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-team .team-content h3, .single-team-box .content h3' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_responsive_control(
            'name_size',
            [
                'label' => esc_html__( 'Member Name Font Size', 'gunter-toolkit' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 50,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],
                'unit' => 'px',
                'selectors' => [
                    '{{WRAPPER}} .single-team .team-content h3, .single-team-box .content h3' => 'font-size: {{SIZE}}{{UNIT}}',
                ],
            ]
        );

        $this->add_control(
            'designation_color',
            [
                'label' => esc_html__( 'Member Designation Color', 'gunter-toolkit' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .single-team .team-content span, .single-team-box .content span' => 'color: {{VALUE}}',
                ],
            ]
        );
    $this->add_responsive_control(
        'designation_size',
        [
            'label' => esc_html__( 'Member Designation Font Size', 'gunter-toolkit' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 50,
                ],
            ],
            'devices' => [ 'desktop', 'tablet', 'mobile' ],
            'unit' => 'px',
            'selectors' => [
                '{{WRAPPER}} .single-team .team-content span, .single-team-box .content span' => 'font-size: {{SIZE}}{{UNIT}}',
            ],
        ]
    );
    $this-> end_controls_section();
}
    protected function render()
    {
        $settings = $this->get_settings_for_display();

        global $opt_name;
		if( isset( $opt_name['enable_lazyloader'] ) ):
			$is_lazyloader = $opt_name['enable_lazyloader'];
		else:
			$is_lazyloader = true;
        endif;

        $slider         = $settings['teams'];

        $count = 0;
        foreach ( $slider as $value ) {
            $count++;
        } ?>

        <?php if( $settings['choose_type'] == 1 ):

            if( $count == 1 || $count == 2 || $count == 3 || $count == 4 ) { ?>
            <div class="uk-container">
                <?php if( $count == 2 ){ ?>
                    <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s uk-flex-center"> <?php
                } elseif( $count == 4 ){ ?>
                    <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-4@m uk-child-width-1-2@s uk-flex-center"> <?php
                } else { ?>
                    <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s uk-flex-center"> <?php
                }
            } else { ?>
            <div class="team-slides owl-carousel owl-theme"><?php
            } ?>

                <?php if ( $settings['teams'] != '' ): ?>
                    <?php foreach( $settings['teams'] as $item ): ?>
                        <div class="single-team">
                            <ul class="team-social">
                                <?php if( $item['icon1'] != '' && $item['url1']['url'] != '' ): ?>
                                    <li><a href="<?php echo esc_url( $item['url1']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon1'] ); ?>"></i></a></li>
                                <?php endif; ?>

                                <?php if( $item['icon2'] != '' && $item['url2']['url'] != '' ): ?>
                                    <li><a href="<?php echo esc_url( $item['url2']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon2'] ); ?>"></i></a></li>
                                <?php endif; ?>

                                <?php if( $item['icon3'] != '' && $item['url3']['url'] != '' ): ?>
                                    <li><a href="<?php echo esc_url( $item['url3']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon3'] ); ?>"></i></a></li>
                                <?php endif; ?>

                                <?php if( $item['icon4'] != '' && $item['url4']['url'] != '' ): ?>
                                    <li><a href="<?php echo esc_url( $item['url4']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon4'] ); ?>"></i></a></li>
                                <?php endif; ?>
                            </ul>
                            <?php if( $item['member_img']['url'] != '' ): ?>
                                <?php if( $is_lazyloader == true ): ?>
                                    <img class="smartify wow fadeInDown bannerrightimg" sm-src="<?php echo esc_url( $item['member_img']['url'] ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>">
                                <?php else: ?>
                                    <img src="<?php echo esc_url( $item['member_img']['url'] ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>" class="wow fadeInDown bannerrightimg">
                                <?php endif; ?>
                            <?php endif; ?>

                            <div class="team-content">
                                <h3><?php echo wp_kses_post( $item['name'] ); ?></h3>
                                <span><?php echo wp_kses_post( $item['designation'] ); ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>

            <?php if( $count == 1 || $count == 2 || $count == 3 || $count == 4 ) { ?>
            </div>
            <?php } ?>
            </div>

        <?php endif; ?>

        <?php if( $settings['choose_type'] == 2 ): ?>
            <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s">
                 <?php if ( $settings['teams'] != '' ): ?>
                    <?php foreach( $settings['teams'] as $item ): ?>
                        <div class="single-team mb-30">
                            <ul class="team-social">
                                <?php if( $item['icon1'] != '' && $item['url1']['url'] != '' ): ?>
                                    <li><a href="<?php echo esc_url( $item['url1']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon1'] ); ?>"></i></a></li>
                                <?php endif; ?>

                                <?php if( $item['icon2'] != '' && $item['url2']['url'] != '' ): ?>
                                    <li><a href="<?php echo esc_url( $item['url2']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon2'] ); ?>"></i></a></li>
                                <?php endif; ?>

                                <?php if( $item['icon3'] != '' && $item['url3']['url'] != '' ): ?>
                                    <li><a href="<?php echo esc_url( $item['url3']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon3'] ); ?>"></i></a></li>
                                <?php endif; ?>

                                <?php if( $item['icon4'] != '' && $item['url4']['url'] != '' ): ?>
                                    <li><a href="<?php echo esc_url( $item['url4']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon4'] ); ?>"></i></a></li>
                                <?php endif; ?>
                            </ul>
                            <?php if( $item['member_img']['url'] != '' ): ?>
                                <?php if( $is_lazyloader == true ): ?>
                                    <img class="smartify" sm-src="<?php echo esc_url( $item['member_img']['url'] ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>">
                                <?php else: ?>
                                    <img src="<?php echo esc_url( $item['member_img']['url'] ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>">
                                <?php endif; ?>
                            <?php endif; ?>

                            <div class="team-content">
                                <h3><?php echo wp_kses_post( $item['name'] ); ?></h3>
                                <span><?php echo wp_kses_post( $item['designation'] ); ?></span>
                            </div>
                        </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if( $settings['choose_type'] == 3 ): ?>
            <div class="uk-container">
                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s">
                    <?php if ( $settings['teams'] != '' ): ?>
                        <?php foreach( $settings['teams'] as $item ): ?>
                            <div class="item">
                                <div class="single-team-box">
                                    <?php if( $item['member_img']['url'] != '' ): ?>
                                        <?php if( $is_lazyloader == true ): ?>
                                            <img class="smartify" sm-src="<?php echo esc_url( $item['member_img']['url'] ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>">
                                        <?php else: ?>
                                            <img src="<?php echo esc_url( $item['member_img']['url'] ); ?>" alt="<?php echo esc_attr( $item['name'] ); ?>">
                                        <?php endif; ?>
                                    <?php endif; ?>

                                    <div class="content">
                                        <h3><?php echo wp_kses_post( $item['name'] ); ?></h3>
                                        <span><?php echo wp_kses_post( $item['designation'] ); ?></span>

                                        <div class="social">
                                            <div class="social-btn">
                                                <span uk-icon="cog"></span>
                                            </div>
                                            <ul>
                                                <?php if( $item['icon1'] != '' && $item['url1']['url'] != '' ): ?>
                                                    <li><a href="<?php echo esc_url( $item['url1']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon1'] ); ?>"></i></a></li>
                                                <?php endif; ?>

                                                <?php if( $item['icon2'] != '' && $item['url2']['url'] != '' ): ?>
                                                    <li><a href="<?php echo esc_url( $item['url2']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon2'] ); ?>"></i></a></li>
                                                <?php endif; ?>

                                                <?php if( $item['icon3'] != '' && $item['url3']['url'] != '' ): ?>
                                                    <li><a href="<?php echo esc_url( $item['url3']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon3'] ); ?>"></i></a></li>
                                                <?php endif; ?>

                                                <?php if( $item['icon4'] != '' && $item['url4']['url'] != '' ): ?>
                                                    <li><a href="<?php echo esc_url( $item['url4']['url'] ); ?>"><i class="<?php echo esc_attr( $item['icon4'] ); ?>"></i></a></li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>

    <?php
    }
}
Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Team );