<?php
/**
 * Contact Two Widget
 */

namespace Elementor;
class Gunter_Contact_Two extends Widget_Base {

	public function get_name() {
        return 'Contact Two';
    }

	public function get_title() {
        return __( 'Contact Two', 'gunter-toolkit' );
    }

	public function get_icon() {
        return 'eicon-handle';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'Gunter_Contact_Two',
			[
				'label' => __( 'Gunter Contact Two', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );

            $this->add_control(
                'top_title',
                [
                    'label' => __( 'Top Title', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Let’s Talk', 'gunter-toolkit'),
                ]
            );
            $this->add_control(
                'title',
                [
                    'label' => __( 'Title', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Want to Work With Our Team?', 'gunter-toolkit'),
                ]
            );

            $this->add_control(
                'version',
                [
                    'label' => __( 'Select Version', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'dark'      => __( 'Dark', 'gunter-toolkit' ),
                        'light'     => __( 'Light', 'gunter-toolkit' ),
                    ],
                    'default' => 'dark',
                ]
            );

            $this->add_control(
                'image',
                [
                    'label' => __( 'Section Image', 'gunter-toolkit' ),
                    'type' => Controls_Manager::MEDIA,
                ]
            );

            $this->add_control(
                'location_title',
                [
                    'label' => __( 'Location Title', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('27 Division St, New York, NY 10002, USA', 'gunter-toolkit'),
                ]
            );

            $repeater = new Repeater();

            $repeater->add_control(
                'label_title',
                [
                    'type'    => Controls_Manager::TEXT,
                    'label'   => esc_html__( 'Label Title', 'gunter-toolkit' ),
                    'default' => esc_html__('Email:', 'gunter-toolkit'),
                ]
            );

            $repeater->add_control(
                'value_title',
                [
                    'type'    => Controls_Manager::TEXT,
                    'label'   => esc_html__( 'Value Title', 'gunter-toolkit' ),
                    'default' => esc_html__('hello@gunter.com', 'gunter-toolkit'),
                ]
            );

            $repeater->add_control(
                'value_link',
                [
                    'type'    => Controls_Manager::URL,
                    'label'   => esc_html__( 'Value Link', 'gunter-toolkit' ),
                ]
            );
            $this->add_control(
                'items',
                [
                    'label'   => esc_html__( 'Add Contact Info', 'gunter-toolkit' ),
                    'type' => Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                ]
            );

            $this->add_control(
                'contact_form',
                [
                    'label'=>esc_html__('Contact Two From 7 Shortcode', 'gunter-toolkit'),
                    'type'=>Controls_Manager:: TEXT,
                ]
            );

        $this->end_controls_section();

    }

	protected function render() {

        $settings = $this->get_settings_for_display();

        global $opt_name;
		if( isset( $opt_name['enable_lazyloader'] ) ):
			$is_lazyloader = $opt_name['enable_lazyloader'];
		else:
			$is_lazyloader = true;
		endif;

        $dark = '';
        if( $settings['version'] == 'dark' ):
            $dark = 'uk-dark';
        endif;

        ?>
        <div class="contact-section uk-contact <?php echo esc_attr( $dark ); ?>">
            <div class="uk-container-expand">
                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
                    <div class="item">
                        <div class="contact-image" style="background-image:url(<?php echo esc_url( $settings['image']['url'] ); ?>);">

                            <?php if( $is_lazyloader == true ): ?>
                                <img class="smartify" sm-src="<?php echo esc_url( $settings['image']['url'] ); ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                            <?php else: ?>
                                <img src="<?php echo esc_url( $settings['image']['url'] ); ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                            <?php endif; ?>

                            <div class="contact-info">
                                <h3><?php echo wp_kses_post( $settings['location_title'] ); ?></h3>
                                <ul>
                                    <?php foreach( $settings['items'] as $item ): ?>
                                        <li><?php echo wp_kses_post( $item['label_title'] ); ?> <a href="<?php echo esc_url( $item['value_link']['url'] ); ?>"><?php echo wp_kses_post( $item['value_title'] ); ?></a></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="item">
                        <div class="contact-form">
                            <div class="uk-section-title section-title">
                                <span <?php echo $this-> get_render_attribute_string('top_title'); ?>><?php echo wp_kses_post( $settings['top_title'] ); ?></span>
                                <h2 <?php echo $this-> get_render_attribute_string('title'); ?>><?php echo wp_kses_post( $settings['title'] ); ?></h2>
                                <div class="bar"></div>
                            </div>

                            <?php echo do_shortcode( $settings['contact_form'] ); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
	}
}

Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Contact_Two );