<?php
/**
 * Testimonial Widget
 */

namespace Elementor;
class Gunter_Testimonial extends Widget_Base {

	public function get_name() {
        return 'Testimonial';
    }

	public function get_title() {
        return __( 'Testimonials', 'gunter-toolkit' );
    }

	public function get_icon() {
        return 'eicon-testimonial-carousel';
    }

	public function get_categories() {
        return [ 'gunter-elements' ];
    }

	protected function register_controls() {

        $this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Content', 'gunter-toolkit' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
        );
            $this->add_control(
                'card_style',
                [
                    'label' => __( 'Version', 'gunter-toolkit' ),
                    'type' => Controls_Manager::SELECT,
                    'options' => [
                        'dark'      => __( 'Dark', 'gunter-toolkit' ),
                        'light'     => __( 'Light', 'gunter-toolkit' ),
                    ],
                    'default' => 'dark',
                ]
            );

            $this->add_control(
                'image',
                [
                    'label' => __( 'Image', 'gunter-toolkit' ),
                    'type' => Controls_Manager::MEDIA,
                ]
            );

            $this->add_control(
                'shape',
                [
                    'label' => __( 'Show Image Shape', 'gunter-toolkit' ),
                    'type' =>Controls_Manager::SWITCHER,
                    'label_on' => __( 'Show', 'gunter-toolkit' ),
                    'label_off' => __( 'Hide', 'gunter-toolkit' ),
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );

            $this->add_control(
                'button_text',
                [
                    'label' => __( 'Video Button Text', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Watch Video', 'gunter-toolkit'),
                ]
            );

            $this->add_control(
                'video_link',
                [
                    'label'=>esc_html__('Video Link', 'gunter-toolkit'),
                    'type'=>Controls_Manager:: URL,
                ]
            );

            $this->add_control(
                'top_title',
                [
                    'label' => __( 'Top Title', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('What Client Says About Us', 'gunter-toolkit'),
                ]
            );
            $this->add_control(
                'title',
                [
                    'label' => __( 'Title', 'gunter-toolkit' ),
                    'type' => Controls_Manager::TEXT,
                    'default' => __('Our Testimonials', 'gunter-toolkit'),
                ]
            );

            $repeater = new Repeater();

            $repeater->add_control(
                'name',
                [
                    'label' => esc_html__('Name', 'gunter-toolkit'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('Steven Smith', 'gunter-toolkit'),
                    'label_block' => true,
                ]
            );
            $repeater->add_control(
                'designation',
                [
                    'label' => esc_html__('Designation', 'gunter-toolkit'),
                    'type' => Controls_Manager::TEXT,
                    'default' => esc_html__('CTO at Envato', 'gunter-toolkit'),
                    'label_block' => true,
                ]
            );
            $repeater->add_control(
                'feedback',
                [
                    'label' => esc_html__('Feedback', 'gunter-toolkit'),
                    'type' => Controls_Manager::TEXTAREA,
                    'default' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum  ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed tempor incididunt ut labore et dolore.', 'gunter-toolkit'),
                    'label_block' => true,
                ]
            );

            $this->add_control(
                'testimonial_items',
                [
                    'label' => esc_html__('Slider Item', 'gunter-toolkit'),
                    'type' => Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                ]
            );
        $this->end_controls_section();
    }

	protected function render() {

        $settings       = $this->get_settings_for_display();

        global $opt_name;
		if( isset( $opt_name['enable_lazyloader'] ) ):
			$is_lazyloader = $opt_name['enable_lazyloader'];
		else:
			$is_lazyloader = true;
        endif;

        $slider         = $settings['testimonial_items'];
        $card_style     = $settings['card_style'];

        $dark_class = '';
        if($card_style == 'dark'){
            $dark_class = 'uk-dark';
        }

        ?>
            <div id="clients" class="feedback-area uk-section uk-feedback <?php echo wp_kses_post( $dark_class ); ?>">
                <div class="uk-container">
                    <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
                        <div class="item">
                            <div class="feedback-img">

                                <?php if( $settings['image']['url'] != '' ):?>
                                    <?php if( $is_lazyloader == true ): ?>
                                        <img class="smartify" sm-src="<?php echo esc_url( $settings['image']['url'] ); ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo esc_url( $settings['image']['url'] ); ?>" alt="<?php echo esc_attr( $settings['title'] ); ?>">
                                    <?php endif; ?>

                                    <?php if( $settings['shape'] == 'yes' ): ?>
                                        <?php if( $is_lazyloader == true ): ?>
                                            <img class="smartify shape-img" sm-src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/1.png'); ?>" alt="<?php echo esc_attr(  $settings['title'] ); ?>">
                                        <?php else: ?>
                                            <img src="<?php echo esc_url(get_template_directory_uri() .'/assets/img/1.png'); ?>" class="shape-img" alt="<?php echo esc_attr(  $settings['title'] ); ?>">
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endif; ?>

                                <?php if( $settings['button_text'] != '' ): ?>
                                    <a href="<?php echo esc_url( $settings['video_link']['url'] ); ?>" class="video-btn popup-youtube"><i class="flaticon-multimedia"></i> <?php echo wp_kses_post( $settings['button_text'] ); ?></a>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="item">
                            <div class="feedback-inner">
                                <div class="uk-section-title section-title">
                                    <span><?php echo wp_kses_post( $settings['top_title'] ); ?></span>
                                    <h2><?php echo wp_kses_post( $settings['title'] ); ?></h2>
                                    <div class="bar"></div>
                                </div>

                                <div class="feedback-slides owl-carousel owl-theme">
                                    <?php foreach( $slider as $item ): ?>
                                        <div class="single-feedback">
                                            <i class="flaticon-quote"></i>
                                            <p><?php echo wp_kses_post( $item['feedback'] ); ?></p>
                                            <div class="client">
                                                <h3><?php echo wp_kses_post( $item['name'] ); ?></h3>
                                                <span><?php echo wp_kses_post( $item['designation'] ); ?></span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php
	}

}
Plugin::instance()->widgets_manager->register_widget_type( new Gunter_Testimonial );