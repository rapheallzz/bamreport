<?php

// Flat icons
function gunter_icons() {
    return [
        'flaticon-quality'              => 'Quality',
        'flaticon-domain-registration'  => 'Domain Registration',
        'flaticon-targeting'            => 'Targeting',
        'flaticon-search-engine'        => 'Search Engine',
        'flaticon-idea'                 => 'Idea',
        'flaticon-pay-per-click'        => 'Pay Per Click',
        'flaticon-analytics-1'          => 'Analytics 1',
        'flaticon-analytics-2'          => 'Analytics 2',
        'flaticon-link'                 => 'Link',
        'flaticon-translation'          => 'Translation',
        'flaticon-bug'                  => 'Bug',
        'flaticon-mail'                 => 'Mail',
        'flaticon-magnifying-glass'     => 'Magnifying Glass',
        'flaticon-think'                => 'Think',
        'flaticon-shout'                => 'Shout',
        'flaticon-ux-design'            => 'UX Design',
        'flaticon-camera'               => 'Camera',
        'flaticon-data'                 => 'Data',
        'flaticon-chat'                 => 'Chat',
        'flaticon-stats'                => 'Stats',
        'flaticon-project'              => 'Project',
        'flaticon-quote'                => 'Quote',
        'flaticon-facebook'             => 'Facebook',
        'flaticon-instagram'            => 'Instagram',
        'flaticon-twitter'              => 'Twitter',
        'flaticon-linkedin'             => 'Linkedin',
        'flaticon-down-arrow'           => 'Down Arrow',
        'flaticon-back'                 => 'Back',
        'flaticon-multimedia'           => 'Multimedia',
        'flaticon-search'               => 'Search',
        'flaticon-edit'                 => 'Edit',
        'flaticon-plus'                 => 'Plus',
        'flaticon-line'                 => 'Line',
        'flaticon-tick'                 => 'Tick',
        'flaticon-chevron'              => 'Chevron',
    ];
}

function gunter_include_icons() {
    return array_keys(gunter_icons());
}