<?php
function gunter_services_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'count'         => '',
        'style'         => '',
        'read_more'     => '',
        'pagination'    => '',
        'link_type'     => 'show',
        'animation'     => '',
        'cat_name'      => '',
        'top_title'     => '',
        'title'         => '',
        'img'           => '',
    ), $atts) );

    global $opt_name;
    if( isset( $opt_name['enable_lazyloader'] ) ):
        $is_lazyloader = $opt_name['enable_lazyloader'];
    else:
        $is_lazyloader = true;
    endif;
    
    $domain = 'gunter-toolkit';

    // Services Query
    if( $cat_name != '' ) {
        $args = array(
            'post_type'     => 'service',
            'posts_per_page'=> $count,
            'tax_query'     => array(
                array(
                    'taxonomy'      => 'service_cat',
                    'field'         => 'slug',
                    'terms'         => $cat_name,
                    'hide_empty'    => false
                )
            ),
            'paged' => get_query_var('paged') ? get_query_var('paged') : 1
        );
    } else {
        $args = array(
            'post_type'         => 'service',
            'posts_per_page'    => $count,
            'paged' => get_query_var('paged') ? get_query_var('paged') : 1
        );
    }
    $q = new WP_Query( $args ); 
    
    $gunter_services_markup ='';

    if($style == 1){ $gunter_services_markup .='
    <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s">';
        while($q->have_posts()): $q->the_post();
        $idd = get_the_ID();
        $title = get_the_title($idd);
        $act = get_field( "service_card_active" );
        $icon = get_field( "select_flat_icon" );

        // Post Link
        if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
            $post_link = get_the_permalink();
        } else {
            $post_link = get_field('external_link');
        }

        if(!$title == ''){
            $gunter_services_markup .='
                <div class="item">
                    <div class="single-services'; if(!$act == false){ $gunter_services_markup .=' active'; } $gunter_services_markup .='">
                        <div class="icon">
                            <i class="'.esc_attr( $icon, 'gunter-toolkit').'"></i>
                        </div>
                        <h3>'.esc_html( get_the_title($idd)).'</h3>';

                        if( $link_type == 'show' ): $gunter_services_markup .='
                            <i class="flaticon-right link-btn"></i>
                            <a href="'.esc_url($post_link).'" class="link uk-position-cover"></a>';
                        endif; $gunter_services_markup .='
                    </div>
                </div>';
        }
        endwhile;
        wp_reset_query();
        $gunter_services_markup .='
    </div>';
    }elseif($style == 3){ $gunter_services_markup .='
        <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s">';
            while($q->have_posts()): $q->the_post();
                $idd = get_the_ID();
                $title = get_the_title($idd);
                $icon = get_field( "select_flat_icon" );

                // Post Link
                if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
                    $post_link = get_the_permalink();
                } else {
                    $post_link = get_field('external_link');
                }

                $gunter_services_markup .='
                <div class="item">
                    <div class="services-box">
                        '; if( $is_lazyloader == true ): $gunter_services_markup .='
                            <img class="smartify" sm-src="'.get_the_post_thumbnail_url( $idd, 'gunter_service_single' ).'" alt="'.esc_attr(get_the_title()).'">
                        '; else: $gunter_services_markup .='
                            <img src="'.get_the_post_thumbnail_url( $idd, 'gunter_service_single' ).'" alt="'.esc_attr(get_the_title()).'">
                        '; endif; $gunter_services_markup .='
                        <div class="content">
                            <div class="icon">
                                <i class="'.esc_attr( $icon).'"></i>
                            </div>
                            <h3>'.esc_html( get_the_title($idd)).'</h3>
                        </div>

                        <div class="hover-content">
                            <div class="d-table">
                                <div class="d-table-cell">
                                    <div class="inner">
                                        <div class="icon">
                                            <i class="'.esc_attr( $icon).'"></i>
                                        </div>
                                        <h3>'.esc_html( get_the_title($idd)).'</h3>
                                        <p>'.esc_html(get_the_excerpt()).'</p>
                                        <a href="'.esc_url($post_link).'" class="details-btn"><i class="flaticon-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>';
            endwhile;
            wp_reset_query();
            $gunter_services_markup .='
        </div>';
    }elseif($style == 4){ $gunter_services_markup .='
        <div class="uk-container">
            <div class="services-slides owl-carousel owl-theme">';
                while($q->have_posts()): $q->the_post();
                    $idd = get_the_ID();
                    $title = get_the_title($idd);
                    $act = get_field( "service_card_active" );
                    $icon = get_field( "select_flat_icon" );

                    // Post Link
                    if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
                        $post_link = get_the_permalink();
                    } else {
                        $post_link = get_field('external_link');
                    }

                    $gunter_services_markup .='
                        <div class="services-box">
                            '; if( $is_lazyloader == true ): $gunter_services_markup .='
                                <img class="smartify" sm-src="'.get_the_post_thumbnail_url( $idd, 'gunter_service_single' ).'" alt="'.esc_attr(get_the_title()).'">
                            '; else: $gunter_services_markup .='
                                <img src="'.get_the_post_thumbnail_url( $idd, 'gunter_service_single' ).'" alt="'.esc_attr(get_the_title()).'">
                            '; endif; $gunter_services_markup .='
                            <div class="content">
                                <div class="icon">
                                    <i class="'.esc_attr( $icon).'"></i>
                                </div>
                                <h3>'.esc_html( get_the_title($idd)).'</h3>
                            </div>

                            <div class="hover-content">
                                <div class="d-table">
                                    <div class="d-table-cell">
                                        <div class="inner">
                                            <div class="icon">
                                                <i class="'.esc_attr( $icon).'"></i>
                                            </div>
                                            <h3>'.esc_html( get_the_title($idd)).'</h3>
                                            <p>'.esc_html(get_the_excerpt()).'</p>
                                            <a href="'.esc_url($post_link).'" class="details-btn"><i class="flaticon-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>';
                endwhile;
                wp_reset_query();
                $gunter_services_markup .='
            </div>
        </div>';
    }elseif($style == 2) {
        $gunter_services_markup .='
        <section class="services-area uk-services uk-section">
            <div class="uk-container">
                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s">';
                while($q->have_posts()): $q->the_post();
                    $idd = get_the_ID();
                    $title = get_the_title($idd);
                    $act = get_field( "service_card_active" );
                    $icon = get_field( "select_flat_icon" );

                    // Post Link
                    if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
                        $post_link = get_the_permalink();
                    } else {
                        $post_link = get_field('external_link');
                    }

                    if(!$title == ''){ $gunter_services_markup .='
                        <div class="item">
                            <div class="single-services-box">
                                <div class="icon">
                                    <i class="'.esc_attr( $icon).'"></i>
                                </div>
                                <h3><a href="'.esc_url($post_link).'">'.esc_html( get_the_title($idd)).'</a></h3>
                                <div class="bar"></div>
                                <p>'.esc_html(get_the_excerpt()).'</p>';
                                if($read_more){ $gunter_services_markup .='
                                    <a href="'.esc_url($post_link).'" class="link-btn"><span>'.esc_html($read_more, 'gunter-toolkit').'</span> <i class="flaticon-right"></i></a>';
                                } 

                                if($animation == false){
                                    $gunter_services_markup .='
                                        <div class="animation-img">
                                            '; if( $is_lazyloader == true ): $gunter_services_markup .='
                                                <img class="smartify" sm-src="'.esc_url(get_template_directory_uri().'/assets/img/shape1.svg').'" alt="'.esc_attr('shape-image').'">
                                                <img class="smartify" sm-src="'.esc_url(get_template_directory_uri().'/assets/img/shape2.svg').'" alt="'.esc_attr('shape-image').'">
                                                <img class="smartify" sm-src="'.esc_url(get_template_directory_uri().'/assets/img/shape3.svg').'" alt="'.esc_attr('shape-image').'">
                                                <img class="smartify" sm-src="'.esc_url(get_template_directory_uri().'/assets/img/shape1.svg').'" alt="'.esc_attr('shape-image').'">
                                                <img class="smartify" sm-src="'.esc_url(get_template_directory_uri().'/assets/img/shape2.svg').'" alt="'.esc_attr('shape-image').'">
                                                <img class="smartify" sm-src="'.esc_url(get_template_directory_uri().'/assets/img/shape3.svg').'" alt="'.esc_attr('shape-image').'">
                                                <img class="smartify" sm-src="'.esc_url(get_template_directory_uri().'/assets/img/shape1.svg').'" alt="'.esc_attr('shape-image').'">
                                                <img class="smartify" sm-src="'.esc_url(get_template_directory_uri().'/assets/img/shape2.svg').'" alt="'.esc_attr('shape-image').'">
                                                <img class="smartify" sm-src="'.esc_url(get_template_directory_uri().'/assets/img/shape3.svg').'" alt="'.esc_attr('shape-image').'">
                                            '; else: $gunter_services_markup .='
                                                <img src="'.esc_url(get_template_directory_uri().'/assets/img/shape1.svg').'" alt="'.esc_attr('shape-image').'">
                                                <img src="'.esc_url(get_template_directory_uri().'/assets/img/shape2.svg').'" alt="'.esc_attr('shape-image').'">
                                                <img src="'.esc_url(get_template_directory_uri().'/assets/img/shape3.svg').'" alt="'.esc_attr('shape-image').'">
                                                <img src="'.esc_url(get_template_directory_uri().'/assets/img/shape1.svg').'" alt="'.esc_attr('shape-image').'">
                                                <img src="'.esc_url(get_template_directory_uri().'/assets/img/shape2.svg').'" alt="'.esc_attr('shape-image').'">
                                                <img src="'.esc_url(get_template_directory_uri().'/assets/img/shape3.svg').'" alt="'.esc_attr('shape-image').'">
                                                <img src="'.esc_url(get_template_directory_uri().'/assets/img/shape1.svg').'" alt="'.esc_attr('shape-image').'">
                                                <img src="'.esc_url(get_template_directory_uri().'/assets/img/shape2.svg').'" alt="'.esc_attr('shape-image').'">
                                                <img src="'.esc_url(get_template_directory_uri().'/assets/img/shape3.svg').'" alt="'.esc_attr('shape-image').'">
                                            '; endif; $gunter_services_markup .='    
                                        </div>';
                                } $gunter_services_markup .='
                            </div>
                        </div>';
                    }
                    endwhile;
                    $gunter_services_markup .='
                </div>';
                $pagin    = 999999999; 
                $pageLinks  =  paginate_links( array(
                    "base"      => str_replace( $pagin, "%#%", get_pagenum_link( $pagin ) ),
                    "format"    => "?paged=%#%",
                    "current"   => max( 1, get_query_var("paged") ),
                    "total"     => $q->max_num_pages,
                    "prev_text" => __("<span class='flaticon-back'></span>","gunter-toolkit"),
                    "next_text" => __("<span class='flaticon-right'>","gunter-toolkit"),
                    "type"      => "list",
                ) );
        
            if(!is_front_page() && !is_home() && $pagination == false){
                $gunter_services_markup .= '
                <div class="custom-pagination-area">
                    '.wp_kses_post($pageLinks, 'gunter-toolkit').'
                </div>';    
            }  
            wp_reset_query();
            $gunter_services_markup .='
            </div>
        </section>';

    }elseif($style == 6){
        $image   = wp_get_attachment_image_src( $img, 'full' );
        $gunter_services_markup .='
        <div class="what-we-do-section uk-what-we-do">
            <div class="uk-container-expand">
                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
                    <div class="item">';
                        if( $image[0] != '' ): $gunter_services_markup .='
                            <div class="what-we-do-image" style="background-image:url('.esc_url( $image[0] ).')">
                                <img src="'.esc_url( $image[0] ).'" alt="'.esc_attr__( 'Services Image', 'gunter-toolkit' ).'">
                            </div>';
                        endif; $gunter_services_markup .='
                    </div>

                    <div class="item">
                        <div class="what-we-do-content">
                            <div class="content">
                                <div class="uk-section-title section-title">
                                    <span>'.esc_html( $top_title ).'</span>
                                    <h2>'.esc_html( $title ).'</h2>
                                    <div class="bar"></div>
                                </div>';
                                while($q->have_posts()): $q->the_post();
                                    $idd = get_the_ID();
                                    $title = get_the_title($idd);
                                    $act = get_field( "service_card_active" );
                                    $icon = get_field( "select_flat_icon" );
                            
                                    // Post Link
                                    if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
                                        $post_link = get_the_permalink();
                                    } else {
                                        $post_link = get_field('external_link');
                                    } $gunter_services_markup .='
                                        <div class="single-services'; if( !$act == false ){ $gunter_services_markup .=' active'; } $gunter_services_markup .='">
                                            <div class="icon">
                                                <i class="'.esc_attr( $icon, 'gunter-toolkit').'"></i>
                                            </div>
                                            <h3>'.esc_html( get_the_title( $idd ) ).'</h3>';

                                            if( $link_type == 'show' ): $gunter_services_markup .='
                                                <i class="flaticon-right link-btn"></i>
                                                <a href="'.esc_url( $post_link ).'" class="link uk-position-cover"></a>';
                                            endif; $gunter_services_markup .='
                                        </div>';
                                endwhile;
                                wp_reset_query();
                                $gunter_services_markup .='
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>';
    }elseif($style == 7){
        $image   = wp_get_attachment_image_src( $img, 'full' );
        $gunter_services_markup .='
        <div class="experience-area uk-experience">
            <div class="uk-container-expand">
                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
                    <div class="item">
                        <div class="experience-content">
                            <div class="content">
                                <div class="uk-section-title section-title">
                                    <span>'.esc_html( $top_title ).'</span>
                                    <h2>'.esc_html( $title ).'</h2>
                                    <div class="bar"></div>
                                </div>';
                                while($q->have_posts()): $q->the_post();
                                    $idd = get_the_ID();
                                    $title = get_the_title($idd);
                                    $act = get_field( "service_card_active" );
                                    $icon = get_field( "select_flat_icon" );
                            
                                    // Post Link
                                    if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
                                        $post_link = get_the_permalink();
                                    } else {
                                        $post_link = get_field('external_link');
                                    } $gunter_services_markup .='
                                    <div class="single-experience-box">
                                        <div class="icon">
                                            <i class="'.esc_attr( $icon, 'gunter-toolkit').'"></i>
                                        </div>
                                        <h3>'.esc_html( get_the_title( $idd ) ).'</h3>
                                        <p>'.get_the_excerpt( $idd ).'</p>
                                    </div>';
                                endwhile;
                                wp_reset_query();
                                $gunter_services_markup .='
                            </div>
                        </div>
                    </div>

                    <div class="item">';
                        if( $image[0] != '' ): $gunter_services_markup .='
                            <div class="experience-image" style="background-image:url('.esc_url( $image[0] ).')">
                                <img src="'.esc_url( $image[0] ).'" alt="'.esc_attr__( 'Services Image', 'gunter-toolkit' ).'">
                            </div>';
                        endif; $gunter_services_markup .='
                    </div>
                </div>
            </div>
        </div>';
    }
    return $gunter_services_markup;
}
add_shortcode('gunter_services', 'gunter_services_shortcode');