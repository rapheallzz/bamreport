<?php
function gunter_box_testimonials_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'img'           => '',
        'title'         => '',
        'name'          => '',
        'designation'   => '',
        'feed'          => '',
        'style'         => 1,
    ), $atts) );

    
    $domain = 'gunter-toolkit';
    $test_img = wp_get_attachment_image_src($img, 'large');

    global $opt_name;
    if( isset( $opt_name['enable_lazyloader'] ) ):
        $is_lazyloader = $opt_name['enable_lazyloader'];
    else:
        $is_lazyloader = true;
    endif;

    $gunter_box_testimonials_markup ='';

    if( $style == 2 ){$gunter_box_testimonials_markup .='
        <div class="single-feedback-item">
            <i class="flaticon-quote"></i>
            <p>'.wp_kses_post($feed).'</p>
            <div class="client-info">
                '; if( $is_lazyloader == true ): $gunter_box_testimonials_markup .='
                    <img class="smartify" sm-src="'.esc_url($test_img[0]).'" alt="'.esc_attr($name).'">
                '; else: $gunter_box_testimonials_markup .='
                    <img src="'.esc_url($test_img[0]).'" alt="'.esc_attr($name).'">
                '; endif; $gunter_box_testimonials_markup .='

                <h3>'.esc_html($name).'</h3>
                <span>'.esc_html($designation).'</span>
            </div>
        </div>
    ';}else{
    $gunter_box_testimonials_markup .='
    <div class="testimonials-item">
        <div class="testimonials-single-item">
            <p>'.wp_kses_post($feed).'</p>
        </div>

        <div class="quotation-profile">
            '; if( $is_lazyloader == true ): $gunter_box_testimonials_markup .='
                <img class="smartify" sm-src="'.esc_url($test_img[0], $domain).'" alt="'.esc_attr($name, $domain).'">
            '; else: $gunter_box_testimonials_markup .='
                <img src="'.esc_url($test_img[0], $domain).'" alt="'.esc_attr($name, $domain).'">
            '; endif; $gunter_box_testimonials_markup .='
            <div class="profile-info">
                <h3>'.esc_html($name, $domain).'</h3>
                <span>'.esc_html($designation, $domain).'</span>
            </div>
        </div>
    </div>';
    }
    return $gunter_box_testimonials_markup;
}
add_shortcode('gunter_box_testimonials', 'gunter_box_testimonials_shortcode');