<?php
function gunter_feature_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'title'        => '',
        'desc'         => '',
        'select'       => '',
        'fa_icon'      => '',
        'flaticon'     => '',
        'shape'        => '',
    ), $atts) );
    $domain = 'gunter-toolkit';

    if ($fa_icon != '') {
        $icon = $fa_icon;
    } elseif ($flaticon != '') {
        $icon = $flaticon;
    } else{
        $icon = '';
    }

    global $opt_name;
    if( isset( $opt_name['enable_lazyloader'] ) ):
        $is_lazyloader = $opt_name['enable_lazyloader'];
    else:
        $is_lazyloader = true;
    endif;

    $gunter_feature_markup ='
        <div class="uk-item">
            <div class="single-features-box '; if($select == 'one'){ $gunter_feature_markup .=' active'; } $gunter_feature_markup .='">';
            if(!$icon == '') { $gunter_feature_markup .='
                <div class="icon">
                    <i class="'.esc_attr__($icon, $domain).'"></i>
                </div>';
            } $gunter_feature_markup .='
                <h3>'.
                wp_kses_post($title, $domain).'</h3>
                <div class="bar"></div>
                <p>'.wp_kses_post($desc, $domain).'</p>

                <div class="dot-img">
                    '; if( $is_lazyloader == true ): $gunter_feature_markup .='
                        <img class="smartify color-dot" sm-src="'. esc_url(get_template_directory_uri() .'/assets/img/dot.png').'" alt="'.esc_attr($title, $domain).'">
                        <img class="smartify white-dot" sm-src="'. esc_url(get_template_directory_uri() .'/assets/img/white-dot.png').'" alt="'.esc_attr($title, $domain).'">
                    '; else: $gunter_feature_markup .='
                        <img src="'. esc_url(get_template_directory_uri() .'/assets/img/dot.png').'" alt="'.esc_attr($title, $domain).'" class="color-dot">
                        <img src="'. esc_url(get_template_directory_uri() .'/assets/img/white-dot.png').'" alt="'.esc_attr($title, $domain).'" class="white-dot">
                    '; endif; $gunter_feature_markup .='   
                </div>';

                if(!$shape == true){ $gunter_feature_markup .='
                <div class="animation-img">
                    '; if( $is_lazyloader == true ): $gunter_feature_markup .='
                        <img class="smartify" sm-src="'.esc_url(get_template_directory_uri().'/assets/img/shape1.svg').'" alt="'.esc_attr('shape-image').'">
                        <img class="smartify" sm-src="'.esc_url(get_template_directory_uri().'/assets/img/shape2.svg').'" alt="'.esc_attr('shape-image').'">
                        <img class="smartify" sm-src="'.esc_url(get_template_directory_uri().'/assets/img/shape3.svg').'" alt="'.esc_attr('shape-image').'">
                        <img class="smartify" sm-src="'.esc_url(get_template_directory_uri().'/assets/img/shape1.svg').'" alt="'.esc_attr('shape-image').'">
                        <img class="smartify" sm-src="'.esc_url(get_template_directory_uri().'/assets/img/shape2.svg').'" alt="'.esc_attr('shape-image').'">
                        <img class="smartify" sm-src="'.esc_url(get_template_directory_uri().'/assets/img/shape3.svg').'" alt="'.esc_attr('shape-image').'">
                        <img class="smartify" sm-src="'.esc_url(get_template_directory_uri().'/assets/img/shape1.svg').'" alt="'.esc_attr('shape-image').'">
                        <img class="smartify" sm-src="'.esc_url(get_template_directory_uri().'/assets/img/shape2.svg').'" alt="'.esc_attr('shape-image').'">
                        <img class="smartify" sm-src="'.esc_url(get_template_directory_uri().'/assets/img/shape3.svg').'" alt="'.esc_attr('shape-image').'">
                    '; else: $gunter_feature_markup .='
                        <img src="'.esc_url(get_template_directory_uri().'/assets/img/shape1.svg').'" alt="'.esc_attr('shape-image').'">
                        <img src="'.esc_url(get_template_directory_uri().'/assets/img/shape2.svg').'" alt="'.esc_attr('shape-image').'">
                        <img src="'.esc_url(get_template_directory_uri().'/assets/img/shape3.svg').'" alt="'.esc_attr('shape-image').'">
                        <img src="'.esc_url(get_template_directory_uri().'/assets/img/shape1.svg').'" alt="'.esc_attr('shape-image').'">
                        <img src="'.esc_url(get_template_directory_uri().'/assets/img/shape2.svg').'" alt="'.esc_attr('shape-image').'">
                        <img src="'.esc_url(get_template_directory_uri().'/assets/img/shape3.svg').'" alt="'.esc_attr('shape-image').'">
                        <img src="'.esc_url(get_template_directory_uri().'/assets/img/shape1.svg').'" alt="'.esc_attr('shape-image').'">
                        <img src="'.esc_url(get_template_directory_uri().'/assets/img/shape2.svg').'" alt="'.esc_attr('shape-image').'">
                        <img src="'.esc_url(get_template_directory_uri().'/assets/img/shape3.svg').'" alt="'.esc_attr('shape-image').'">
                    '; endif; $gunter_feature_markup .='
                </div>';
                } $gunter_feature_markup .='
            </div>
        </div>';
    return $gunter_feature_markup;
}
add_shortcode('gunter_feature', 'gunter_feature_shortcode');