<?php
function gunter_map_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'top_title'             => '',
        'location1_title'       => '',
        'location1_content'     => '',
        'location2_title'       => '',
        'location2_content'     => '',
        'select'                => '',
    ), $atts) );
    $domain = 'gunter-toolkit';

    global $opt_name;
    if( isset( $opt_name['enable_lazyloader'] ) ):
        $is_lazyloader = $opt_name['enable_lazyloader'];
    else:
        $is_lazyloader = true;
    endif;

    $gunter_map_markup ='
    <div class="item">
        <div class="map-img">'; 
            if(!$select == 'one'){ $gunter_map_markup .='
                '; if( $is_lazyloader == true ): $gunter_map_markup .='
                    <img class="smartify" sm-src="'. esc_url(get_template_directory_uri() .'/assets/img/map2.png').'" alt="'.esc_attr('map', $domain).'">
                '; else: $gunter_map_markup .='
                    <img src="'. esc_url(get_template_directory_uri() .'/assets/img/map2.png').'" alt="'.esc_attr('map', $domain).'">
               '; endif; $gunter_map_markup .=' 
            '; 
            }else{ $gunter_map_markup .='
                '; if( $is_lazyloader == true ): $gunter_map_markup .='
                    <img class="smartify" sm-src="'. esc_url(get_template_directory_uri() .'/assets/img/map.png').'" alt="'.esc_attr('map', $domain).'">
                '; else: $gunter_map_markup .='
                    <img src="'. esc_url(get_template_directory_uri() .'/assets/img/map.png').'" alt="'.esc_attr('map', $domain).'">
                '; endif; $gunter_map_markup .='
                '; 
            } $gunter_map_markup .='

            <div class="location uk-location1">
                <a href="#" class="active">
                    <div class="location-info">
                        <h5>'.esc_html__($location1_title, $domain).'</h5>
                        <span>'.esc_html__($location1_content, $domain).'</span>
                    </div>
                </a>
            </div>

            <div class="location uk-location2">
                <a href="#">
                    <div class="location-info">
                        <h5>'.esc_html__($location2_title, $domain).'</h5>
                        <span>'.esc_html__($location2_content, $domain).'</span>
                    </div>
                </a>
            </div>
        </div>
    </div>';
    return $gunter_map_markup;
}
add_shortcode('gunter_map', 'gunter_map_shortcode');