<?php
function gunter_why_choose_us_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'top_title'         => '',
        'title'             => '',
        'img'               => '',
        'icon_type'         => '',
        'flat-icon'         => '',
        'fa_icon'           => '',
        'content'           => '',
        'group_items'       => '',
    ), $atts) );

    global $opt_name;
    if( isset( $opt_name['enable_lazyloader'] ) ):
        $is_lazyloader = $opt_name['enable_lazyloader'];
    else:
        $is_lazyloader = true;
    endif;

    $domain = 'gunter-toolkit';

    $section_image = wp_get_attachment_image_src($img, 'large');

    $gunter_why_choose_us_markup ='
        <div class="why-choose-us-section uk-why-choose-us uk-section">
            <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-2@s">
                <div class="item">
                    <div class="why-choose-us-content">
                        <div class="uk-section-title section-title">
                            <span>'.esc_html($top_title).'</span>
                            <h2>'.esc_html($title).'</h2>
                            <div class="bar"></div>
                        </div>

                        <ul class="why-choose-us-text">';
                            $items = vc_param_group_parse_atts($atts['group_items']); 
                            foreach($items as $item){
                                if (!empty($item)) {
                                    if(isset($item['icon_type']) &&  isset($item['title']) && isset($item['content']) ):
                                        if( $item['icon_type'] == 'font-awesome' ):
                                            $icon = $item['fa_icon'];
                                        else:
                                            $icon = $item['flat-icon'];
                                        endif;
                                        $gunter_why_choose_us_markup .='

                                        <li>
                                            <div class="icon">
                                                <i class="'.esc_attr($icon).'"></i>
                                            </div>
                                            <h3>'.esc_html($item['title']).'</h3>
                                            <p>'.wp_kses_post($item['content']).'</p>
                                        </li>';
                                    endif;
                                }
                            }
                            $gunter_why_choose_us_markup .='
                        </ul>
                    </div>
                </div>

                <div class="item">
                    <div class="why-choose-us-image uk-text-center">
                        '; if( $is_lazyloader == true ): $gunter_why_choose_us_markup .='
                            <img class="smartify" sm-src="'.esc_url($section_image[0]).'" alt="'.esc_attr($title).'">
                        '; else: $gunter_why_choose_us_markup .='
                            <img src="'.esc_url($section_image[0]).'" alt="'.esc_attr($title).'">
                        '; endif; $gunter_why_choose_us_markup .='
                    </div>
                </div>
            </div>
        </div>';

    return $gunter_why_choose_us_markup;
}
add_shortcode('gunter_why_choose_us', 'gunter_why_choose_us_shortcode');