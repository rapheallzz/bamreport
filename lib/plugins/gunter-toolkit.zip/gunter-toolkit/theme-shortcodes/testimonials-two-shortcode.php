<?php
function gunter_testimonials_two_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'top_title'     => '',
        'title'         => '',
        'name'          => '',
        'designation'   => '',
        'feed'          => '',
        'image'         => '',
        'select'         => '',
    ), $atts) );

    global $opt_name;
    if( isset( $opt_name['enable_lazyloader'] ) ):
        $is_lazyloader = $opt_name['enable_lazyloader'];
    else:
        $is_lazyloader = true;
    endif;

    $domain = 'gunter-toolkit';

    $test = vc_param_group_parse_atts($atts['group_testimonials']); 

    $count = 0;
    foreach ( $test as $value ) {
        $count++;
    }
    $gunter_testimonials_markup ='
        <div id="testimonials" class="feedback-section uk-section '; if(!$select == 'one'){ $gunter_testimonials_markup .=' uk-dark'; } $gunter_testimonials_markup .='">
            <div class="uk-container">
                <div class="uk-grid" uk-grid>
                    <div class="uk-width-1-3@m">
                        <div class="uk-section-title section-title">
                            <span>'.esc_html($top_title).'</span>
                            <h2>'.esc_html($title).'</h2>
                            <div class="bar"></div>
                        </div>
                    </div>

                    <div class="uk-width-expand@m">';
                        if( $count == 1 ){ $gunter_testimonials_markup .='
                        <div>';
                        } elseif($count == 2) { $gunter_testimonials_markup .='
                        <div class="uk-container">
                            <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">';
                        } else { $gunter_testimonials_markup .='
                        <div class="feedback-slides-two owl-carousel owl-theme">';
                        }
                            foreach($test as $testimonial){
                                if (!empty($testimonial)) {
                                    if(isset($testimonial['name']) && isset($testimonial['designation']) && isset($testimonial['feed']) && isset($testimonial['image']) ): 
                                        $img = wp_get_attachment_image_src($testimonial['image'], 'large');

                                        if( $count == 2 ){ $gunter_testimonials_markup .='
                                            <div>';
                                        }  $gunter_testimonials_markup .='
                                                <div class="single-feedback-item">
                                                    <i class="flaticon-quote"></i>
                                                    <p>'.wp_kses_post($testimonial['feed']).'</p>
                                                    <div class="client-info">
                                                        '; if( $is_lazyloader == true ): $gunter_testimonials_markup .='
                                                            <img class="smartify" sm-src="'.esc_url($img[0]).'" alt="'.esc_attr($testimonial['name']).'">
                                                        '; else: $gunter_testimonials_markup .='   
                                                            <img src="'.esc_url($img[0]).'" alt="'.esc_attr($testimonial['name']).'">
                                                        '; endif; $gunter_testimonials_markup .='

                                                        <h3>'.esc_html($testimonial['name']).'</h3>
                                                        <span>'.esc_html($testimonial['designation']).'</span>
                                                    </div>
                                                </div>';
                                        if( $count == 2 ){ $gunter_testimonials_markup .='
                                            </div>';
                                        }
                                    endif;
                                }
                            }

                            if($count == 2) { $gunter_testimonials_markup .='
                                </div>';
                            } $gunter_testimonials_markup .='
                        </div>

                    </div>
                </div>                
            </div>
        </div>';
    return $gunter_testimonials_markup;
}
add_shortcode('gunter_testimonials_two', 'gunter_testimonials_two_shortcode');