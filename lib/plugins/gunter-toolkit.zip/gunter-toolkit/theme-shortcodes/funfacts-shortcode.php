<?php
function gunter_funfacts_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'icon_type'         => '',
        'uikit_icon'        => '',
        'fa_icon'           => '',
        'title'             => '',
        'number'            => '',
        'group_funfacts'    => '',
        'bg_image'          => '',
    ), $atts) );
    $domain = 'gunter-toolkit';

    
    $bg_img = wp_get_attachment_image_src($bg_image, 'large');

    $gunter_funfacts_markup ='
    <div class="funfacts-area uk-section uk-funfacts" style="background-image:url('.esc_url($bg_img['0']).');">
        <div class="uk-container">
            <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-4@m uk-child-width-1-2@s">';
                $funfacts = vc_param_group_parse_atts($atts['group_funfacts']); 
                foreach($funfacts as $item){
                    if (!empty($item)) {
                        if(isset($item['icon_type']) &&  isset($item['title']) && isset($item['number']) ):
                            if( $item['icon_type'] == 'font-awesome' ):
                                $icon = $item['fa_icon'];
                            else:
                                $icon = $item['uikit_icon'];
                            endif;
                            $gunter_funfacts_markup .='
                            <div class="item">
                                <div class="single-funfacts">
                                    <div class="icon">';

                                        if($item['icon_type'] == 'font-awesome'){ 
                                            $gunter_funfacts_markup .='<i class="'.esc_attr($icon).'"></i>';
                                        }else{ 
                                            $gunter_funfacts_markup .=' <i uk-icon="'.esc_attr($icon).'"></i>';
                                        } $gunter_funfacts_markup .='
                                    </div>
                                    <h3 class="odometer" data-count="'.esc_attr($item['number']).'">00</h3>
                                    <p>'.wp_kses_post($item['title']).'</p>
                                </div>
                            </div>';
                        endif;
                    }
                }
                $gunter_funfacts_markup .='
            </div>
        </div>
    </div>';

    return $gunter_funfacts_markup;
}
add_shortcode('gunter_funfacts', 'gunter_funfacts_shortcode');