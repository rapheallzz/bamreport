<?php
function gunter_contact_area_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'type'                      => '',
        'img'                       => '',
        'location_title'            => '',
        'top_title'                 => '',
        'title'                     => '',
        'contact_from_shortcode'    => '',
        'label_title'               => '',
        'value'                     => '',
        'value_link'                => '',
        'group_info'                => '',
    ), $atts) );

    global $opt_name;
    if( isset( $opt_name['enable_lazyloader'] ) ):
        $is_lazyloader = $opt_name['enable_lazyloader'];
    else:
        $is_lazyloader = true;
    endif;

    $contact_img = wp_get_attachment_image_src($img, 'large');

    $gunter_contact_area_markup ='';
    $gunter_contact_area_markup .='
        <div id="contact" class="contact-section uk-contact" '; if(!$type == 2){ $gunter_contact_area_markup .=' uk-dark'; } $gunter_contact_area_markup .='">
            <div class="uk-container-expand">
                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
                    <div class="item">
                        <div class="contact-image" style="background-image:url('.esc_url($contact_img[0]).');">
                            '; if( $is_lazyloader == true ): $gunter_contact_area_markup .='
                                <img class="smartify" sm-src="'.esc_url($contact_img[0]).'" alt="'.esc_attr($location_title).'">
                            '; else: $gunter_contact_area_markup .='
                                <img src="'.esc_url($contact_img[0]).'" alt="'.esc_attr($location_title).'">
                            '; endif; $gunter_contact_area_markup .='

                            <div class="contact-info">
                                <h3>'.esc_html($location_title).'</h3>
                                <ul>';
                                    $group_infos = vc_param_group_parse_atts($atts['group_info']); 
        
                                    foreach($group_infos as $item){
                                        if (!empty($item)) {
                                            if(isset($item['label_title']) && isset($item['value']) && isset($item['value_link'])) {
                                                $gunter_contact_area_markup .='
                                                <li>'.esc_html($item['label_title']).' <a href="'.esc_url($item['value_link']).'">'.esc_html($item['value']).'</a></li>';
                                            }
                                        }
                                    }
                                    $gunter_contact_area_markup .='
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="item">
                        <div class="contact-form">
                            <div class="uk-section-title section-title">
                                <span>'.esc_html($top_title).'</span>
                                <h2>'.esc_html($title).'</h2>
                                <div class="bar"></div>
                            </div>
                            '.do_shortcode( $content ).'
                        </div>
                    </div>
                </div>
            </div>
        </div>
    ';
    return $gunter_contact_area_markup;
}
add_shortcode('gunter_contact_area', 'gunter_contact_area_shortcode');