<?php
function gunter_testimonials_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'img'           => '',
        'top_title'     => '',
        'title'         => '',
        'video_btn'     => '',
        'video_link'    => '',
        'select'        => '',
        'name'          => '',
        'designation'   => '',
        'feed'          => '',
    ), $atts) );

    global $opt_name;
    if( isset( $opt_name['enable_lazyloader'] ) ):
        $is_lazyloader = $opt_name['enable_lazyloader'];
    else:
        $is_lazyloader = true;
    endif;
    
    $domain = 'gunter-toolkit';
    $test_img = wp_get_attachment_image_src($img, 'large');

    $gunter_testimonials_markup ='
        <div id="clients" class="feedback-area uk-section uk-feedback'; if(!$select == 'one'){ $gunter_testimonials_markup .=' uk-dark'; } $gunter_testimonials_markup .='">
            <div class="uk-container">
                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
                    <div class="item">
                        <div class="feedback-img">
                            '; if( $is_lazyloader == true ): $gunter_testimonials_markup .='
                                <img class="smartify" sm-src="'.esc_url($test_img[0], $domain).'" alt="'.esc_attr($title, $domain).'">
                                <img class="smartify shape-img" sm-src="'.esc_url(get_template_directory_uri() .'/assets/img/1.png').'" alt="'.esc_attr($title, $domain).'">
                            '; else: $gunter_testimonials_markup .='
                                <img src="'.esc_url($test_img[0], $domain).'" alt="'.esc_attr($title, $domain).'">
                                <img src="'.esc_url(get_template_directory_uri() .'/assets/img/1.png').'" class="shape-img" alt="'.esc_attr($title, $domain).'">
                            '; endif; $gunter_testimonials_markup .='

                            ';
                            if(!$video_btn == '') { $gunter_testimonials_markup .='
                                <a href="'.esc_url($video_link).'" class="video-btn popup-youtube"><i class="flaticon-multimedia"></i> '.esc_html__($video_btn, $domain).'</a>';
                            } $gunter_testimonials_markup .=' 
                        </div>
                    </div>

                    <div class="item">
                        <div class="feedback-inner">
                            <div class="uk-section-title section-title">
                                <span>'.esc_html__($top_title, $domain).'</span>
                                <h2>'.esc_html__($title, $domain).'</h2>
                                <div class="bar"></div>
                            </div>

                            <div class="feedback-slides owl-carousel owl-theme">';
                            
                            $test = vc_param_group_parse_atts($atts['group_testimonials']); 
                            foreach($test as $testimonial){
                                if (!empty($testimonial)) {
                                    if(isset($testimonial['name']) &&  isset($testimonial['designation']) && isset($testimonial['feed']) ): 
                                    $gunter_testimonials_markup .='
                                        <div class="single-feedback">
                                            <i class="flaticon-quote"></i>
                                            <p>'.esc_html__($testimonial['feed'], $domain).'</p>
                                            <div class="client">
                                                <h3>'.esc_html__($testimonial['name'], $domain).'</h3>
                                                <span>'.esc_html__($testimonial['designation'], $domain).'</span>
                                            </div>
                                        </div>';
                                    endif;
                                }
                            } $gunter_testimonials_markup .='
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>';
    return $gunter_testimonials_markup;
}
add_shortcode('gunter_testimonials', 'gunter_testimonials_shortcode');