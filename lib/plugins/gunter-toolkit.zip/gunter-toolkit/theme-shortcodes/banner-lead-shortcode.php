<?php
function gunter_banner_lead_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'title'         => '',
        'desc'          => '',
        'btn1'          => '',
        'btn2'          => '',
        'btn2_link'     => '',
        'version_type'  => 1,
        'img'     	  	=> 1,
        'external_link' => '',
        'link_to_page'  => '',
        'type'          => '1',
        'position'      => '',
    ), $atts) );
    $domain = 'gunter-toolkit';

    if($type == 1){
        $link_source = get_page_link($link_to_page); 
      } else {
          $link_source = $external_link;
      }

    $gunter_banner_lead_markup ='';
    if($position == 1) {  $gunter_banner_lead_markup .='
        <div class="uk-banner main-banner lead-generation-banner'; if($version_type == 2){ $gunter_banner_lead_markup .=' uk-dark">'; }else{ $gunter_banner_lead_markup .=' light-banner">'; } $gunter_banner_lead_markup .='
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="uk-container">
                        <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
                            <div clss="item">
                                <div class="main-banner-content">
                                    <h2>'.
                                    wp_kses_post($title, $domain).'</h2>
                                    <p>'.wp_kses_post($desc, $domain).'</p>';
                                    if(!$btn1 == '') { $gunter_banner_lead_markup .='
                                        <a href="'.esc_url($link_source, $domain).'" class="uk-button uk-button-default">'.esc_html__($btn1, $domain).'</a>';
                                    }
                                    if(!$btn2 == '') { $gunter_banner_lead_markup .='
                                        <a href="'.esc_url($btn2_link, $domain).'" class="video-btn popup-youtube"><span data-uk-icon="play"></span> '.esc_html__($btn2, $domain).'</a>';
                                    } $gunter_banner_lead_markup .='
                                </div>
                            </div>
                            <div clss="item">
                                <div class="lead-generation-form">
                                    '.do_shortcode($content).'
                                
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>';
    } else { $gunter_banner_lead_markup .='
        <div class="uk-banner main-banner lead-generation-banner form-left'; if($version_type == 2){ $gunter_banner_lead_markup .=' uk-dark">'; }else{ $gunter_banner_lead_markup .=' light-banner light-form-left">'; } $gunter_banner_lead_markup .='
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="uk-container">
                        <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
                            <div clss="item">
                                <div class="lead-generation-form">
                                    '.do_shortcode($content).'
                                
                                </div>
                            </div>
                            <div clss="item">
                                <div class="main-banner-content">
                                    <h2>'.wp_kses_post($title, $domain).'</h2>
                                    <p>'.wp_kses_post($desc, $domain).'</p>';
                                    if(!$btn1 == '') { $gunter_banner_lead_markup .='
                                        <a href="'.esc_url($link_source, $domain).'" class="uk-button uk-button-default">'.esc_html__($btn1, $domain).'</a>';
                                    }
                                    if(!$btn2 == '') { $gunter_banner_lead_markup .='
                                        <a href="'.esc_url($btn2_link, $domain).'" class="video-btn popup-youtube"><span data-uk-icon="play"></span> '.esc_html__($btn2, $domain).'</a>';
                                    } $gunter_banner_lead_markup .='
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>';
    }
    return $gunter_banner_lead_markup;
}
add_shortcode('gunter_banner_lead', 'gunter_banner_lead_shortcode');