<?php
function gunter_work_process_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'icon_type'         => '',
        'uikit_icon'        => '',
        'fa_icon'           => '',
        'title'             => '',
        'content'           => '',
        'group_works'       => '',
        'shape_image'       => '',
    ), $atts) );

    global $opt_name;
    if( isset( $opt_name['enable_lazyloader'] ) ):
        $is_lazyloader = $opt_name['enable_lazyloader'];
    else:
        $is_lazyloader = true;
    endif;
    
    $domain = 'gunter-toolkit';

    $gunter_team_markup ='
    <div class="uk-container">
        <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-4@m uk-child-width-1-2@s">';
            $works = vc_param_group_parse_atts($atts['group_works']); 
            foreach($works as $item){
                if (!empty($item)) {
                    if(isset($item['icon_type']) &&  isset($item['title']) && isset($item['content']) ):
                        if( $item['icon_type'] == 'font-awesome' ):
                            $icon = $item['fa_icon'];
                        else:
                            $icon = $item['uikit_icon'];
                        endif;
                        $gunter_team_markup .='
                        <div class="item">
                            <div class="single-process-box">
                                <div class="icon">';
                                    if($item['icon_type'] == 'font-awesome'){ 
                                        $gunter_team_markup .='<i class="'.esc_attr($icon).'"></i>';
                                    }else{ 
                                        $gunter_team_markup .=' <i uk-icon="'.esc_attr($icon).'"></i>';
                                    } $gunter_team_markup .='
                                </div>
                                <h3>'.esc_html($item['title']).'</h3>
                                <p>'.wp_kses_post($item['content']).'</p>
                            </div>
                        </div>';
                    endif;
                }
            }
            $gunter_team_markup .='
            <div class="item">
                <div class="process-arrow-icon">
                    '; if( $is_lazyloader == true ): $gunter_team_markup .='
                        <img class="smartify" sm-src="'.esc_url(get_template_directory_uri().'/assets/img/arrow.png').'" alt="'.esc_attr__('Work process', 'gunter-toolkit').'">
                    '; else: $gunter_team_markup .='
                        <img src="'.esc_url(get_template_directory_uri().'/assets/img/arrow.png').'" alt="'.esc_attr__('Work process', 'gunter-toolkit').'">
                    '; endif; $gunter_team_markup .='
                </div>
            </div>
        </div>
    </div>';

    if( $shape_image == true ): $gunter_team_markup .='
        <div class="shape-circle-img2">
            '; if( $is_lazyloader == true ): $gunter_team_markup .='
                <img class="smartify" sm-src="'.esc_url(get_template_directory_uri().'/assets/img/shape-img2.png').'" alt="'.esc_attr__('Work process', 'gunter-toolkit').'">
            '; else: $gunter_team_markup .='
                <img src="'.esc_url(get_template_directory_uri().'/assets/img/shape-img2.png').'" alt="'.esc_attr__('Work process', 'gunter-toolkit').'">
            '; endif; $gunter_team_markup .='
        </div>';
    endif;

    return $gunter_team_markup;
}
add_shortcode('gunter_work_process', 'gunter_work_process_shortcode');