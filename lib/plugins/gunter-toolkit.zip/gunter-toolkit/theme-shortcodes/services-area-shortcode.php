<?php
function gunter_service_area_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'icon_type'         => '',
        'uikit_icon'        => '',
        'fa_icon'           => '',
        'icon_class_name'   => '',
        'title'             => '',
        'description'       => '',
        'items'             => '',
        'title'             => '',

    ), $atts) );   

    $gunter_service_area_markup ='
    <div class="featured-services-area uk-featured-services uk-section">
        <div class="uk-container">
            <div class="uk-section-title section-title">
                <p>'.esc_html( $title ).'</p>
            </div>

            <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s">';

                $card_items = vc_param_group_parse_atts($atts['items']); 
                foreach($card_items as $item){
                    if ( !empty( $item ) ) {
                        $gunter_service_area_markup .='
                        <div class="uk-item">
                            <div class="single-featured-services-box">';
                                if( isset( $item['icon_type'] ) ):
                                    if( $item['icon_type'] == 'font-awesome' ):
                                        $icon = $item['fa_icon'];
                                    elseif( $item['icon_type'] == 'uikit' ):
                                        $icon = $item['uikit_icon'];
                                    else:
                                        $icon = $item['icon_class_name'];
                                    endif;
                                    $gunter_service_area_markup .='
                                    <div class="icon">';
                                        if($item['icon_type'] == 'font-awesome'){ 
                                            $gunter_service_area_markup .='<i class="'.esc_attr($icon).'"></i>';
                                        }elseif($item['icon_type'] == 'uikit'){ 
                                            $gunter_service_area_markup .=' <i uk-icon="'.esc_attr($icon).'"></i>';
                                        } else{
                                            $gunter_service_area_markup .=' <i class="'.esc_attr($icon).'"></i>';
                                        }
                                        $gunter_service_area_markup .='
                                    </div>';
                                endif;

                                if( isset( $item['title'] ) ): $gunter_service_area_markup .='
                                    <h3>'.esc_html($item['title']).'</h3>';
                                endif;
                                $gunter_service_area_markup .='
                                <div class="bar"></div>';
                                if( isset( $item['description'] ) ): $gunter_service_area_markup .='
                                    <p>'.esc_html($item['description']).'</p>';
                                endif;
                                $gunter_service_area_markup .='
                                <div class="bg-shape"><img src="'.get_template_directory_uri().'/assets/img/box-shape.png" alt="'.esc_attr__( 'SHape Image', 'gunter-toolkit' ).'"></div>
                            </div>
                        </div>';
                    } 
                }
                $gunter_service_area_markup .='
            </div>
        </div>
    </div>';

    return $gunter_service_area_markup;
}
add_shortcode('gunter_service_area', 'gunter_service_area_shortcode');