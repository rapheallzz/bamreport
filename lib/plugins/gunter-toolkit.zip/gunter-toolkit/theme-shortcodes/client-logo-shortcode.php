<?php
function gunter_client_logo_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'logos'         => '',
        'select'        => '',
        'style'         => 1,
        'top_title'     => '',
        'title'         => '',
    ), $atts) );

    global $opt_name;
    if( isset( $opt_name['enable_lazyloader'] ) ):
        $is_lazyloader = $opt_name['enable_lazyloader'];
    else:
        $is_lazyloader = true;
    endif;

    $logo_ids = explode(',', $logos);

    if( $style == 1 ):
        $gunter_client_logo_markup ='
            <div class="partner-area uk-section uk-padding-remove-top '; if(!$select == 'one'){ $gunter_client_logo_markup .=' uk-dark'; } $gunter_client_logo_markup .='">
                <div class="uk-container">
                    <div class="partner-slides owl-carousel owl-theme">';
                    foreach($logo_ids as $logo) {
                        $logo_array = wp_get_attachment_image_src($logo, 'large');
                        $gunter_client_logo_markup .='
                        <div class="item">
                            <a href="#">
                                '; if( $is_lazyloader == true ): $gunter_client_logo_markup .='
                                    <img src="'.esc_url($logo_array[0]).'" alt="'.esc_attr('logos', 'gunter-toolkit').'"/>
                                '; else: $gunter_client_logo_markup .='
                                    <img src="'.esc_url($logo_array[0]).'" alt="'.esc_attr('logos', 'gunter-toolkit').'"/>
                                '; endif; $gunter_client_logo_markup .='
                            </a>
                        </div>';
                    } $gunter_client_logo_markup .='
                    </div>
                </div>
            </div>';
        elseif( $style == 2 ):
            $gunter_client_logo_markup ='
                <div class="partner-area-two uk-partner uk-section bg-f5e7da">
                    <div class="uk-container">
                        <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-2@s">
                            <div class="item">
                                <div class="uk-section-title section-title">
                                    <span>'.esc_html( $top_title ).'</span>
                                    <h2>'.esc_html( $top_title ).'</h2>
                                    <div class="bar"></div>
                                </div>
                            </div>

                            <div class="item">
                                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s">';
                                    foreach($logo_ids as $logo) {
                                        $logo_array = wp_get_attachment_image_src($logo, 'large');
                                        $gunter_client_logo_markup .='
                                        <div class="item">
                                            <div class="partner-item">
                                                '; if( $is_lazyloader == true ): $gunter_client_logo_markup .='
                                                    <img src="'.esc_url($logo_array[0]).'" alt="'.esc_attr('logos', 'gunter-toolkit').'"/>
                                                '; else: $gunter_client_logo_markup .='
                                                    <img src="'.esc_url($logo_array[0]).'" alt="'.esc_attr('logos', 'gunter-toolkit').'"/>
                                                '; endif; $gunter_client_logo_markup .='
                                            </div>
                                        </div>';
                                    } $gunter_client_logo_markup .='
                                </div>
                            </div>
                        </div>
                    </div>
                </div>';
        endif;
    return $gunter_client_logo_markup;
}
add_shortcode('gunter_client_logo', 'gunter_client_logo_shortcode');