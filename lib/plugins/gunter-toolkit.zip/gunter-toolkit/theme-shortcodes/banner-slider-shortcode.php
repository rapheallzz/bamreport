<?php
function gunter_banner_slider_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'type'          => '1',
        'title'         => '',
        'desc'          => '',
        'img'           => '',
        'btn1'          => '',
        'btn1_link'     => '',
        'btn2'          => '',
        'btn2_link'     => '',
    ), $atts) );
    $domain = 'gunter-toolkit';

    $gunter_banner_slider_markup ='
        <div class="main-banner-slider' ; if($type == 2){ $gunter_banner_slider_markup .=' uk-dark';}$gunter_banner_slider_markup .=' owl-carousel owl-theme">';
            $slides = vc_param_group_parse_atts($atts['group_slides']); 
            if(!$slides == '') {
                foreach($slides as $slide) {
                    $image = wp_get_attachment_image_src($slide['img'], 'large');
                    if(isset($slide['img']) ):  
                    $gunter_banner_slider_markup .='
                    <div class="uk-banner main-banner" style="background-image:url('.esc_url($image[0], $domain).');">';
                    endif;
                    $gunter_banner_slider_markup .='
                        <div class="d-table">
                            <div class="d-table-cell">
                                <div class="uk-container">
                                    <div class="main-banner-content">';
                                        if(isset($slide['title']) ):
                                        $gunter_banner_slider_markup .='     
                                        <h2>'.esc_html__($slide['title'], $domain).'</h2>';
                                        endif;
                                        if(isset($slide['desc']) ):
                                        $gunter_banner_slider_markup .='
                                        <p>'.wp_kses_post($slide['desc'], $domain).'</p>';
                                        endif;
                                        $gunter_banner_slider_markup .='

                                        <div class="banner-btn">';
                                            if(isset($slide['btn1']) &&  isset($slide['btn1_link']) ):
                                            $gunter_banner_slider_markup .='   
                                            <a href="'.esc_url($slide['btn1_link'], $domain).'" class="uk-button uk-button-default">'.esc_html__($slide['btn1'], $domain).'</a>';
                                            endif;

                                            if(isset($slide['btn2']) &&  isset($slide['btn2_link']) ):
                                            $gunter_banner_slider_markup .='
                                            <a href="'.esc_url($slide['btn2_link'], $domain).'" class="video-btn popup-youtube">
                                                <span data-uk-icon="play"></span>
                                                '.esc_html__($slide['btn2'], $domain).'
                                            </a>';
                                            endif;
                                            $gunter_banner_slider_markup .='
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>';
                }
            } 
            $gunter_banner_slider_markup .='
        </div>';
    return $gunter_banner_slider_markup;
}
add_shortcode('gunter_banner_slider', 'gunter_banner_slider_shortcode');