<?php
function gunter_banner_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'title'         => '',
        'desc'          => '',
        'btn1'          => '',
        'btn2'          => '',
        'btn2_link'     => '',
        'img'     	  	=> 1,
        'style'         => '1',
        'video_link'    => '1',
        'type'          => '',
        'link_type'     => '',
        'link_to_page'  => '',
        'external_link' => '',
    ), $atts) );
    $domain = 'gunter-toolkit';

    if($link_type == 1){
        $link_source = get_page_link($link_to_page); 
      } else {
          $link_source = $external_link;
      }
    $banner_image = wp_get_attachment_image_src($img, 'large');
    if($style == 'video') {
    $gunter_banner_markup ='
        <div class="video-banner-bg '; if($type == 2){ $gunter_banner_markup .=' uk-dark'; } $gunter_banner_markup .='">
            <div class="video-area">
                <video id="bgvid" loop autoPlay muted>
                    <source src="'.esc_url($video_link, $domain).'" type="'.esc_attr('video/mp4', $domain).'" />
                </video>
            </div>    

            <div class="uk-banner main-banner">
                <div class="d-table">
                    <div class="d-table-cell">
                        <div class="uk-container">
                            <div class="main-banner-content">
                                <h2>'.
                                wp_kses_post($title, $domain).'</h2>
                                <p>'.wp_kses_post($desc, $domain).'</p>';
                                if(!$btn1 == '') { $gunter_banner_markup .='
                                    <a href="'.esc_url($link_source, $domain).'" class="uk-button uk-button-default">'.esc_html__($btn1, $domain).'</a>';
                                }
                                if(!$btn2 == '') { $gunter_banner_markup .='
                                    <a href="'.esc_url($btn2_link, $domain).'" class="video-btn popup-youtube"><span data-uk-icon="play"></span> '.esc_html__($btn2, $domain).'</a>';
                                } $gunter_banner_markup .='
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>';
    }else {
    $gunter_banner_markup ='
        <div class="uk-banner main-banner'; if($type == 2){ $gunter_banner_markup .=' uk-dark'; } if($style == 2){ $gunter_banner_markup .=' banner-left-img'; } $gunter_banner_markup .='" style="background-image:url('.esc_url($banner_image[0]).');">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="uk-container">
                        <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">';
                            if($style == 2){ $gunter_banner_markup .='<div class="item"></div>'; }
                            $gunter_banner_markup .='
                            <div class="item">
                                <div class="main-banner-content">
                                    <h2>'.esc_html__($title, $domain).'</h2>
                                    <p>'.esc_html__($desc, $domain).'</p>';
                                    if(!$btn1 == '') { $gunter_banner_markup .='
                                        <a href="'.esc_url($link_source, $domain).'" class="uk-button uk-button-default">'.esc_html__($btn1, $domain).'</a>';
                                    }
                                    if(!$btn2 == '') { $gunter_banner_markup .='
                                        <a href="'.esc_url($btn2_link, $domain).'" class="video-btn popup-youtube"><span data-uk-icon="play"></span> '.esc_html__($btn2, $domain).'</a>';
                                    } $gunter_banner_markup .='
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>';
    }
    return $gunter_banner_markup;
}
add_shortcode('gunter_banner', 'gunter_banner_shortcode');