<?php
function gunter_pricing_plan_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'name'          => '',
        'price'         => '',
        'duration'      => '',
        'btnname'       => '',
        'button_bg'     => '',
        'type'     	  	=> 1,
        'icon'     	  	=> '',
        'icon_color'    => '',
        'style'     	=> 1,
        'shape_image'   => '',
        'link_to_page'  => '',
        'external_link' => '',
        'custom_class'  => '',
    ), $atts) );

    if($type == 1){
        $link_source = get_page_link($link_to_page); 
    } else {
        $link_source = $external_link;
    }

    $items = vc_param_group_parse_atts($atts['group_package_features']); 
    $image   = wp_get_attachment_image_src( $shape_image, 'full' );
    
    $domain = 'gunter-toolkit';
    $gunter_pricing_plan_markup ='';

    $gunter_pricing_plan_markup .='
    <div class="single-pricing-box">
        <div class="pricing-header">'; 
            if( $icon != '' ): $gunter_pricing_plan_markup .='
                <div class="icon" style="color:'.esc_attr( $icon_color ).'">
                    <i class="'. $icon .'"></i>'; 
                    if( $image[0] != '' ): $gunter_pricing_plan_markup .='
                        <img src="'.esc_url( $image[0] ).'" alt="'.esc_attr( 'Shape Image' ).'">';
                    endif; $gunter_pricing_plan_markup .='
                </div>';
            endif; $gunter_pricing_plan_markup .='
            <h3>'.esc_html( $name ).'</h3>
        </div>

        <div class="pricing-features">
            <ul>';
                foreach($items as $item){
                    if (!empty($item)) {
                        if(isset($item['feature'])):
                            $gunter_pricing_plan_markup .='
                            <li>'.esc_html($item['feature'] ).'</li>';
                        endif;
                    }
                }
                $gunter_pricing_plan_markup .='
            </ul>
        </div>

        <div class="price">
            '.esc_html( $price ).'
            <span>'.esc_html( $duration ).'</span>
        </div>';
        if ( ( $link_source != '') && ( $btnname != '' ) ) {
            $gunter_pricing_plan_markup .='
            <a href="'.esc_url($link_source).'" class="uk-button uk-button-default" style="background-color:'.esc_attr( $button_bg ).'; border-color:'.esc_attr( $button_bg ).'">'.esc_html($btnname).'</a>
            ';
        }
        $gunter_pricing_plan_markup .='
    </div>';
    return $gunter_pricing_plan_markup;
}
add_shortcode('gunter_pricing_plan', 'gunter_pricing_plan_shortcode');