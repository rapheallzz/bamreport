<?php
function gunter_team_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'name'          => '',
        'designation'   => '',
        'img'           => '',
        'style'         => '',
    ), $atts) );

    global $opt_name;
    if( isset( $opt_name['enable_lazyloader'] ) ):
        $is_lazyloader = $opt_name['enable_lazyloader'];
    else:
        $is_lazyloader = true;
    endif;

    $teams = vc_param_group_parse_atts($atts['group_teams']); 

    $count = 0;
    foreach ( $teams as $value ) {
        $count++;
    }
    
    $domain = 'gunter-toolkit';

    $gunter_team_markup ='';

    if($style == 1){
    $gunter_team_markup .='


    '; if( $count == 1 || $count == 2 || $count == 3 || $count == 4 ) { $gunter_team_markup .='
        <div class="uk-container">

            '; if( $count == 2 ) { $gunter_team_markup .='
                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s uk-flex-center">
            '; } elseif($count == 4) { $gunter_team_markup .='
                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-4@m uk-child-width-1-2@s uk-flex-center">
            '; } else { $gunter_team_markup .='
                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s uk-flex-center">
            '; } $gunter_team_markup .='


        '; } else { $gunter_team_markup .='
        <div class="team-slides owl-carousel owl-theme">
        '; } $gunter_team_markup .='

        ';
            foreach($teams as $team){
                if (!empty($team)) {
                    if(isset($team['name']) &&  isset($team['designation']) && isset($team['img']) ):
                        $image = wp_get_attachment_image_src($team['img'], 'large');
                        $socials = vc_param_group_parse_atts(($team['group_social'])); 
                        $gunter_team_markup .='
                        <div class="single-team">
                            <ul class="team-social">';
                                foreach($socials as $social){
                                    if (!empty($social)) {
                                        if(isset($social['link']) &&  isset($social['socialicon']) ):  
                                        $gunter_team_markup .='
                                        <li><a href="'.esc_attr__($social['link'], $domain).'"> <i class="'.esc_attr__($social['socialicon'], $domain).'"></i></a></li>';
                                        endif;
                                    }
                                }
                            $gunter_team_markup .='
                            </ul>

                            '; if( $is_lazyloader == true ): $gunter_team_markup .='
                                <img class="smartify" sm-src="'.esc_url($image[0]).'" alt="'.esc_attr__($team['name'], $domain).'">
                            '; else: $gunter_team_markup .='    
                                <img src="'.esc_url($image[0]).'" alt="'.esc_attr__($team['name'], $domain).'">
                            '; endif; $gunter_team_markup .='

                            <div class="team-content">
                                <h3>'.esc_html__($team['name'], $domain).'</h3>
                                <span>'.esc_html__($team['designation'], $domain).'</span>
                            </div>
                        </div>';
                    endif;
                }
            }
            $gunter_team_markup .='

        '; if( $count == 1 || $count == 2 || $count == 3 || $count == 4 ) { $gunter_team_markup .='  
        </div>
        '; } $gunter_team_markup .='

        </div>';
    }elseif($style == 3){
        $gunter_team_markup .='
        <div class="uk-container">
            <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s">';
            $teams = vc_param_group_parse_atts($atts['group_teams']); 
            foreach($teams as $team){
                if (!empty($team)) {
                    if(isset($team['name']) &&  isset($team['designation']) && isset($team['img']) ):
                        $image = wp_get_attachment_image_src($team['img'], 'large');
                        $socials = vc_param_group_parse_atts(($team['group_social'])); 
                        $gunter_team_markup .='
                        <div class="item">
                            <div class="single-team-box">
                                '; if( $is_lazyloader == true ): $gunter_team_markup .='
                                    <img class="smartify" sm-src="'.esc_url($image[0]).'" alt="'.esc_attr($team['name']).'">
                                '; else: $gunter_team_markup .='
                                    <img src="'.esc_url($image[0]).'" alt="'.esc_attr($team['name']).'">
                                '; endif; $gunter_team_markup .='

                                <div class="content">
                                    <h3>'.esc_html($team['name']).'</h3>
                                    <span>'.esc_html($team['designation']).'</span>

                                    <div class="social">
                                        <div class="social-btn">
                                            <span uk-icon="cog"></span>
                                        </div>
                                        <ul>';
                                            foreach($socials as $social){
                                                if (!empty($social)) {
                                                    if(isset($social['link']) &&  isset($social['socialicon']) ):  
                                                    $gunter_team_markup .='
                                                    <li><a href="'.esc_url($social['link']).'"> <i class="'.esc_attr($social['socialicon']).'"></i></a></li>';
                                                    endif;
                                                }
                                            }
                                        $gunter_team_markup .='
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>';
                    endif;
                }
            }
            $gunter_team_markup .='
            </div>
        </div>';
    }else{
        $gunter_team_markup .='
        <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s"> ';
            $teams = vc_param_group_parse_atts($atts['group_teams']); 
            foreach($teams as $team){
                if (!empty($team)) {
                    if(isset($team['name']) &&  isset($team['designation']) && isset($team['img']) ):
                        $image = wp_get_attachment_image_src($team['img'], 'large');
                        $socials = vc_param_group_parse_atts(($team['group_social'])); 
                        $gunter_team_markup .='
                        <div class="single-team mb-30">
                            <ul class="team-social">';
                                foreach($socials as $social){
                                    if (!empty($social)) {
                                        if(isset($social['link']) &&  isset($social['socialicon']) ):  
                                        $gunter_team_markup .='
                                        <li><a href="'.esc_URL($social['link']).'"> <i class="'.esc_attr($social['socialicon']).'"></i></a></li>';
                                        endif;
                                    }
                                }
                            $gunter_team_markup .='
                            </ul>

                            '; if( $is_lazyloader == true ): $gunter_team_markup .='
                                <img class="smartify" sm-src="'.esc_url($image[0]).'" alt="'.esc_attr($team['name']).'">
                            '; else: $gunter_team_markup .='
                                <img src="'.esc_url($image[0]).'" alt="'.esc_attr($team['name']).'">
                            '; endif; $gunter_team_markup .='
                            
                            <div class="team-content">
                                <h3>'.esc_html($team['name']).'</h3>
                                <span>'.esc_html($team['designation']).'</span>
                            </div>
                        </div>';
                    endif;
                }
            }
            $gunter_team_markup .='
        </div>';
        }
    return $gunter_team_markup;
}
add_shortcode('gunter_team', 'gunter_team_shortcode');