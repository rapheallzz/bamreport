<?php
function gunter_project_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'count'         => '',
        'select'        => '',
        'style'         => '',
        'pagination'    => '',
        'link_type'     => 'show',
        'cat'           => '',
        'order'         => '',
    ), $atts) );

    global $opt_name;
    if( isset( $opt_name['enable_lazyloader'] ) ):
        $is_lazyloader = $opt_name['enable_lazyloader'];
    else:
        $is_lazyloader = true;
    endif;

    $gunter_project_categories = get_terms('project_cat');
    $gunter_project_markup ='';

        if($style == 1){ $gunter_project_markup .= '

            '; if( $count == 1 || $count == 2 ) { $gunter_project_markup .='
            <div class="uk-container">

                '; if( $count == 2 ) { $gunter_project_markup .='
                    <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s uk-flex-center">
    
                '; } else { $gunter_project_markup .='
                    <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s uk-flex-center">
                '; } $gunter_project_markup .='


            '; } else { $gunter_project_markup .='
            <div class="project-slides owl-carousel owl-theme">
            '; } 

                if (!empty($cat)) {
                    $work_array = new \WP_Query(array(
                        'post_type' => 'project',
                        'posts_per_page' => $count,
                        'order' => $order,
                        'tax_query' => array(
                            array(
                                'taxonomy' => 'project_cat',
                                'field'    => 'slug',
                                'terms'    => explode( ',', str_replace( ' ', '', $cat)),
                            ),
                        ),
                    ));
                } else {
                    $work_array = new \WP_Query(array(
                        'post_type' => 'project',
                        'posts_per_page' => $count,
                        'order' => $order,
                    ));
                }
                while($work_array->have_posts()): $work_array->the_post();
                    // Post Link
                    if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
                        $post_link = get_the_permalink();
                    } else {
                        $post_link = get_field('external_link');
                    }

                    $idd = get_the_ID();
                    $work_category = get_the_terms(get_the_ID(), 'project_cat');
    
                    if($work_category && ! is_wp_error( $work_category )) {
                        $work_cat_list = array();
                        
                        foreach($work_category as $category) {
                        $work_cat_list[] = '<li>'.$category->name.'</li>'; 
                        $work_cat_slug[] = $category->slug; 
                        }
                        $work_assaigned_cat = join( " ", $work_cat_list );
                        $work_assaigned_slug = join( " ", $work_cat_slug );
                    } else {
                        $work_assaigned_cat = '';
                        $work_assaigned_slug = '';
                    }
                    $gunter_project_markup .= '
                    
                    <div class="single-projects'; if(!$select == 'one'){ $gunter_project_markup .=' owl-dark'; } $gunter_project_markup .='">';

                        if( $link_type == 'show' ): $gunter_project_markup .='
                            <a href="'.esc_url($post_link).'" class="project-img">
                                '; if( $is_lazyloader == true ): $gunter_project_markup .='
                                    <img class="smartify" sm-src="'.esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')).'" alt="'.esc_attr(get_the_title()).'">
                                '; else: $gunter_project_markup .='    
                                    <img src="'.esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')).'" alt="'.esc_attr(get_the_title()).'">
                                '; endif; $gunter_project_markup .='
                            </a>';
                        else: $gunter_project_markup .='
                            <div class="project-img">
                                '; if( $is_lazyloader == true ): $gunter_project_markup .='
                                    <img class="smartify" sm-src="'.esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')).'" alt="'.esc_attr(get_the_title()).'">
                                '; else: $gunter_project_markup .='    
                                    <img src="'.esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')).'" alt="'.esc_attr(get_the_title()).'">
                                '; endif; $gunter_project_markup .='
                            </div>';
                        endif; $gunter_project_markup .='
    
                        <div class="project-content">';
                            if( $link_type == 'show' ): $gunter_project_markup .='
                                <h3><a href="'.esc_url($post_link).'">'.esc_html(get_the_title()).'</a></h3>';
                            else: $gunter_project_markup .='
                                <h3>'.esc_html(get_the_title()).'</h3>';
                            endif; $gunter_project_markup .='

                            <ul>'.wp_kses_post($work_assaigned_cat, 'gunter-toolkit').'</ul>
                        </div>
                    </div>';
                endwhile;
                wp_reset_query();
                $gunter_project_markup .= '

            '; if( $count == 1 || $count == 2 ) { $gunter_project_markup .='  
            </div>
            '; } $gunter_project_markup .='

            </div>';
        }elseif($style == 3) {$gunter_project_markup .='
            <div class="uk-container">
                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s">';
                    if (!empty($cat)) {
                        $work_array = new \WP_Query(array(
                            'post_type' => 'project',
                            'posts_per_page' => $count,
                            'order' => $order,
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'project_cat',
                                    'field'    => 'slug',
                                    'terms'    => explode( ',', str_replace( ' ', '', $cat)),
                                ),
                            ),
                        ));
                    } else {
                        $work_array = new \WP_Query(array(
                            'post_type' => 'project',
                            'posts_per_page' => $count,
                            'order' => $order,
                        ));
                    }
                    while($work_array->have_posts()): $work_array->the_post();
                        // Post Link
                        if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
                            $post_link = get_the_permalink();
                        } else {
                            $post_link = get_field('external_link');
                        }

                        $idd = get_the_ID();
                        $work_category = get_the_terms(get_the_ID(), 'project_cat');
        
                        if($work_category && ! is_wp_error( $work_category )) {
                            $work_cat_list = array();
                            
                            foreach($work_category as $category) {
                            $work_cat_list[] = '<li>'.$category->name.'</li>'; 
                            $work_cat_slug[] = $category->slug; 
                            }
                            $work_assaigned_cat = join( " ", $work_cat_list );
                            $work_assaigned_slug = join( " ", $work_cat_slug );
                        } else {
                            $work_assaigned_cat = '';
                            $work_assaigned_slug = '';
                        }
                        $gunter_project_markup .= '
                        <div class="item">
                            <div class="single-project-box">';

                                if( $link_type == 'show' ): $gunter_project_markup .='
                                    <a href="'.esc_url($post_link).'" class="project-img">
                                        '; if( $is_lazyloader == true ): $gunter_project_markup .='
                                            <img class="smartify" sm-src="'.esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')).'" alt="'.esc_attr(get_the_title()).'">
                                        '; else: $gunter_project_markup .='  
                                            <img src="'.esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')).'" alt="'.esc_attr(get_the_title()).'">
                                        '; endif; $gunter_project_markup .='
                                    </a>';
                                else: $gunter_project_markup .='
                                    <div class="project-img">
                                        '; if( $is_lazyloader == true ): $gunter_project_markup .='
                                            <img class="smartify" sm-src="'.esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')).'" alt="'.esc_attr(get_the_title()).'">
                                        '; else: $gunter_project_markup .='    
                                            <img src="'.esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')).'" alt="'.esc_attr(get_the_title()).'">
                                        '; endif; $gunter_project_markup .='
                                    </div>';
                                endif; $gunter_project_markup .='

                                <div class="project-content">';
                                    if( $link_type == 'show' ): $gunter_project_markup .='
                                        <h3><a href="'.esc_url($post_link).'">'.esc_html(get_the_title()).'</a></h3>';
                                    else: $gunter_project_markup .='
                                        <h3>'.esc_html(get_the_title()).'</h3>';
                                    endif; $gunter_project_markup .='
                                    <ul>'.wp_kses_post($work_assaigned_cat, 'gunter-toolkit').'</ul>';

                                    if( $link_type == 'show' ): 
                                        $gunter_project_markup .='
                                            <a href="'.esc_url($post_link).'" class="details-btn"><i uk-icon="plus"></i></a>
                                        ';
                                    else: $gunter_project_markup .='';
                                    endif; $gunter_project_markup .='
                                </div>
                            </div>
                        </div>';
                    endwhile;
                    wp_reset_query();
                    $gunter_project_markup .= ' 
                </div>
            </div>
            <div class="shape-circle-img1">
                '; if( $is_lazyloader == true ): $gunter_project_markup .='
                    <img class="smartify" sm-src="'.esc_url(get_template_directory_uri().'/assets/img/shape-img1.png').'" alt="'.esc_attr__('shape-image', 'gunter-toolkit').'">
                '; else: $gunter_project_markup .='    
                    <img src="'.esc_url(get_template_directory_uri().'/assets/img/shape-img1.png').'" alt="'.esc_attr__('shape-image', 'gunter-toolkit').'">
                '; endif; $gunter_project_markup .='
            </div>';
        }elseif($style == 2) {
            $gunter_project_markup .='
            <div class="project-area uk-project uk-section">
                <div class="uk-container">
                    <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s">';
                    $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

                    if (!empty($cat)) {
                        $work_array = new \WP_Query(array(
                            'post_type' => 'project',
                            'posts_per_page' => $count,
                            'order' => $order,
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'project_cat',
                                    'field'    => 'slug',
                                    'terms'    => explode( ',', str_replace( ' ', '', $cat)),
                                ),
                            ),
                            'paged' => get_query_var('paged') ? get_query_var('paged') : 1
                        ));
                    } else {
                        $work_array = new \WP_Query(array(
                            'post_type' => 'project',
                            'posts_per_page' => $count,
                            'order' => $order,
                            'paged' => get_query_var('paged') ? get_query_var('paged') : 1
                        ));
                    }

                    while($work_array->have_posts()): $work_array->the_post();
                        // Post Link
                        if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
                            $post_link = get_the_permalink();
                        } else {
                            $post_link = get_field('external_link');
                        }

                        $idd = get_the_ID();
                        $work_category = get_the_terms(get_the_ID(), 'project_cat');
            
                            if($work_category && ! is_wp_error( $work_category )) {
                                $work_cat_list = array();
                                
                                foreach($work_category as $category) {
                                $work_cat_list[] = '<li>'.$category->name.'</li>'; 
                                $work_cat_slug[] = $category->slug; 
                                }
                                $work_assaigned_cat = join( " ", $work_cat_list );
                                $work_assaigned_slug = join( " ", $work_cat_slug );
                            } else {
                                $work_assaigned_cat = '';
                                $work_assaigned_slug = '';
                            }
                            $gunter_project_markup .= '
                            <div class="single-projects single-project-two">';

                                if( $link_type == 'show' ): $gunter_project_markup .='
                                    <a href="'.esc_url($post_link).'" class="project-img">
                                        '; if( $is_lazyloader == true ): $gunter_project_markup .='
                                            <img class="smartify" sm-src="'.esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')).'" alt="'.esc_attr(get_the_title()).'">
                                        '; else: $gunter_project_markup .='    
                                            <img src="'.esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')).'" alt="'.esc_attr(get_the_title()).'">
                                        '; endif; $gunter_project_markup .='
                                    </a>';
                                else: $gunter_project_markup .='
                                    <div class="project-img">
                                        '; if( $is_lazyloader == true ): $gunter_project_markup .='
                                            <img class="smartify" sm-src="'.esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')).'" alt="'.esc_attr(get_the_title()).'">
                                        '; else: $gunter_project_markup .='    
                                            <img src="'.esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image')).'" alt="'.esc_attr(get_the_title()).'">
                                        '; endif; $gunter_project_markup .='
                                    </div>';
                                endif; $gunter_project_markup .='

                                <div class="project-content">';
                                    if( $link_type == 'show' ): $gunter_project_markup .='
                                        <h3><a href="'.esc_url($post_link).'">'.esc_html(get_the_title()).'</a></h3>';
                                    else: $gunter_project_markup .='
                                        <h3>'.esc_html(get_the_title()).'</h3>';
                                    endif; $gunter_project_markup .='
                                    <ul>'.wp_kses_post($work_assaigned_cat, 'gunter-toolkit').'</ul>
                                </div>
                            </div>';
                    endwhile;
                    $gunter_project_markup .='
                    </div>';

                    $pagin    = 999999999; 
                    $pageLinks  =  paginate_links( array(
                        "base"      => str_replace( $pagin, "%#%", get_pagenum_link( $pagin ) ),
                        "format"    => "?paged=%#%",
                        "current"   => max( 1, get_query_var("paged") ),
                        "total"     => $work_array->max_num_pages,
                        "prev_text" => __("<span class='flaticon-back'></span>","gunter-toolkit"),
                        "next_text" => __("<span class='flaticon-right'>","gunter-toolkit"),
                        "type"      => "list",
                    ) );
            
                if(!is_front_page() && !is_home() && $pagination == false){
                    $gunter_project_markup .= '
                    <div class="custom-pagination-area">
                        '.wp_kses_post($pageLinks, 'gunter-toolkit').'
                    </div>';    
                }  
                wp_reset_query();
                $gunter_project_markup .='
                    
                </div>
            </div>';
        }elseif($style == 4 ) {
            if (!empty($cat)) {
                $work_array = new \WP_Query(array(
                    'post_type' => 'project',
                    'posts_per_page' => $count,
                    'order' => $order,
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'project_cat',
                            'field'    => 'slug',
                            'terms'    => explode( ',', str_replace( ' ', '', $cat)),
                        ),
                    ),
                ));
            } else {
                $work_array = new \WP_Query(array(
                    'post_type' => 'project',
                    'posts_per_page' => $count,
                    'order' => $order,
                ));
            }
            $gunter_project_markup .='
            <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-2@s">';
                $i = 1;
                while( $work_array->have_posts()): $work_array->the_post();
                    // Post Link
                    if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
                        $post_link = get_the_permalink();
                    } else {
                        $post_link = get_field('external_link');
                    }

                    $top_title = get_field( 'project_top_title' );

                    $idd = get_the_ID();
                    $work_category = get_the_terms(get_the_ID(), 'project_cat');
        
                        if($work_category && ! is_wp_error( $work_category )) {
                            $work_cat_list = array();
                            
                            foreach($work_category as $category) {
                            $work_cat_list[] = '<li>'.$category->name.'</li>'; 
                            $work_cat_slug[] = $category->slug; 
                            }
                            $work_assaigned_cat = join( " ", $work_cat_list );
                            $work_assaigned_slug = join( " ", $work_cat_slug );
                        } else {
                            $work_assaigned_cat = '';
                            $work_assaigned_slug = '';
                        }
                        if( $i == 1 || $i == 2 ):
                            $gunter_project_markup .= '
                            <div class="uk-item">
                                <div class="single-project-item">';
                                    if( $link_type == 'show' ): $gunter_project_markup .='
                                        <a href="'.esc_url($post_link).'" class="image">
                                            '; if( $is_lazyloader == true ): $gunter_project_markup .='
                                                <img class="smartify" sm-src="'.esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image_full')).'" alt="'.esc_attr(get_the_title()).'">
                                            '; else: $gunter_project_markup .='    
                                                <img src="'.esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image_full')).'" alt="'.esc_attr(get_the_title()).'">
                                            '; endif; $gunter_project_markup .='
                                        </a>';
                                    else: $gunter_project_markup .='
                                        <div class="image">
                                            '; if( $is_lazyloader == true ): $gunter_project_markup .='
                                                <img class="smartify" sm-src="'.esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image_two')).'" alt="'.esc_attr(get_the_title()).'">
                                            '; else: $gunter_project_markup .='    
                                                <img src="'.esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image_two')).'" alt="'.esc_attr(get_the_title()).'">
                                            '; endif; $gunter_project_markup .='
                                        </div>';
                                    endif; $gunter_project_markup .='

                                    <div class="content">';
                                        if( $link_type == 'show' ): $gunter_project_markup .='
                                            <a href="'.esc_url( $post_link ).'" class="category">'.esc_html( $top_title ).'</a>
                                            <h3><a href="'.esc_url( $post_link ).'">'.esc_html(get_the_title()).'</a></h3>';
                                        else: $gunter_project_markup .='
                                            <div class="category">'.esc_html( $top_title ).'</div>
                                            <h3>'.esc_html(get_the_title()).'</h3>';
                                        endif; $gunter_project_markup .='
                                    </div>
                                </div>
                            </div>';
                        endif;
                    $i++; endwhile;
                wp_reset_query();
                $gunter_project_markup .='
            </div>

            <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s">';
                $i2 = 1;
                while( $work_array->have_posts()): $work_array->the_post();
                    // Post Link
                    if ( class_exists('ACF') && get_field('choose_link_type') == 1 ) {
                        $post_link = get_the_permalink();
                    } else {
                        $post_link = get_field('external_link');
                    }

                    $top_title = get_field( 'project_top_title' );

                    $idd = get_the_ID();
                    $work_category = get_the_terms(get_the_ID(), 'project_cat');
        
                        if($work_category && ! is_wp_error( $work_category )) {
                            $work_cat_list = array();
                            
                            foreach($work_category as $category) {
                            $work_cat_list[] = '<li>'.$category->name.'</li>'; 
                            $work_cat_slug[] = $category->slug; 
                            }
                            $work_assaigned_cat = join( " ", $work_cat_list );
                            $work_assaigned_slug = join( " ", $work_cat_slug );
                        } else {
                            $work_assaigned_cat = '';
                            $work_assaigned_slug = '';
                        }
                        if( $i2 > 2 ):
                            $gunter_project_markup .= '
                            <div class="uk-item">
                                <div class="single-project-item">';
                                    if( $link_type == 'show' ): $gunter_project_markup .='
                                        <a href="'.esc_url($post_link).'" class="image">
                                            '; if( $is_lazyloader == true ): $gunter_project_markup .='
                                                <img class="smartify" sm-src="'.esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image_full')).'" alt="'.esc_attr(get_the_title()).'">
                                            '; else: $gunter_project_markup .='    
                                                <img src="'.esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image_full')).'" alt="'.esc_attr(get_the_title()).'">
                                            '; endif; $gunter_project_markup .='
                                        </a>';
                                    else: $gunter_project_markup .='
                                        <div class="image">
                                            '; if( $is_lazyloader == true ): $gunter_project_markup .='
                                                <img class="smartify" sm-src="'.esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image_two')).'" alt="'.esc_attr(get_the_title()).'">
                                            '; else: $gunter_project_markup .='    
                                                <img src="'.esc_url(get_the_post_thumbnail_url(get_the_ID(), 'gunter_project_image_two')).'" alt="'.esc_attr(get_the_title()).'">
                                            '; endif; $gunter_project_markup .='
                                        </div>';
                                    endif; $gunter_project_markup .='

                                    <div class="content">';
                                        if( $link_type == 'show' ): $gunter_project_markup .='
                                            <a href="'.esc_url( $post_link ).'" class="category">'.esc_html( $top_title ).'</a>
                                            <h3><a href="'.esc_url( $post_link ).'">'.esc_html(get_the_title()).'</a></h3>';
                                        else: $gunter_project_markup .='
                                            <div class="category">'.esc_html( $top_title ).'</div>
                                            <h3>'.esc_html(get_the_title()).'</h3>';
                                        endif; $gunter_project_markup .='
                                    </div>
                                </div>
                            </div>';
                        endif;
                    $i2++; endwhile;
                wp_reset_query();
                $gunter_project_markup .='
            </div>';
        }
    return $gunter_project_markup;
}
add_shortcode('gunter_project', 'gunter_project_shortcode');