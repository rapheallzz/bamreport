<?php
function gunter_about_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'top_title'     => '',
        'title'         => '',
        'img'           => '',
        'img1'          => '',
        'img2'          => '',
        'select'        => '',
        'icon_type'     => 1,
        'type'     	  	=> 1,
        'link_to_page'  => '',
        'external_link' => '',
        'btn1'          => '',
        'fa_icon'      => '',
        'flaticon'     => '',
        'shape_image'  => 'yes',
        'select_style' => '',
    ), $atts) );

    // icon
    if ($fa_icon != '') {
        $icon = $fa_icon;
    }elseif ($flaticon != '') {
        $icon = $flaticon;
    }else{
        $icon = '';
    }

    $domain = 'gunter-toolkit';
    $signature_img = wp_get_attachment_image_src($img, 'large');
    $img1 = wp_get_attachment_image_src($img1, 'large');
    $img2 = wp_get_attachment_image_src($img2, 'large');
    
    if( $img2 == false )
    {
        $img2[0] = '';
    }

    if($type == 1){
        $link_source = get_page_link($link_to_page); 
    } else {
        $link_source = $external_link;
    }

    $about_text_allowed_tags = array(
        'a' =>array(
            'href' => array(),
            'title' => array(),
            'class' => array()
        ),
        'img' => array(
            'alt' => array(),
            'src' => array()
        ),
        'br' => array(),
        'em' => array(),
        'strong' => array()
    );

    global $opt_name;
    if( isset( $opt_name['enable_lazyloader'] ) ):
        $is_lazyloader = $opt_name['enable_lazyloader'];
    else:
        $is_lazyloader = true;
    endif;

    $gunter_about_markup ='';
    if( $select_style == 'two' ){
        $gunter_about_markup .='
        <div class="uk-about about-area uk-section">
            <div class="uk-container">
                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
                    <div class="item">
                        <div class="about-image">';
                            if($img1[0] != '' ){ $gunter_about_markup .='
                                '; if( $is_lazyloader == true ): $gunter_about_markup .='
                                    <img class="smartify" sm-src="'.esc_url($img1[0]).'" alt="'.esc_attr__('about-img1', $domain).'">
                                '; else: $gunter_about_markup .='
                                    <img src="'.esc_url($img1[0]).'" alt="'.esc_attr__('about-img1', $domain).'">
                                '; endif; $gunter_about_markup .='
                            ';
                            } 

                            if($img2[0] != '' ){ $gunter_about_markup .='
                                '; if( $is_lazyloader == true ): $gunter_about_markup .='
                                    <img class="smartify" sm-src="'.esc_url($img2[0]).'" alt="'.esc_attr__('about-img', $domain).'">
                                '; else: $gunter_about_markup .='
                                    <img src="'.esc_url($img2[0]).'" alt="'.esc_attr__('about-img', $domain).'">
                                '; endif; $gunter_about_markup .='
                            ';
                            }
                            $gunter_about_markup .='
                        </div>
                    </div>

                    <div class="item">
                        <div class="about-content">
                            <div class="uk-section-title section-title">
                                <span>'.esc_html($top_title).'</span>
                                <h2>'.esc_html($title).'</h2>
                                <div class="bar"></div>
                            </div>

                            <div class="about-text">
                                <div class="icon">
                                    <i class="'.esc_attr($icon, $domain).'"></i>
                                </div>
                                '.wp_kses_post( __( $content, $domain ), $about_text_allowed_tags ).'

                                <div class="signature">';
                                    if($img1[0] != '' ){ $gunter_about_markup .='
                                        '; if( $is_lazyloader == true ): $gunter_about_markup .='
                                            <img class="smartify" sm-src="'.esc_url($signature_img[0]).'" alt="'.esc_attr($top_title).'">
                                        '; else: $gunter_about_markup .='
                                            <img src="'.esc_url($signature_img[0]).'" alt="'.esc_attr($top_title).'">
                                        '; endif; $gunter_about_markup .='   
                                    ';
                                    }  $gunter_about_markup .='
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>';
            if($shape_image == 'yes' ){ $gunter_about_markup .='
                <div class="shape-circle-img1">
                    '; if( $is_lazyloader == true ): $gunter_about_markup .='
                        <img class="smartify" sm-src="'. esc_url(get_template_directory_uri() .'/assets/img/shape-img1.png').'" alt="'.esc_attr__('shape', $domain).'">
                    '; else: $gunter_about_markup .='
                        <img src="'. esc_url(get_template_directory_uri() .'/assets/img/shape-img1.png').'" alt="'.esc_attr__('shape', $domain).'">
                    '; endif; $gunter_about_markup .='
                </div>';
            } $gunter_about_markup .='

        </div>
        ';
    }else{ $gunter_about_markup .='
        <div class="uk-about about-area uk-section'; if(!$select == 'one'){ $gunter_about_markup .=' uk-dark'; } $gunter_about_markup .='">
            <div class="uk-container">
                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
                    <div class="item">
                        <div class="about-content">
                            <div id="about" class="uk-section-title section-title">
                                <span>'.esc_html($top_title).'</span>
                                <h2>'.esc_html($title).'</h2>
                                <div class="bar"></div>
                            </div>

                            <div class="about-text">';
                                if(!$icon == '') { $gunter_about_markup .='
                                    <div class="icon">
                                        <i class="'.esc_attr($icon, $domain).'"></i>
                                    </div>';
                                } $gunter_about_markup .='
                                '.wp_kses_post( __( $content, $domain ), $about_text_allowed_tags ).'

                                <div class="signature">';

                                    if($img1[0] != '' ){ $gunter_about_markup .='
                                        '; if( $is_lazyloader == true ): $gunter_about_markup .='
                                            <img class="smartify" sm-src="'.esc_url($signature_img[0], $domain).'" alt="'.esc_attr($top_title, $domain).'">
                                        '; else: $gunter_about_markup .='
                                            <img src="'.esc_url($signature_img[0], $domain).'" alt="'.esc_attr($top_title, $domain).'">
                                        '; endif; $gunter_about_markup .='  
                                    ';
                                    }  $gunter_about_markup .='
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="item">
                        <div class="about-img">';

                            if($img1[0] != '' ){ $gunter_about_markup .='
                                '; if( $is_lazyloader == true ): $gunter_about_markup .='
                                    <img class="smartify about-img1" sm-src="'.esc_url($img1[0], $domain).'" alt="'.esc_attr__('about-img', $domain).'">
                                '; else: $gunter_about_markup .='
                                    <img src="'.esc_url($img1[0], $domain).'" class="about-img1" alt="'.esc_attr__('about-img', $domain).'">
                                '; endif; $gunter_about_markup .='  
                            ';
                            } 

                            if($img2[0] != '' ){ $gunter_about_markup .='
                                '; if( $is_lazyloader == true ): $gunter_about_markup .='
                                    <img class="smartify about-img2" sm-src="'.esc_url($img2[0], $domain).'"  alt="'.esc_attr__('about-img', $domain).'">
                                '; else: $gunter_about_markup .='
                                    <img src="'.esc_url($img2[0], $domain).'" class="about-img2" alt="'.esc_attr__('about-img', $domain).'">
                               '; endif; $gunter_about_markup .=' 
                                ';
                            }

                            if($shape_image == 'yes' ){ $gunter_about_markup .='
                                '; if( $is_lazyloader == true ): $gunter_about_markup .='
                                    <img class="smartify shape-img" sm-src="'. esc_url(get_template_directory_uri() .'/assets/img/1.png').'" alt="'.esc_attr__('shape', $domain).'">
                                '; else: $gunter_about_markup .='
                                    <img src="'. esc_url(get_template_directory_uri() .'/assets/img/1.png').'" class="shape-img" alt="'.esc_attr__('shape', $domain).'">
                                '; endif; $gunter_about_markup .='
                                ';
                            } 
                            if(!$btn1 == '') { $gunter_about_markup .='
                                <a href="'.esc_url($link_source, $domain).'" class="uk-button uk-button-default lax" data-lax-translate-x="vh 100, -elh -100" data-lax-anchor="self">'.esc_html__($btn1, $domain).'<i class="flaticon-right"></i></a>';
                            }
                            $gunter_about_markup .='
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>';
    }
    return $gunter_about_markup;
}
add_shortcode('gunter_about', 'gunter_about_shortcode');