<?php

function gunter_news_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'style'     => 1,
        'order'     => '',
        'cat'       => '',
        'count'     => '',
        'btntext'   => '',
    ), $atts) );
    $domain = 'gunter-toolkit';

    global $opt_name;
    if( isset( $opt_name['enable_lazyloader'] ) ):
        $is_lazyloader = $opt_name['enable_lazyloader'];
    else:
        $is_lazyloader = true;
    endif;

    if (!empty($cat)) {
        $q = new WP_Query(array(
            'post_type' => 'post',
            'posts_per_page'=> $count,
            'order' => $order,
            'ignore_sticky_posts' => 1,
            'category_name' => $cat,
        ));
    }
    else {
        $q = new WP_Query(array(
            'post_type' => 'post',
            'ignore_sticky_posts' => 1,
            'posts_per_page' => $count,
            'order' => $order,
        ));
    }

        if( $style == 1 ):
            $gunter_news_markup ='
                <div class="blog-slides owl-carousel owl-theme">';
                    while($q->have_posts()): $q->the_post();
                        $idd = get_the_ID();
                        $title = get_the_title();
                        $post_date = get_the_date( 'j F' );
                        $gunter_news_markup .='
                            <div class="single-blog-post">
                                <div class="blog-post-image">
                                    <a href="'.get_the_permalink().'">
                                        '; if( $is_lazyloader == true ): $gunter_news_markup .='
                                            <img class="smartify" sm-src="'.(get_the_post_thumbnail_url($idd, 'gunter_news_image')).'" alt="'.esc_attr__($title, $domain).'">
                                        '; else: $gunter_news_markup .='
                                            <img src="'.(get_the_post_thumbnail_url($idd, 'gunter_news_image')).'" alt="'.esc_attr__($title, $domain).'">
                                        '; endif; $gunter_news_markup .='    
                                    </a>
                                </div>

                                <div class="blog-post-content">';
                                    if( isset( $opt_name['is_post_meta'] ) && $opt_name['is_post_meta'] == true ) {
                                        $gunter_news_markup .=' 
                                        <span class="date">'.esc_attr($post_date, $domain).'</span>';
                                    }
                                    $gunter_news_markup .='
                                    <h3><a href="'.get_the_permalink().'">'.wp_trim_words( get_the_title(), 9, ' ' ).'</a></h3>';
                                    if(!$btntext == ''){ $gunter_news_markup .='
                                        <a href="'.get_the_permalink().'" class="read-more">'.esc_html__($btntext).'</a>';
                                    } $gunter_news_markup .='
                                </div>
                            </div>';
                        endwhile;
                    wp_reset_query();
                    $gunter_news_markup .='
            </div>';
        elseif( $style == 2 ):
            $gunter_news_markup ='
            <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-3@m uk-child-width-1-2@s">';
                while($q->have_posts()): $q->the_post();
                    $idd = get_the_ID();
                    $title = get_the_title();
                    $post_date = get_the_date( 'j F' );
                    $gunter_news_markup .='

                    <div class="uk-item">
                        <div class="single-blog-post-item">
                            <a href="'.get_the_permalink().'" class="post-image">
                                '; if( $is_lazyloader == true ): $gunter_news_markup .='
                                    <img class="smartify" sm-src="'.(get_the_post_thumbnail_url($idd, 'gunter_news_image')).'" alt="'.esc_attr__($title, $domain).'">
                                '; else: $gunter_news_markup .='
                                    <img src="'.(get_the_post_thumbnail_url($idd, 'gunter_news_image')).'" alt="'.esc_attr__($title, $domain).'">
                                '; endif; $gunter_news_markup .=' 
                            </a>

                            <div class="post-content">';
                                $posttags = get_the_tags();
                                $count = 0; $sep = '';
                                if ( $posttags ) {
                                    foreach( $posttags as $tag ) {
                                        $count++;
                                        $gunter_news_markup .=' 
                                        <a class="category" href="'.get_tag_link($tag->term_id).'">'.$tag->name.'</a>';
                                        if( $count > 0 ) break;
                                    }
                                } $gunter_news_markup .=' 
                                <h3><a href="'.get_the_permalink().'">'.wp_trim_words( get_the_title(), 9, ' ' ).'</a></h3>
                            </div>
                        </div>
                    </div>';
                endwhile;
                wp_reset_query();
                $gunter_news_markup .='
            </div>';
        endif;
    return $gunter_news_markup;
    
}
add_shortcode('gunter_news', 'gunter_news_shortcode');