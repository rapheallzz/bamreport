<?php
function gunter_banner_two_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'section_ver'           => '',
        'title'                 => '',
        'marked_title'          => '',
        'desc'                  => '',
        'btn1'                  => '',
        'link_type'             => '',
        'link_to_page'          => '',
        'external_link'         => '',
        'desc'                  => '',
        'right_btn'             => '',
        'right_link_type'       => '',
        'right_link_to_page'    => '',
        'right_external_link'   => '',
        'img'                   => '',
    ), $atts) );

    $domain = 'gunter-toolkit';

    if($link_type == 1){
        $link_source = get_page_link($link_to_page); 
    } else {
        $link_source = $external_link;
    }

    if($right_link_type == 1){
        $right_link_source = get_page_link($right_link_to_page); 
    } else {
        $right_link_source = $right_external_link;
    }

    global $opt_name;
    if( isset( $opt_name['enable_lazyloader'] ) ):
        $is_lazyloader = $opt_name['enable_lazyloader'];
    else:
        $is_lazyloader = true;
    endif;

    $banner_image = wp_get_attachment_image_src($img, 'large');

    $gunter_banner_markup ='
        <div class="banner-section'; if($section_ver == 2){ $gunter_banner_markup .=' uk-dark'; } $gunter_banner_markup .='">
            <div class="uk-container-expand">
                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
                    <div class="item">
                        <div class="banner-content">
                            <div class="d-table">
                                <div class="d-table-cell">
                                    <div class="content">
                                        <h1>'.esc_html($title).' <span>'.esc_html($marked_title).'</span></h1>
                                        <p>'.wp_kses_post($desc).'</p>
                                        <div class="btn-box"> ';
                                            if(!$btn1 == '') { $gunter_banner_markup .='
                                                <a href="'.esc_url($link_source).'" class="uk-button uk-button-default">'.esc_html($btn1).'</a>';
                                            }

                                            if(!$right_btn== '') { $gunter_banner_markup .='
                                                <a href="'.esc_url($right_link_source).'" class="uk-button-optional">'.esc_html($right_btn).'</a>';
                                            } $gunter_banner_markup .='
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="item">
                        <div class="banner-image" style="background-image:url('.esc_url($banner_image[0]).');">
                            '; if( $is_lazyloader == true ): $gunter_banner_markup .='
                                <img class="smartify" sm-src="'.esc_url($banner_image[0]).'" alt="'.esc_attr( $title ).'">
                            '; else: $gunter_banner_markup .='
                                <img src="'.esc_url($banner_image[0]).'" alt="'.esc_attr( $title ).'">
                            '; endif; $gunter_banner_markup .='
                        </div>
                    </div>
                </div>
            </div>
        </div>';
        
    return $gunter_banner_markup;
}
add_shortcode('gunter_banner_two', 'gunter_banner_two_shortcode');