<?php
function gunter_separator_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'select'       => '',
        'style'        => 1,
    ), $atts) );
    $domain = 'gunter-toolkit';

    if( $style == 1 ):
        $gunter_separator_markup ='
        <div class="separate '; if(!$select == 'one'){ $gunter_separator_markup .=' uk-dark'; } $gunter_separator_markup .='">
            <div class="br-line"></div>
        </div>';
    elseif( $style == 2 ):
        $gunter_separator_markup ='
        <div class="uk-border">
            <div class="uk-container">
                <div class="uk-border"></div>
            </div>
        </div>';
    endif;
    return $gunter_separator_markup;
}
add_shortcode('gunter_separator', 'gunter_separator_shortcode');