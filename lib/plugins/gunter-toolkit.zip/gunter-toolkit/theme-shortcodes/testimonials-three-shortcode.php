<?php
function gunter_testimonials_three_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'shape_image'    => '',
        'name'          => '',
        'designation'   => '',
        'feed'          => '',
        'image'         => '',
        'select'        => '',
    ), $atts) );

    global $opt_name;
    if( isset( $opt_name['enable_lazyloader'] ) ):
        $is_lazyloader = $opt_name['enable_lazyloader'];
    else:
        $is_lazyloader = true;
    endif;

    $domain = 'gunter-toolkit';

    $test           = vc_param_group_parse_atts($atts['group_testimonials']); 
    $shape_image    = wp_get_attachment_image_src($atts['shape_image'], 'full');

    $gunter_testimonials_markup ='
        <div class="testimonials-section uk-testimonials uk-section '; if(!$select == 'one'){ $gunter_testimonials_markup .=' uk-dark'; } $gunter_testimonials_markup .='">
            <div class="uk-container">
                <div class="testimonials-slides owl-carousel owl-theme">';
                    foreach($test as $testimonial){
                        if (!empty($testimonial)) {
                            if(isset($testimonial['name']) && isset($testimonial['designation']) && isset($testimonial['feed']) && isset($testimonial['image']) ): 
                                $img = wp_get_attachment_image_src($testimonial['image'], 'full');
                                $gunter_testimonials_markup .='
                                <div class="single-testimonials-box">
                                    <div class="user-image">
                                        '; if( $is_lazyloader == true ): $gunter_testimonials_markup .='
                                            <img class="smartify user" sm-src="'.esc_url($img[0]).'" alt="'.esc_attr($testimonial['name']).'">
                                        '; else: $gunter_testimonials_markup .='   
                                            <img class="user" src="'.esc_url($img[0]).'" alt="'.esc_attr($testimonial['name']).'">
                                        '; endif; 
                                        if( $shape_image[0] != '' ):
                                            $gunter_testimonials_markup .='
                                            <img src="'.esc_url( $shape_image[0] ).'" alt="'.esc_attr( 'Shape Image' ).'" class="shape">';
                                        endif; $gunter_testimonials_markup .='
                                    </div>
                                    <p>'.wp_kses_post($testimonial['feed']).'</p>
                                    <div class="user-info">
                                        <h3>'.esc_html($testimonial['name']).'</h3>
                                        <span>'.esc_html($testimonial['designation']).'</span>
                                    </div>
                                </div>';
                            endif;
                        }
                    } $gunter_testimonials_markup .='
                </div>
            </div>
        </div>';
    return $gunter_testimonials_markup;
}
add_shortcode('gunter_testimonials_three', 'gunter_testimonials_three_shortcode');