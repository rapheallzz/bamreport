<?php
function gunter_corporate_banner_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'title'         => '',
        'desc'          => '',
        'btn1'          => '',
        'img'     	  	=> '',
        'shape1'     	=> '',
        'shape2'     	=> '',
        'shape3'     	=> '',
        'shape4'     	=> '',
        'type'          => '',
        'link_type'     => 1,
        'link_to_page'  => '',
        'external_link' => '',
        'bg_color'      => '',
    ), $atts) );

    if( $link_type == 1 ){
        $link_source = get_page_link( $link_to_page ); 
    } else {
        $link_source = $external_link;
    }

    $banner_image   = wp_get_attachment_image_src( $img, 'full' );
    $shape1         = wp_get_attachment_image_src( $shape1, 'full' );
    $shape2         = wp_get_attachment_image_src( $shape2, 'full' );
    $shape3         = wp_get_attachment_image_src( $shape3, 'full' );
    $shape4         = wp_get_attachment_image_src( $shape4, 'full' );

    $gunter_corporate_banner_markup ='
        <div class="uk-corporate-banner corporate-main-banner '; if($type == 2){ $gunter_corporate_banner_markup .=' uk-dark'; } $gunter_corporate_banner_markup .='" style="background-color:'.esc_attr( $bg_color ).'">
            <div class="uk-container-expand">
                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
                    <div class="uk-item">
                        <div class="corporate-banner-content">
                            <div class="content">
                                <h1>'.
                                wp_kses_post( $title ).'</h1>
                                <p>'.wp_kses_post( $desc ).'</p>';
                                if( !$btn1 == '' ) { $gunter_corporate_banner_markup .='
                                    <a href="'.esc_url( $link_source ).'" class="uk-button uk-button-default">'.esc_html( $btn1 ).'</a>';
                                } $gunter_corporate_banner_markup .='
                            </div>
                        </div>
                    </div>

                    <div class="uk-item">';
                        if( $banner_image[0] != '' ): $gunter_corporate_banner_markup .='
                            <div class="corporate-banner-image" style="background-image:url('.esc_url( $banner_image[0] ).');">
                                <img src="'.esc_url( $banner_image[0] ).'" alt="'.esc_attr( $title ).'">
                            </div>';
                        endif;
                        $gunter_corporate_banner_markup .='
                    </div>
                </div>
            </div>';
            
            if( $shape1[0] != '' ): $gunter_corporate_banner_markup .='
                <div class="shape1"><img src="'.esc_url( $shape1[0] ).'" alt="'.esc_attr( $title ).'"></div>';
            endif;
            if( $shape2[0] != '' ): $gunter_corporate_banner_markup .='
                <div class="shape2"><img src="'.esc_url( $shape2[0] ).'" alt="'.esc_attr( $title ).'"></div>';
            endif;
            if( $shape3[0] != '' ): $gunter_corporate_banner_markup .='
                <div class="shape3"><img src="'.esc_url( $shape3[0] ).'" alt="'.esc_attr( $title ).'"></div>';
            endif;
            if( $shape4[0] != '' ): $gunter_corporate_banner_markup .='
                <div class="shape4"><img src="'.esc_url( $shape4[0] ).'" alt="'.esc_attr( $title ).'"></div>';
            endif;
            $gunter_corporate_banner_markup .='
        </div>';
    return $gunter_corporate_banner_markup;
}
add_shortcode('gunter_corporate_banner', 'gunter_corporate_banner_shortcode');