<?php

function gunter_newsletter_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'title'         => '',
        'btn_text'      => '',
        'style'         => 1,
        'description'   => '',
        'placeholder'   => '',
        'select'        => '',
        'top_title'     => '',
        'bg_img'        => '',
        'select_mod'    => '2',
        'action_url'    => '',
    ), $atts) );
    $domain = 'gunter-toolkit';

    global $opt_name;
    if( isset( $opt_name['enable_lazyloader'] ) ):
        $is_lazyloader = $opt_name['enable_lazyloader'];
    else:
        $is_lazyloader = true;
    endif;
    if ($select_mod == 1):
        if( $style == 1 ):
        $gunter_newsletter_markup ='
        <div class="subscribe-area uk-section uk-subscribe bg-gray'; if(!$select == 'one'){ $gunter_newsletter_markup .=' uk-dark'; } $gunter_newsletter_markup .='">
            <div class="uk-container">
                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
                    <div class="item">
                        <h3>'.esc_html__($title, $domain).'</h3>
                    </div>

                    <div class="item">
                        <form class="newsletter-form mailchimp" method="post">
                            <input type="email" class="uk-input memail" placeholder="'.esc_attr($placeholder).'" name="EMAIL">';
                            if(!$btn_text == ''){  $gunter_newsletter_markup .='
                                <button type="submit" class="uk-button uk-button-default">'.esc_html__($btn_text, $domain).'</button>';
                            }  $gunter_newsletter_markup .='
                            <p class="mchimp-errmessage" style="display: none;"></p>
                            <p class="mchimp-sucmessage" style="display: none;"></p>
                        </form>
                    </div>
                </div>
            </div>

            <div class="shape">
                '; if( $is_lazyloader == true ): $gunter_newsletter_markup .='
                    <img class="smartify" sm-src="'. esc_url(get_template_directory_uri() .'/assets/img/footer-shape1.png').'" alt="'.esc_attr('shape', $domain).'">
                '; else: $gunter_newsletter_markup .='
                    <img src="'. esc_url(get_template_directory_uri() .'/assets/img/footer-shape1.png').'" alt="'.esc_attr('shape', $domain).'">
                '; endif; $gunter_newsletter_markup .='
            </div>
        </div>';
        elseif( $style == 2 ):
            $banner_image = wp_get_attachment_image_src($bg_img, 'full');
            $gunter_newsletter_markup ='
            <div class="uk-newsletter newsletter-area"'; if(!$select == 'one'){ $gunter_newsletter_markup .=' uk-dark'; } $gunter_newsletter_markup .='" style="background-image:url('.esc_url( $banner_image[0] ).');">
                <div class="uk-container">
                    <div class="newsletter-content">
                        <span class="sub-title">'.esc_html($top_title).'</span>
                        <h2>'.wp_kses_post($title).'</h2>
                        <p>'.wp_kses_post($description).'</p>
                        <form class="newsletter-form mailchimp" method="post">
                            <input type="email" class="uk-input memail" placeholder="'.esc_attr($placeholder).'" name="EMAIL">';
                            if(!$btn_text == ''){  $gunter_newsletter_markup .='
                                <button type="submit" class="uk-button uk-button-default">'.esc_html__($btn_text, $domain).'</button>';
                            }  $gunter_newsletter_markup .='
                        </form>
                        <p class="mchimp-errmessage" style="display: none;"></p>
                        <p class="mchimp-sucmessage" style="display: none;"></p>
                    </div>
                </div>
            </div>';
        endif;

        $gunter_newsletter_markup .=' 
        <script>
            ;(function($){
                "use strict";
                $(document).ready(function () {
                    // MAILCHIMP
                    if ($(".mailchimp").length > 0) {
                        $(".mailchimp").ajaxChimp({
                            callback: mailchimpCallback,
                            url: "'.esc_js($action_url).'"
                        });
                    }
                    if ($(".mailchimp_two").length > 0) {
                        $(".mailchimp_two").ajaxChimp({
                            callback: mailchimpCallback,
                            url: "'.esc_js($action_url).'"
                        });
                    }
                    $(".memail").on("focus", function () {
                        $(".mchimp-errmessage").fadeOut();
                        $(".mchimp-sucmessage").fadeOut();
                    });
                    $(".memail").on("keydown", function () {
                        $(".mchimp-errmessage").fadeOut();
                        $(".mchimp-sucmessage").fadeOut();
                    });
                    $(".memail").on("click", function () {
                        $(".memail").val("");
                    });

                    function mailchimpCallback(resp) {
                        if (resp.result === "success") {
                            $(".mchimp-sucmessage").html(resp.msg).fadeIn(1000);
                            $(".mchimp-sucmessage").fadeOut(500);
                        } else if (resp.result === "error") {
                            $(".mchimp-errmessage").html(resp.msg).fadeIn(1000);
                        }
                    }
                });
            })(jQuery)
        </script>';
    else:
        if( $style == 1 ):
        $gunter_newsletter_markup ='
        <div class="subscribe-area uk-section uk-subscribe bg-gray'; if(!$select == 'one'){ $gunter_newsletter_markup .=' uk-dark'; } $gunter_newsletter_markup .='">
            <div class="uk-container">
                <div class="uk-grid uk-grid-match uk-grid-medium uk-child-width-1-2@m uk-child-width-1-1@s">
                    <div class="item">
                        <h3>'.esc_html__($title, $domain).'</h3>
                    </div>

                    <div class="item">
                        <form class="newsletter-form" method="post" action="'.get_bloginfo().'/?na=s" onsubmit="return newsletter_check(this)">
                            <input type="email" class="uk-input" placeholder="'.esc_attr($placeholder).'" name="ne" required autocomplete="off">';
                            if(!$btn_text == ''){  $gunter_newsletter_markup .='
                                <button type="submit" class="uk-button uk-button-default">'.esc_html__($btn_text, $domain).'</button>';
                            }  $gunter_newsletter_markup .='
                        </form>
                    </div>
                </div>
            </div>

            <div class="shape">
                '; if( $is_lazyloader == true ): $gunter_newsletter_markup .='
                    <img class="smartify" sm-src="'. esc_url(get_template_directory_uri() .'/assets/img/footer-shape1.png').'" alt="'.esc_attr('shape', $domain).'">
                '; else: $gunter_newsletter_markup .='
                    <img src="'. esc_url(get_template_directory_uri() .'/assets/img/footer-shape1.png').'" alt="'.esc_attr('shape', $domain).'">
                '; endif; $gunter_newsletter_markup .='
            </div>
        </div>';
        elseif( $style == 2 ):
            $banner_image = wp_get_attachment_image_src($bg_img, 'full');
            $gunter_newsletter_markup ='
            <div class="uk-newsletter newsletter-area"'; if(!$select == 'one'){ $gunter_newsletter_markup .=' uk-dark'; } $gunter_newsletter_markup .='" style="background-image:url('.esc_url( $banner_image[0] ).');">
                <div class="uk-container">
                    <div class="newsletter-content">
                        <span class="sub-title">'.esc_html($top_title).'</span>
                        <h2>'.esc_html($title).'</h2>
                        <p>'.esc_html($description).'</p>
                        <form class="newsletter-form" method="post" action="'.get_bloginfo().'/?na=s" onsubmit="return newsletter_check(this)">
                            <input type="email" class="uk-input" placeholder="'.esc_attr($placeholder).'" name="ne" required autocomplete="off">';
                            if(!$btn_text == ''){  $gunter_newsletter_markup .='
                                <button type="submit" class="uk-button uk-button-default">'.esc_html__($btn_text, $domain).'</button>';
                            }  $gunter_newsletter_markup .='
                        </form>
                    </div>
                </div>
            </div>';
        endif;
    endif;
    return $gunter_newsletter_markup;
    
}
add_shortcode('gunter_newsletter', 'gunter_newsletter_shortcode');