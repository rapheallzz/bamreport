<?php
function gunter_section_shortcode($atts, $content = null){
    extract( shortcode_atts( array(
        'top_title'     => '',
        'title'         => '',
        'type'     	  	=> 1,
        'link_to_page'  => '',
        'external_link' => '',
        'btn1'          => '',
        'center'         => '',
    ), $atts) );
    $domain = 'gunter-toolkit';

    if($type == 1){
        $link_source = get_page_link($link_to_page); 
    } else {
        $link_source = $external_link;
    }
    if($center == true){
        $section_class = 'uk-text-center';
    }else{
        $section_class = '';
    }
    
    $gunter_section_markup ='
        <div class="uk-section-title section-title '.esc_attr($section_class).'">
            <span>'.esc_html__($top_title, $domain).'</span>
            <h2>'.esc_html__($title, $domain).'</h2>
            <div class="bar"></div>';
            if(!$btn1 == '') { $gunter_section_markup .='
                <a href="'.esc_url($link_source, $domain).'" class="uk-button uk-button-default">'.esc_html__($btn1, $domain).'<i class="flaticon-right"></i></a>';
            } $gunter_section_markup .='
        </div>';
    return $gunter_section_markup;
}
add_shortcode('gunter_section', 'gunter_section_shortcode');