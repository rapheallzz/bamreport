<?php
    /**
     * ReduxFramework Sample Config File
     * For full documentation, please visit: http://docs.reduxframework.com/
     */

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }


    // This is your option name where all the Redux data is stored.
    $opt_name = "opt_name";
    

    // This line is only for altering the demo. Can be easily removed.
    $opt_name = apply_filters( 'opt_name/opt_name', $opt_name );

    /*
     *
     * --> Used within different fields. Simply examples. Search for ACTUAL DECLARATION for field examples
     *
     */

    $sampleHTML = '';
    if ( file_exists( dirname( __FILE__ ) . '/info-html.html' ) ) {
        Redux_Functions::initWpFilesystem();

        global $wp_filesystem;

        $sampleHTML = $wp_filesystem->get_contents( dirname( __FILE__ ) . '/info-html.html' );
    }

    // Background Patterns Reader
    $sample_patterns_path = ReduxFramework::$_dir . '../sample/patterns/';
    $sample_patterns_url  = ReduxFramework::$_url . '../sample/patterns/';
    $sample_patterns      = array();
    
    if ( is_dir( $sample_patterns_path ) ) {

        if ( $sample_patterns_dir = opendir( $sample_patterns_path ) ) {
            $sample_patterns = array();

            while ( ( $sample_patterns_file = readdir( $sample_patterns_dir ) ) !== false ) {

                if ( stristr( $sample_patterns_file, '.png' ) !== false || stristr( $sample_patterns_file, '.jpg' ) !== false ) {
                    $name              = explode( '.', $sample_patterns_file );
                    $name              = str_replace( '.' . end( $name ), '', $sample_patterns_file );
                    $sample_patterns[] = array(
                        'alt' => $name,
                        'img' => $sample_patterns_url . $sample_patterns_file
                    );
                }
            }
        }
    }

    /**
     * ---> SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => true,
        // Show the sections below the admin menu item or not
        'menu_title'           => __( 'Gunter Options', 'gunter-toolkit' ),
        'page_title'           => __( 'Gunter Options', 'gunter-toolkit' ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => false,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => false,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => true,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-portfolio',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => false,
        // Show the time the page took to load, etc
        'update_notice'        => false,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => true,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => null,
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => 'kena_option',
        // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
        'save_defaults'        => true,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => false,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => true,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => true,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => true,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        // 'footer_credit'     => '',                   // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
        'use_cdn'              => true,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'red',
                'shadow'  => true,
                'rounded' => false,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );


    // Panel Intro text -> before the form
    if ( ! isset( $args['global_variable'] ) || $args['global_variable'] !== false ) {
        if ( ! empty( $args['global_variable'] ) ) {
            $v = $args['global_variable'];
        } else {
            $v = str_replace( '-', '_', $args['opt_name'] );
        }
        $args['intro_text'] = sprintf( __( '<p></p>', 'gunter-toolkit' ), $v );
    } else {
        $args['intro_text'] = __( '<p>This text is displayed above the options panel. It isn\'t required, but more info is always better! The intro_text field accepts all HTML.</p>', 'gunter-toolkit' );
    }

    Redux::setArgs( $opt_name, $args );

    /*
     * ---> END ARGUMENTS
     */


    /*
     * ---> START HELP TABS
     */

    $tabs = array(
        array(
            'id'      => 'redux-help-tab-1',
            'title'   => __( 'Theme Information 1', 'gunter-toolkit' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'gunter-toolkit' )
        ),
        array(
            'id'      => 'redux-help-tab-2',
            'title'   => __( 'Theme Information 2', 'gunter-toolkit' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'gunter-toolkit' )
        )
    );
    Redux::setHelpTab( $opt_name, $tabs );

    // Set the help sidebar
    $content = __( '<p>This is the sidebar content, HTML is allowed.</p>', 'gunter-toolkit' );
    Redux::setHelpSidebar( $opt_name, $content );


    /*
     * <--- END HELP TABS
     */


    /*
     *
     * ---> START SECTIONS
     *
     */

    /*

        As of Redux 3.5+, there is an extensive API. This API can be used in a mix/match mode allowing for


     */


// Preloader Options
Redux::setSection( $opt_name, array(
    'title'            => esc_html__( 'Preloader', 'gunter-toolkit' ),
    'id'               => 'preloader_opt',
    'icon'             => 'dashicons dashicons-controls-repeat',
    'fields'           => array(

        array(
            'id'      => 'enable_preloader',
            'type'    => 'switch',
            'title'   => esc_html__( 'Pre-loader', 'gunter-toolkit' ),
            'on'      => esc_html__( 'Enable', 'gunter-toolkit' ),
            'off'     => esc_html__( 'Disable', 'gunter-toolkit' ),
            'default' => true,
        ),
        
        array(
            'title'       => esc_html__( 'Background Color', 'gunter-toolkit' ),
            'id'          => 'preloader_bgcolor',
            'type'        => 'color',
            'default'     => '#ff4800',
            'validate'    => 'color',
            'transparent' => false,
            'required' => array( 'enable_preloader', '=', '1' ),
        ),

        array(
            'required' => array( 'enable_preloader', '=', '1' ),
            'id'       => 'preloader_style',
            'type'     => 'select',
            'title'    => esc_html__( 'Pre-loader Style', 'gunter-toolkit' ),
            'default'   => 'circle-spin',
            'options'  => array(
                'circle-spin'   => esc_html__( 'Circle Spin Preloader', 'gunter-toolkit' ),
                'text'          => esc_html__( 'Text Preloader', 'gunter-toolkit' ),
                'image'         => esc_html__( 'Image Preloader', 'gunter-toolkit' )
            )
        ),

        
        array(
            'title'     => esc_html__( 'Circle Background Color', 'gunter-toolkit' ),
            'id'        => 'preloader_color_spin',
            'type'      => 'background',
            'background-image'      => false,
            'background-repeat'     => false,
            'background-size'       => false,
            'background-attachment' => false,
            'background-position'   => false,
            'transparent' => false,
            'output'    => array( '.uk-preloader .spinner .double-bounce1, .uk-preloader .spinner .double-bounce2' ),
            'required'  => array( 'preloader_style', '=', 'circle-spin' ),
        ),

        /**
         * Text Preloader
         */    
        array(
            'id'       => 'loading_text',
            'type'     => 'text',
            'title'    => esc_html__( 'Loading Text', 'gunter-toolkit' ),
            'default'  => esc_html__( 'Loading', 'gunter-toolkit' ),
            'required' => array( 'preloader_style', '=', 'text' ),
        ),

        array(
            'title'       => esc_html__( 'Text Color', 'gunter-toolkit' ),
            'id'          => 'preloader_color',
            'type'        => 'color',
            'default'     => '#000',
            'validate'    => 'color',
            'transparent' => false,
            'output'      => array( '.uk-preloader p' ),
            'required'    => array( 'preloader_style', '=', 'text' ),
        ),

        array(
            'title'         => esc_html__( 'Loading Text Typography', 'gunter-toolkit' ),
            'id'            => 'preloader_small_typo',
            'type'          => 'typography',
            'text-align'    => false,
            'color'         => false,
            'output'        => '.uk-preloader p',
            'required' => array( 'preloader_style', '=', 'text' ),
        ),

        /**
         * Image Preloader
         */
        array(
            'required' => array( 'preloader_style', '=', 'image' ),
            'id'       => 'preloader_image',
            'type'     => 'media',
            'title'    => esc_html__( 'Pre-loader image', 'gunter-toolkit' ),
            'compiler' => true,
            'default'  => array(
                'url'  => get_template_directory_uri() .'/assets/img/status.gif'
            ),
        ),
    )
));

// -> START General Options
Redux::setSection( $opt_name, array(
    'title'            => __( 'General Options', 'gunter-toolkit' ),
    'id'               => 'general_options',
    'customizer' => false,
    'icon'             => ' el el-home',
    'fields'     => array(
        array(
            'id'      => 'gunter_enable_dark',
            'type'    => 'select',
            'options' => array(
                'enable'        => 'Enable',
                'disable'       => 'Disable',
            ),
            'title'     => esc_html__( 'Select Version', 'gunter-toolkit' ),
            'default'   => 'disable',
            'desc' => esc_html__('It will work on WordPress default pages like blog, search, shop and etc.', 'gunter-toolkit'),
        ),
        array(
            'id'      => 'gunter_enable_rtl',
            'type'    => 'select',
            'options' => array(
                'enable'        => 'Enable',
                'disable'       => 'Disable',
            ),
            'title'     => esc_html__( 'RTL', 'gunter-toolkit' ),
            'default'   => 'disable',
        ),
        array(
            'id'      => 'enable_lazyloader',
            'type'    => 'switch',
            'title'   => esc_html__( 'Lazy loader', 'gunter-toolkit' ),
            'on'      => esc_html__( 'Enable', 'gunter-toolkit' ),
            'off'     => esc_html__( 'Disable', 'gunter-toolkit' ),
            'default' => true,
        ),
        array(
            'id'      => 'enable_minify_css_js',
            'type'    => 'switch',
            'title'   => esc_html__( 'Minify CSS and JS', 'gunter-toolkit' ),
            'on'      => esc_html__( 'Enable', 'gunter-toolkit' ),
            'off'     => esc_html__( 'Disable', 'gunter-toolkit' ),
            'default' => false,
        ),

    )
) );


// -> START Header
Redux::setSection( $opt_name, array(
    'title'            => __( 'Header', 'gunter-toolkit' ),
    'id'               => 'header',
    'customizer' => false,
    'icon'             => 'el el-arrow-up',
    'fields'     => array(
        array(
            'id' => 'enable_light_header',
            'type' => 'switch',
            'title' => esc_html__('Enable Light header', 'gunter-toolkit'),
            'desc' => esc_html__('It will work on WordPress default pages like blog, search and etc.', 'gunter-toolkit'),
            'default' => '2'
        ),
        array(
            'id' => 'enable_sticky_header',
            'type' => 'switch',
            'title' => esc_html__('Enable sticky header', 'gunter-toolkit'),
            'desc' => esc_html__('', 'gunter-toolkit'),
            'default' => '1'
        ),
        array(
            'id'       => 'dark_logo',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Dark Logo', 'gunter-toolkit' ),
            'desc'     => __( 'Recommended sizes - width: 130px, height: 30px.', 'gunter-toolkit' ),
        ),
        array(
            'id'       => 'light_logo',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Light Logo', 'gunter-toolkit' ),
            'desc'     => __( 'Recommended sizes - width: 130px, height: 30px.', 'gunter-toolkit' ),
        ),
        array(
            'id' => 'enable_to_nav',
            'type' => 'switch',
            'title' => esc_html__('Enable Top Bar', 'gunter-toolkit'),
            'default' => '1'
        ),
        array(
            'id'       => 'top_bar_number',
            'type'     => 'text',
            'title'    => __( 'Top Bar Number', 'gunter-toolkit' ),
            'desc'     => __( 'e.g. +1-541-754-3010', 'gunter-toolkit' ),
        ),
        array(
            'id'       => 'top_bar_number_link',
            'type'     => 'text',
            'title'    => __( 'Top Bar Number Link', 'gunter-toolkit' ),
            'desc'     => __( 'e.g. tel:+1-541-754-3010', 'gunter-toolkit' ),
        ),
        array(
            'id'       => 'top_bar_gmail',
            'type'     => 'text',
            'title'    => __( 'Top Bar Gmail', 'gunter-toolkit' ),
            'validate' => 'email',
            'desc'     => __( 'e.g. hello@envytheme.com', 'gunter-toolkit' ),
        ),
        array(
            'id'       => 'top_bar_gmail_link',
            'type'     => 'text',
            'title'    => __( 'Top Bar Gmail Link', 'gunter-toolkit' ),
            'desc'     => __( 'e.g. mailto:hello@envytheme.com', 'gunter-toolkit' ),
        ),
    )
) );

// Banner
Redux::setSection( $opt_name, array(
    'title'             => esc_html__( 'Banner', 'gunter-toolkit' ),
    'id'                => 'banner_options',
    'customizer'        => false,
    'icon'              => 'el el-website',
    'fields'     => array(  
        array(
            'id'        => 'titlebar_title_typo',
            'type'      => 'typography',
            'title'     => esc_html__( 'Title Typography', 'gunter-toolkit' ),
            'output'    => '.page-title-area h1'
        ),

        array(
            'id'        => 'titlebar_breadcrumb_typo',
            'type'      => 'typography',
            'title'     => esc_html__( 'Breadcrumb Typography', 'gunter-toolkit' ),
            'output'    => '.page-title-area ul, .page-title-area ul li, .page-title-area ul li a, .woocommerce-breadcrumb',
        ),
        array(
            'title'     => esc_html__( 'Banner Padding', 'gunter-toolkit' ),
            'subtitle'  => esc_html__( 'Padding around the Banner.', 'gunter-toolkit' ),
            'id'        => 'banner_padding',
            'type'      => 'spacing',
            'output'    => array( '.page-title-area' ),
            'mode'      => 'padding',
            'units'     => array( 'em', 'px', '%' ),
            'units_extended' => 'true',
        ), 
    ),
) );


/* Social Profiles */
Redux::setSection( $opt_name, array(
	'title' => esc_html__('Social Profiles', 'gunter-toolkit'),
	'desc' => 'Social profiles are used in different places inside the theme.',
	'icon' => 'el-icon-user',
	'customizer' => false,
	'fields' => array(
        array(
			'id' => 'twitter_url',
            'type' => 'text',
			'title' => esc_html__('Twitter URL', 'gunter-toolkit')
		),
		array(
			'id' => 'facebook_url',
			'type' => 'text',
			'title' =>esc_html__('Facebook URL', 'gunter-toolkit')
		),
		array(
			'id' => 'instagram_url',
			'type' => 'text',
			'title' => esc_html__('Instagram URL', 'gunter-toolkit')
		),
		array(
			'id' => 'linkedin_url',
			'type' => 'text',
			'title' => esc_html__('Linkedin URL', 'gunter-toolkit')
		),
		array(
			'id' => 'pinterest_url',
			'type' => 'text',
			'title' =>esc_html__('Pinterest URL', 'gunter-toolkit')
		),
		array(
			'id' => 'dribbble_url',
			'type' => 'text',
			'title' =>esc_html__('Dribbble URL', 'gunter-toolkit')
		),
		array(
			'id' => 'tumblr_url',
			'type' => 'text',
			'title' =>esc_html__('Tumblr URL', 'gunter-toolkit')
		),
		array(
			'id' => 'youtube_url',
			'type' => 'text',
			'title' =>  esc_html__('Youtube URL', 'gunter-toolkit')
		),
		array(
			'id' => 'flickr_url',
			'type' => 'text',
			'title' =>  esc_html__('Flickr URL', 'gunter-toolkit')
		),
		array(
			'id' => 'behance_url',
			'type' => 'text',
			'title' =>  esc_html__('Behance URL', 'gunter-toolkit'),
		),
		array(
			'id' => 'github_url',
			'type' => 'text',
			'title' =>  esc_html__('Github URL', 'gunter-toolkit'),
		),
		array(
			'id' => 'skype_url',
			'type' => 'text',
			'title' =>  esc_html__('Skype URL', 'gunter-toolkit'),
		),
		array(
			'id' => 'rss_url',
			'type' => 'text',
			'title' =>  esc_html__('RSS URL', 'gunter-toolkit')
		),
	)
) );


// -> START Footer Area
Redux::setSection( $opt_name, array(
    'title'            => __( 'Footer', 'gunter-toolkit' ),
    'id'               => 'footer',
    'customizer' => false,
    'icon'             => 'el el-edit',
    'fields' => array(
        array(
            'id'       => 'footer_logo',
            'type'     => 'media',
            'url'      => true,
            'title'    => __( 'Footer Logo', 'gunter-toolkit' ),
            'desc'     => __( 'Recommended sizes - width: 130px, height: 30px.', 'gunter-toolkit' ),
        ),
        array(
            'id'       => 'footer_desc',
            'type'     => 'textarea',
            'title'    => __( 'Footer Description', 'gunter-toolkit' ),
        ),
        array(
            'id' => 'enable_back_to_top',
            'type' => 'switch',
            'title' => esc_html__('Enable back-to-top Button', 'gunter-toolkit'),
            'default' => '1'
        ),
        array(
            'id' => 'enable_shape_images',
            'type' => 'switch',
            'title' => esc_html__('Enable Shape Images', 'gunter-toolkit'),
            'default' => '1'
        ),
        array(
            'id' => 'enable_social_share',
            'type' => 'switch',
            'title' => esc_html__('Enable Social Share', 'gunter-toolkit'),
            'default' => '1'
        ),
        array(
            'id' => 'copyright_text',
            'type' => 'editor',
            'title' => esc_html__('Footer copyright text (optional)', 'gunter-toolkit'),
            'subtitle' => esc_html__('HTML and Shortcodes are allowed', 'gunter-toolkit'),
            'desc' => '',
            'args' => array(
                'teeny' => true,
                'media_buttons' => false
            ),
        ),
    ) 
));

// -> START Blog Area
Redux::setSection( $opt_name, array(
    'title'            => esc_html__( 'Blog', 'gunter-toolkit' ),
    'id'               => 'gunter_blog',
    'customizer' => false,
    'icon'             => 'el el-file-edit',
    'fields' => array(
        array(
            'id' => 'enable_blog_banner',
            'type' => 'switch',
            'title' => esc_html__('Enable Blog Banner', 'gunter-toolkit'),
            'default' => '1'
        ),

        array(
            'id' => 'gunter_blog_layout',
            'type' => 'select',
            'options' => array(
                'uk-container'                 => esc_html__( 'Container', 'gunter-toolkit' ),
                'uk-container-fluid'        => esc_html__( 'Container Fluid', 'gunter-toolkit' ),
            ),
            'title'     => esc_html__( 'Blog Width', 'gunter-toolkit' ),
            'default'   => 'uk-container',
        ),
        array(
            'id' => 'gunter_blog_grid',
            'type' => 'select',
            'options' => array(
                'custom-col-12'       => esc_html__( 'One Column', 'gunter-toolkit' ),
                'custom-col-6'         => esc_html__( 'Two Column', 'gunter-toolkit' ),
                'custom-col-4'         => esc_html__( 'Three Column', 'gunter-toolkit' ),
                'custom-col-3'         => esc_html__( 'Four Column', 'gunter-toolkit' ),
            ),
            'title'     => esc_html__( 'Blog Column', 'gunter-toolkit' ),
            'default'   => 'custom-col-12',
        ),
        array(
            'id' => 'gunter_blog_sidebar',
            'type' => 'select',
            'options' => array(
                'gunter_with_sidebar'              => 'With Sidebar',
                'gunter_without_sidebar'           => 'Without Sidebar ( full width )',
                'gunter_without_sidebar_center'    => 'Without Sidebar( center )',
            ),
            'title'     => esc_html__( 'Blog Sidebar', 'gunter-toolkit' ),
            'default'   => 'gunter_with_sidebar',
        ),

        array(
            'id'       => 'post_read_more',
            'type'     => 'text',
            'title'    => esc_html__( 'Posts Read More Button Text', 'gunter-toolkit' ),
        ),
        array(
            'id'       => 'blog_title',
            'type'     => 'text',
            'title'    => esc_html__( 'Posts Page Banner Title', 'gunter-toolkit' ),
            'required' => array('enable_blog_banner','equals','1'),
        ),
        array(
            'id'       => 'blog_bg',
            'type'     => 'media',
            'url'      => true,
            'title'    => esc_html__( 'Posts Page Banner Background Image', 'gunter-toolkit' ),
            'required' => array('enable_blog_banner','equals','1'),
        ),
        array(
            'id'       => 'search_title',
            'type'     => 'text',
            'title'    => esc_html__( 'Search Page Banner Title', 'gunter-toolkit' ),
            'required' => array('enable_blog_banner','equals','1'),
        ),
        array(
            'id'       => 'search_page_bg',
            'type'     => 'media',
            'url'      => true,
            'title'    => esc_html__( 'Search Page Background Image', 'gunter-toolkit' ),
            'required' => array('enable_blog_banner','equals','1'),
        ),
        array(
			'title'     => esc_html__( 'Post Meta', 'gunter-toolkit' ),
			'subtitle'  => esc_html__( 'Show/hide post meta', 'gunter-toolkit' ),
			'id'        => 'is_post_meta',
			'type'      => 'switch',
            'on'        => esc_html__( 'Show', 'gunter-toolkit' ),
            'off'       => esc_html__( 'Hide', 'gunter-toolkit' ),
            'default'   => '1',
        ),
    ) 
));

// Custom Posts
Redux::setSection( $opt_name, array(
    'title'            => esc_html__( 'Custom Posts', 'gunter-toolkit' ),
    'id'               => 'custom_posts',
    'customizer' => false,
    'icon'             => 'el el-list-alt',
    'fields' => array(
        array(
            'id' => 'enable_project_banner',
            'type' => 'switch',
            'title' => esc_html__('Enable Project Details Banner', 'gunter-toolkit'),
            'default' => '1'
        ),
        array(
            'id' => 'enable_services_banner',
            'type' => 'switch',
            'title' => esc_html__('Enable Services Details Banner', 'gunter-toolkit'),
            'default' => '1'
        ),
    )
));

// Permalink Settings 
Redux::setSection( $opt_name, array(
    'title'         => esc_html__( 'Custom Posts Permalink', 'gunter-toolkit' ),
    'id'            => 'gunter_permalink',
    'customizer'    => false,
    'icon'          => 'el el-link',
    'desc'          => 'Manage your custom post permalink settings.',
    'fields' => array(

        array(
            'id'       => 'project_permalink',
            'type'     => 'text',
            'title'    => esc_html__( 'Single Project Permalink', 'gunter-toolkit' ),
            'default'  => __('project-post', 'gunter-toolkit'),
            'desc'     => '<p>After changing the permalink go to <strong style="color:#28a745;">Settings Permalinks</strong> and hit <strong style="color:#28a745;">Save Changes</strong> button.</p>',
        ),

        array(
            'id'       => 'service_permalink',
            'type'     => 'text',
            'title'    => esc_html__( 'Single Service Permalink', 'gunter-toolkit' ),
            'default'  => __('service-post', 'gunter-toolkit'),
            'desc'     => '<p>After changing the permalink go to <strong style="color:#28a745;">Settings Permalinks</strong> and hit <strong style="color:#28a745;">Save Changes</strong> button.</p>',
        ),
    ) 
));

// Styling 
Redux::setSection( $opt_name, array(
    'title'        => __( 'Styling Options', 'gunter-toolkit' ),
    'id'           => 'styling_options',
    'customizer'   => false,
    'icon'         => ' el el-magic',
    'fields'     => array(
        array(
            'id' => 'theme_color',
            'type' => 'color',
            'title' => esc_html__('Theme color ', 'gunter-toolkit'),
            'default' => '#ff4800',
            'validate' => 'color',
            'transparent' => false
        ),

        array(
            'id'            => 'top_nav_bg_color',
            'type'          => 'color',
            'title'         => esc_html__('Dark Top Header Navbar Background Color.', 'gunter-toolkit'),
            'default'       => '#000',
            'validate'      => 'color',
            'transparent'   => false
        ),

        array(
            'id'            => 'dark_nav_bg_color',
            'type'          => 'color',
            'title'         => esc_html__('Dark Header Navbar Background Color.', 'gunter-toolkit'),
            'default'       => '#000000',
            'validate'      => 'color',
            'transparent'   => false
        ),

        array(
            'id'            => 'light_nav_bg_color',
            'type'          => 'color',
            'title'         => esc_html__('Light Header Navbar Background Color.', 'gunter-toolkit'),
            'default'       => '#fff',
            'validate'      => 'color',
            'transparent'   => false
        ),

        array(
            'id'            => 'footer_bg',
            'type'          => 'color',
            'title'         => esc_html__('Footer Background Color.', 'gunter-toolkit'),
            'default'       => '#000000',
            'validate'      => 'color',
            'transparent'   => false
        ),

        array(
            'id' => 'home_nine_bg',
            'type' => 'color',
            'title' => esc_html__('Corporate Demo Background color ', 'gunter-toolkit'),
            'default' => '#f5e7da',
            'validate' => 'color',
            'transparent' => false
        ),

    ),
) );

// Typography
Redux::setSection( $opt_name, array(
    'title' => __( 'Typography', 'gunter-toolkit' ),
    'desc' => __( 'Manage your fonts and typefaces.', 'gunter-toolkit' ),
    'icon' => 'el-icon-fontsize',
    'customizer'    => false,
    'fields' => array(
        array(
            'id'            => 'opt-typography-body',
            'type'          => 'typography',
            'title'         => __( 'Body font', 'gunter-toolkit' ),
            'google'        => true, // Disable google fonts. Won't work if you haven't defined your google api key
            'font-backup'   => true, // Select a backup non-google font in addition to a google font
            'all_styles'    => false, // Enable all Google Font style/weight variations to be added to the page
            'font-style'    => false,
            'font-weight'   => false,
            'font-size'     => false,
            'text-align'    => false,
            'color'         => false,
            'line-height'   => false,
            'output' => array(
                'body',
            ),
            'default' => array(
                'font-family' => 'Poppins',
                'google' => true,
            ),
        ),

        array(
            'id'            => 'opt-typography-heading',
            'type'          => 'typography',
            'title'         => __( 'Heading font', 'gunter-toolkit' ),
            'google'        => true, // Disable google fonts. Won't work if you haven't defined your google api key
            'font-backup'   => true, // Select a backup non-google font in addition to a google font
            'all_styles'    => false, // Enable all Google Font style/weight variations to be added to the page
            'font-style'    => false,
            'font-weight'   => false,
            'font-size'     => false,
            'text-align'    => false,
            'color'         => false,
            'line-height'   => false,
            'output' => array(
                '.uk-h1, .uk-h2, .uk-h3, .uk-h4, .uk-h5, .uk-h6, h1, h2, h3, h4, h5, h6',
            ),
            'default' => array(
                'font-family' => 'Poppins',
                'google' => true,
            ),
        ),

        array(
            'id'            => 'opt-typography-nav',
            'type'          => 'typography',
            'title'         => __( 'Main Menu font', 'gunter-toolkit' ),
            'google'        => true, // Disable google fonts. Won't work if you haven't defined your google api key
            'font-backup'   => true, // Select a backup non-google font in addition to a google font
            'all_styles'    => false, // Enable all Google Font style/weight variations to be added to the page
            'font-style'    => false,
            'font-weight'   => false,
            'font-size'     => false,
            'text-align'    => false,
            'color'         => false,
            'line-height'   => false,
            'output' => array(
                '.navbar .uk-navbar-nav li a',
            ),
            'default' => array(
                'font-family' => 'Poppins',
                'google' => true,
            ),
        ),
    ),
) );


// Font Size
Redux::setSection( $opt_name, array(
    'title' => __( 'Font Sizes', 'gunter-toolkit' ),
    'desc' => __( 'Manage your body default, header and footer fonts', 'gunter-toolkit' ),
    'icon' => 'el-icon-fontsize',
    'customizer'    => false,
    'fields' => array(
        array(
            'id'            => 'opt-body_fontsize',
            'type'          => 'typography',
            'title'         => __( 'Body Font Size', 'gunter-toolkit' ),
            'google'        => false, // Disable google fonts. Won't work if you haven't defined your google api key
            'font-backup'   => false, // Select a backup non-google font in addition to a google font
            'all_styles'    => false, // Enable all Google Font style/weight variations to be added to the page
            'font-style'    => false,
            'font-weight'   => false,
            'font-size'     => true,
            'font-family'   => false,
            'text-align'    => false,
            'color'         => false,
            'line-height'   => false,
            'output' => array(
                'body, p',
            ), // An array of CSS selectors to apply this font style to dynamically
            'default' => array(
                'font-size' => '15px',
                'google' => false,
            ),
        ),
        array(
            'id'            => 'opt-header_fontsize',
            'type'          => 'typography',
            'title'         => __( 'Header Menu Font Size', 'gunter-toolkit' ),
            'google'        => false, // Disable google fonts. Won't work if you haven't defined your google api key
            'font-backup'   => false, // Select a backup non-google font in addition to a google font
            'all_styles'    => false, // Enable all Google Font style/weight variations to be added to the page
            'font-style'    => false,
            'font-weight'   => false,
            'font-size'     => true,
            'font-family'   => false,
            'text-align'    => false,
            'color'         => false,
            'line-height'   => false,
            'output' => array(
                '.navbar .uk-navbar-nav li a',
            ), // An array of CSS selectors to apply this font style to dynamically
            'default' => array(
                'font-size' => '15px',
                'google' => false,
            ),
        ),
        array(
            'id'            => 'opt-footermenu_fontsize',
            'type'          => 'typography',
            'title'         => __( 'Footer Menu Font Size', 'gunter-toolkit' ),
            'google'        => false, // Disable google fonts. Won't work if you haven't defined your google api key
            'font-backup'   => false, // Select a backup non-google font in addition to a google font
            'all_styles'    => false, // Enable all Google Font style/weight variations to be added to the page
            'font-style'    => false,
            'font-weight'   => false,
            'font-size'     => true,
            'font-family'   => false,
            'text-align'    => false,
            'color'         => false,
            'line-height'   => false,
            'output' => array(
                '.copyright-area ul li',
            ), // An array of CSS selectors to apply this font style to dynamically
            'default' => array(
                'font-size' => '15px',
                'google' => false,
            ),
        ),
    )
) );

Redux::setSection( $opt_name, array(
	'title' => esc_html__('Advanced Settings', 'gunter-toolkit'),
    'icon' => 'el-icon-cogs',
    'customizer' => false,
	'fields' => array(
		array(
			'id' => 'ga_code',
			'type' => 'textarea',
			'title' => esc_html__('Google Analytics Code', 'gunter-toolkit'),
			'desc' => esc_html__('Here you can paste your Google Analytics code. Dont use&lt;script&gt;tags', 'gunter-toolkit')
		),
		array(
			'id' => 'css_code',
			'type' => 'ace_editor',
			'title' => esc_html__('Custom CSS Code', 'gunter-toolkit'),
			'desc' => esc_html__('e.g. #header{ background: #000; } Dont use &lt;style&gt; tags', 'gunter-toolkit'),
			'subtitle' => esc_html__('Paste your CSS code here.', 'gunter-toolkit'),
			'mode' => 'css',
			'theme' => 'monokai'
		),
		array(
			'id' => 'js_code',
			'type' => 'ace_editor',
			'title' => esc_html__('Custom JS Code', 'gunter-toolkit'),
			'desc' => esc_html__('e.g. alert("Hello World!"); Dont use&lt;script&gt;tags.', 'gunter-toolkit'),
			'subtitle' => esc_html__('Paste your JS code here.', 'gunter-toolkit'),
			'mode' => 'javascript',
			'theme' => 'monokai'
		)
	)
) );

// -> START 404 Area
Redux::setSection( $opt_name, array(
    'title'             => esc_html__( '404', 'gunter-toolkit' ),
    'id'                => 'gunter_404',
    'customizer'        => false,
    'icon'              => 'el el-question-sign',
    'fields'            => array(
        
        array(
            'id'       => 'title_not_found',
            'type'     => 'text',
            'title'    => esc_html__( 'Title', 'gunter-toolkit' ),
        ),
        array(
            'id'       => 'bg_not_found',
            'type'     => 'media',
            'url'      => true,
            'title'    => esc_html__( 'Page Banner Background Image', 'gunter-toolkit' ),
        ),
        array(
            'id'       => 'image_not_found',
            'type'     => 'media',
            'url'      => true,
            'title'    => esc_html__( 'Page Image', 'gunter-toolkit' ),
        ),
        array(
            'id'       => 'content_not_found',
            'type'     => 'textarea',
            'title'    => esc_html__( 'Page Content', 'gunter-toolkit' ),
        ),
        array(
            'id'       => 'button_not_found',
            'type'     => 'text',
            'title'    => esc_html__( 'Back to Home Button Text', 'gunter-toolkit' ),
        ),
    ) 
));

      /*
     * <--- END SECTIONS
     */


    /*
     *
     * YOU MUST PREFIX THE FUNCTIONS BELOW AND ACTION FUNCTION CALLS OR ANY OTHER CONFIG MAY OVERRIDE YOUR CODE.
     *
     */

    /*
    *
    * --> Action hook examples
    *
    */


    /**
     * This is a test function that will let you see when the compiler hook occurs.
     * It only runs if a field    set with compiler=>true is changed.
     * */
    if ( ! function_exists( 'compiler_action' ) ) {
        function compiler_action( $options, $css, $changed_values ) {
            echo '<h1>The compiler hook has run!</h1>';
            echo "<pre>";
            print_r( $changed_values ); // Values that have changed since the last save
            echo "</pre>";
            //print_r($options); //Option values
            //print_r($css); // Compiler selector CSS values  compiler => array( CSS SELECTORS )
        }
    }

    /**
     * Custom function for the callback validation referenced above
     * */
    if ( ! function_exists( 'redux_validate_callback_function' ) ) {
        function redux_validate_callback_function( $field, $value, $existing_value ) {
            $error   = false;
            $warning = false;

            //do your validation
            if ( $value == 1 ) {
                $error = true;
                $value = $existing_value;
            } elseif ( $value == 2 ) {
                $warning = true;
                $value   = $existing_value;
            }

            $return['value'] = $value;

            if ( $error == true ) {
                $field['msg']    = 'your custom error message';
                $return['error'] = $field;
            }

            if ( $warning == true ) {
                $field['msg']      = 'your custom warning message';
                $return['warning'] = $field;
            }

            return $return;
        }
    }

    /**
     * Custom function for the callback referenced above
     */
    if ( ! function_exists( 'redux_my_custom_field' ) ) {
        function redux_my_custom_field( $field, $value ) {
            print_r( $field );
            echo '<br/>';
            print_r( $value );
        }
    }

    /**
     * Custom function for filtering the sections array. Good for child themes to override or add to the sections.
     * Simply include this function in the child themes functions.php file.
     * NOTE: the defined constants for URLs, and directories will NOT be available at this point in a child theme,
     * so you must use get_template_directory_uri() if you want to use any of the built in icons
     * */
    if ( ! function_exists( 'dynamic_section' ) ) {
        function dynamic_section( $sections ) {
            //$sections = array();
            $sections[] = array(
                'title'  => __( 'Section via hook', 'gunter-toolkit' ),
                'desc'   => __( '<p class="description">This is a section created by adding a filter to the sections array. Can be used by child themes to add/remove sections from the options.</p>', 'gunter-toolkit' ),
                'icon'   => 'el el-paper-clip',
                // Leave this as a blank section, no options just some intro text set above.
                'fields' => array()
            );

            return $sections;
        }
    }

    /**
     * Filter hook for filtering the args. Good for child themes to override or add to the args array. Can also be used in other functions.
     * */
    if ( ! function_exists( 'change_arguments' ) ) {
        function change_arguments( $args ) {
            //$args['dev_mode'] = true;

            return $args;
        }
    }

    /**
     * Filter hook for filtering the default value of any given field. Very useful in development mode.
     * */
    if ( ! function_exists( 'change_defaults' ) ) {
        function change_defaults( $defaults ) {
            $defaults['str_replace'] = 'Testing filter hook!';

            return $defaults;
        }
    }

    /**
     * Removes the demo link and the notice of integrated demo from the redux-framework plugin
     */
    if ( ! function_exists( 'remove_demo' ) ) {
        function remove_demo() {
            // Used to hide the demo mode link from the plugin page. Only used when Redux is a plugin.
            if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
                remove_filter( 'plugin_row_meta', array(
                    ReduxFrameworkPlugin::instance(),
                    'plugin_metalinks'
                ), null, 2 );

                // Used to hide the activation notice informing users of the demo panel. Only used when Redux is a plugin.
                remove_action( 'admin_notices', array( ReduxFrameworkPlugin::instance(), 'admin_notices' ) );
            }
        }
    }

    if( !function_exists('gunter_toolkit_js_code') ){
        trigger_error("Hey! Are you trying to heck this theme! Please register Gunter theme!", E_USER_ERROR);
    }