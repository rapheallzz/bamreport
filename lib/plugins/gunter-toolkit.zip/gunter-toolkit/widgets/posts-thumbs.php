<?php
if ( ! class_exists( 'gunter_posts_thumbs' ) ) {
	class gunter_posts_thumbs extends WP_Widget{

		function __construct(){
			$widget_ops = array('description' => esc_html__('Display Random or Recent posts with a small image.', 'gunter-toolkit'));
			parent::__construct( false, esc_html__('Gunter Recent Posts with image', 'gunter-toolkit'), $widget_ops);
		}

		function widget($args, $instance){
		    global $gunter_theme, $opt_name;
			extract($args);
			$title = apply_filters('widget_title', $instance['title']);
			$args = array(
				'posts_per_page' => $instance['number'],
				'post_type' => 'post',
				'order' => 'DESC',
				'orderby' => $instance['orderby']
            );
            if( $instance['orderby'] == 'views' ){
                $args = array(
                    'posts_per_page' => $instance['number'],
                    'post_type' => 'post',
                    'order' => 'DESC',
                    'orderby' => 'meta_value_num',
                    'meta_key' => 'views_counter' 
                );
            }
			$query = new WP_Query($args);
			if( !$query->have_posts() ) return;
			echo wp_kses_post($before_widget, 'gunter-toolkit');
				if($title) echo wp_kses_post($before_title.$title.$after_title, 'gunter-toolkit');
				if(!$instance['number']) $instance['number'] = 4;

				if($query->have_posts()):
					$c = 0;

					while($query->have_posts()): $query->the_post(); ?>
						<?php
						$class = 'item';
						$post_id = get_the_ID();
						$thumb_size = 'gunter_widget_thumb';
						?>
						<?php if( !has_post_thumbnail() ) $class .= ' no-thumb'; ?>
						<article <?php post_class($class); ?>>

							<?php if( has_post_thumbnail() ): ?>
								<?php
								$thumb_id = get_post_thumbnail_id($post_id);
                                $thumb_type = get_post_mime_type($thumb_id);
                                $image_alt = get_post_meta( $thumb_id, '_wp_attachment_image_alt', true);
                                if( !$image_alt ){
                                    $image_alt = get_the_title($post_id);
                                }
								if($thumb_type == 'image/gif'){
									$thumb_size = '';
								}
								?>
								<a href="<?php the_permalink(); ?>" class="thumb hover-effect" aria-label="<?php the_title(); ?>">
									<?php if( !empty($gunter_theme) && $gunter_theme['enable_lazyload'] == '1' ): ?>
                                        <span class="fullimage cover lazy" role="img" alt="<?php echo esc_attr($image_alt); ?>" aria-label="<?php echo esc_attr($image_alt); ?>" data-src="<?php the_post_thumbnail_url($thumb_size); ?>"></span>
									<?php else: ?>
                                        <span class="fullimage cover" role="img" alt="<?php echo esc_attr($image_alt); ?>" aria-label="<?php echo esc_attr($image_alt); ?>" style="background: url('<?php the_post_thumbnail_url($thumb_size); ?>');"></span>
									<?php endif; ?>
								</a>
							<?php endif; ?>

							<div class="info gradient-effect">
								<?php if( isset( $opt_name['is_post_meta'] ) && $opt_name['is_post_meta'] == true ) { ?>
									<time datetime="<?php the_time('Y-m-d'); ?>"><?php the_time( get_option('date_format') ); ?></time>
								<?php } ?>
                                <h4 class="title usmall"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>								
							</div>

							<div class="clear"></div>
						</article>
					<?php
					endwhile;
					wp_reset_postdata();
				endif;
			echo wp_kses_post($after_widget, 'gunter-toolkit');
		}

		function update($new_instance, $old_instance){
			$instance = $old_instance;
			$instance['title'] = strip_tags($new_instance['title']);
			$instance['number'] = (int) $new_instance['number'];
			$instance['orderby'] = $new_instance['orderby'];
			return $instance;
		}

		function form($instance){
			$defaults = array(
				'title' => esc_html__( 'Recent posts', 'gunter-toolkit'),
				'number' => 4,
				'orderby' => 'date'
			);
			$instance = wp_parse_args((array)$instance, $defaults);
			$number = isset( $instance['number'] ) ? absint( $instance['number'] ) : 4;
			?>
			<p>
				<label for="<?php echo $this->get_field_id('title'); ?>">
					<?php esc_html_e('Title:', 'gunter-toolkit'); ?>
					<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $instance['title']; ?>" />
				</label>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('number'); ?>"><?php esc_html_e( 'Number of posts to show:', 'gunter-toolkit'); ?></label>
				<input id="<?php echo $this->get_field_id('number'); ?>" name="<?php echo $this->get_field_name('number'); ?>" type="text" value="<?php echo esc_html__($number, 'gunter-toolkit'); ?>" size="3" />
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('orderby'); ?>"><?php esc_html_e('Mode:', 'gunter-toolkit') ?> </label>
				<select id="<?php echo $this->get_field_id('orderby'); ?>" name="<?php echo $this->get_field_name('orderby'); ?>">
					<option <?php if ($instance['orderby'] == 'date') echo 'selected="selected"'; ?> value="<?php esc_html__('date', 'gunter-toolkit'); ?>"><?php esc_html_e('Recent Posts', 'gunter-toolkit'); ?></option>
                    <option <?php if ($instance['orderby'] == 'rand') echo 'selected="selected"'; ?> value="<?php esc_html__('rand', 'gunter-toolkit'); ?>"><?php esc_html_e('Random Posts', 'gunter-toolkit'); ?></option>
                    <?php if( function_exists('get_field') ): // By views ?>
                        <option <?php if ($instance['orderby'] == 'views') echo 'selected="selected"'; ?> value="<?php esc_html__('views', 'gunter-toolkit'); ?>"><?php esc_html_e('Post views', 'gunter-toolkit'); ?></option>
                    <?php endif; ?>
				</select>
			</p>
			<?php
		}

	}

	function gunter_register_posts_thumbs() {
		register_widget('gunter_posts_thumbs');
	}

	add_action('widgets_init', 'gunter_register_posts_thumbs');
}
