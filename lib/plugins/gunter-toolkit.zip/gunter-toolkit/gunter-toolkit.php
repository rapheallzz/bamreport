<?php
/*
 * Plugin Name: Gunter Toolkit
 * Author: EnvyTheme Team
 * Author URI: envytheme.com
 * Description: A Light weight and easy toolkit for Gunter theme
 * Version: 4.7.1
 */

if (!defined('ABSPATH')) {
    exit; //Exit if accessed directly
}
//define
define('GUNTER_ACC_URL', WP_PLUGIN_URL . '/' . plugin_basename(dirname(__FILE__)) . '/');
define('GUNTER_ACC_PATH', plugin_dir_path(__FILE__));

function gunter_toolkit_get_page_as_list() {
    $args = wp_parse_args(array(
        'post_type' => 'page',
        'numberposts' => -1,
    ));

    $posts = get_posts($args);
    $post_options = array(esc_html__('--Select Page--', 'gunter-toolkit') => '');

    if ($posts) {
        foreach ($posts as $post) {
            $post_options[$post->post_title] = $post->ID;
        }
    }
    return $post_options;
}

function gunter_toolkit_get_services_as_list() {
    $arg = array(
        'taxonomy' => 'service_cat',
        'orderby' => 'name',
        'order'   => 'ASC'
    );

    $args = get_categories($arg);
    $args_options = array(esc_html__('--Select Page--', 'gunter-toolkit') => '');

    if ($args) {
        foreach ($args as $post) {
            $args_options[$post->name] = $post->slug;
        }
    }
    return $args_options;
}

// Print short codes in widgets
add_filter('widget_text', 'do_shortcode');

// Custom Post
function gunter_toolkit_custom_post()
{
    // Services permalink
    global $opt_name;
	if( isset( $opt_name['service_permalink'] ) ):
		$service_permalink = $opt_name['service_permalink'];
	else:
		$service_permalink = 'service-post';
	endif;

    // Services Custom Post
    register_post_type('service',
        array(
            'labels' => array(
                'name' => esc_html__('Services', 'gunter-toolkit'),
                'singular_name' => esc_html__('Service', 'gunter-toolkit'),
            ),
            'menu_icon' => 'dashicons-megaphone',
            'supports' => array('title', 'thumbnail', 'editor', 'excerpt', 'page-attributes'),
            'has_archive' => true,
			'public'   => true,
			'rewrite' => array( 'slug' => $service_permalink ),
        )
    );

    // Project permalink
    global $opt_name;
	if( isset( $opt_name['project_permalink'] ) ):
		$project_permalink = $opt_name['project_permalink'];
	else:
		$project_permalink = 'project-post';
    endif;

    // Project Custom Post
    register_post_type('project',
        array(
            'labels' => array(
                'name' => esc_html__('Project', 'gunter-toolkit'),
                'singular_name' => esc_html__('Project', 'gunter-toolkit'),
            ),
            'menu_icon' => 'dashicons-pressthis',
            'supports' => array('title', 'thumbnail', 'editor', 'page-attributes'),
            'has_archive' => true,
			'public'   => true,
			'rewrite' => array( 'slug' => $project_permalink ),
        )
    );

}

// Taxonomy Custom Post
function gunter_toolkit_custom_post_taxonomy(){
    register_taxonomy(
      'project_cat',
      'project',
        array(
          'hierarchical'      => true,
          'label'             => esc_html__('Projects Category', 'gunter-toolkit' ),
          'query_var'         => true,
          'show_admin_column' => true,
              'rewrite'         => array(
              'slug'          => 'project-category',
              'with_front'    => true
              )
        )
      );
      register_taxonomy(
        'service_cat',
        'service',
            array(
            'hierarchical'      => true,
            'label'             => esc_html__('Service Category', 'gunter-toolkit' ),
            'query_var'         => true,
            'show_admin_column' => true,
                'rewrite'         => array(
                'slug'          => 'service-category',
                'with_front'    => true
                )
            )
    );
  }
add_action('init', 'gunter_toolkit_custom_post_taxonomy');

add_action('init', 'gunter_toolkit_custom_post');

include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

if (is_plugin_active('js_composer/js_composer.php')) {

    // Loading VC addons
    require_once(GUNTER_ACC_PATH . 'vc-addons/vc-blocks-load.php');

    // Theme Shortcode
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/banner-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/banner-two-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/banner-three-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/section-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/feature-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/separator-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/about-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/services-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/project-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/testimonials-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/testimonials-two-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/client-logo-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/team-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/newsletter-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/news-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/map-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/banner-lead-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/banner-slider-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/box-testimonials-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/work-process-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/funfacts-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/contact-area-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/why-choose-us-shortcode.php');

    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/corporate-banner-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/services-area-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/testimonials-three-shortcode.php');
    require_once(GUNTER_ACC_PATH . 'theme-shortcodes/pricing-plans-shortcode.php');
}

$pcs = trim( get_option( 'gunter_purchase_code_status' ) );
if ( $pcs == 'valid' ) {
    // Redux Theme Options
    require_once(GUNTER_ACC_PATH . 'redux/ReduxCore/framework.php');
    require_once(GUNTER_ACC_PATH . 'redux/sample/sample-config.php');
    require_once(GUNTER_ACC_PATH . 'inc/icons.php');
}

function gunter_toolkit_js_code() {
    if ( !class_exists('Gunter_RT') || !class_exists('Gunter_base') || !class_exists('Gunter_admin_page') ) {
		?>
		<script>
			const body = document.getElementsByTagName('body');
			body[0].style.opacity = "0";
		</script>
	<?php }
}
add_action('wp_footer', 'gunter_toolkit_js_code');


//Theme Widgets
require_once(GUNTER_ACC_PATH . 'widgets/posts-thumbs.php');

// Shortcode depended on Visual Composer
include_once(ABSPATH . 'wp-admin/includes/plugin.php');

// Registering crazy toolkit files
function gunter_toolkit_files()
{
    wp_enqueue_style('gunter-toolkit', plugins_url('assets/css/gunter-toolkit.css', __FILE__));
    wp_enqueue_style('font-awesome-5.1', plugin_dir_url(__FILE__) . 'assets/css/all.min.css');
}
add_action('wp_enqueue_scripts', 'gunter_toolkit_files');

if ( ! function_exists( 'gunter_text_domain' ) ) {
	/**
	 * Loads plugin text domain so it can be used in translation
	 */
	function gunter_text_domain() {
		load_plugin_textdomain( 'gunter-toolkit', false, GUNTER_ACC_PATH . 'languages' );
	}

	add_action( 'plugins_loaded', 'gunter_text_domain' );
}

add_filter('script_loader_tag', 'gunter_clean_script_tag');
  function gunter_clean_script_tag($input) {
        $input = str_replace( array( 'type="text/javascript"', "type='text/javascript'" ), '', $input );
        return $input;
}

function gunter_admin_css() {
	echo '<style>#fw-ext-brizy,#fw-extensions-list-wrapper .toggle-not-compat-ext-btn-wrapper,.fw-brz-dismiss{display:none}.fw-brz-dismiss{display:none}.fw-extensions-list-item{display:none!important}#fw-ext-backups{display:block!important}#update-nag,.update-nag{display:block!important}    .fw-sole-modal-content.fw-text-center .fw-text-danger.dashicons.dashicons-warning:before { content: "\f15e" !important;}.fw-sole-modal-content.fw-text-center .fw-text-danger.dashicons.dashicons-warning {color: green !important;}.wp-core-ui .button-link { display: none !important;} .fw-modal.fw-modal-open > .media-modal-backdrop {display: none !important;}</style>';

  }
add_action('admin_head', 'gunter_admin_css');

/**
 * Elementor Setup
 */

if (is_plugin_active('elementor/elementor.php')) {
    final class Elementor_Gunter_Extension {

        const VERSION = '1.0.0';
        const MINIMUM_ELEMENTOR_VERSION = '2.0.0';
        const MINIMUM_PHP_VERSION = '7.0';

        // Instance
        private static $_instance = null;

        public static function instance() {

            if ( is_null( self::$_instance ) ) {
                self::$_instance = new self();
            }
            return self::$_instance;

        }

        // Constructor
        public function __construct() {
            add_action( 'plugins_loaded', [ $this, 'init' ] );

        }

        // init
        public function init() {
            load_plugin_textdomain( 'gunter-toolkit' );

            // Check if Elementor installed and activated
            if ( ! did_action( 'elementor/loaded' ) ) {
                add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
                return;
            }

            // Check for required Elementor version
            if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
                add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
                return;
            }

            // Check for required PHP version
            if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
                add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );
                return;
            }

            // Add Plugin actions
            add_action( 'elementor/widgets/widgets_registered', [ $this, 'init_widgets' ] );

            add_action('elementor/elements/categories_registered',[ $this, 'register_new_category'] );

        }

        public function register_new_category($manager){
            $manager->add_category('gunter-elements',[
                'title'=>esc_html__('Gunter','gunter-toolkit'),
                'icon'=> 'fa fa-image'
            ]);
        }

        // Admin notice
        public function admin_notice_minimum_elementor_version() {

            if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

            $message = sprintf(
                /* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
                esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'gunter-toolkit' ),
                '<strong>' . esc_html__( 'Gunter', 'gunter-toolkit' ) . '</strong>',
                '<strong>' . esc_html__( 'Elementor', 'gunter-toolkit' ) . '</strong>',
                self::MINIMUM_ELEMENTOR_VERSION
            );

            printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

        }
        public function admin_notice_minimum_php_version() {

            if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

            $message = sprintf(
                /* translators: 1: Plugin name 2: PHP 3: Required PHP version */
                esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'gunter-toolkit' ),
                '<strong>' . esc_html__( 'Gunter', 'gunter-toolkit' ) . '</strong>',
                '<strong>' . esc_html__( 'PHP', 'gunter-toolkit' ) . '</strong>',
                self::MINIMUM_PHP_VERSION
            );

            printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

        }

        // Toolkit Widgets
        public function init_widgets() {

            // Include Widget files
            $pcs = trim( get_option( 'gunter_purchase_code_status' ) );
            if ( $pcs == 'valid' ) {
                require_once( __DIR__ . '/el-addons/banner-area.php' );
                require_once( __DIR__ . '/el-addons/banner-lead.php' );
                require_once( __DIR__ . '/el-addons/banner-slider.php' );
                require_once( __DIR__ . '/el-addons/banner-two.php' );
                require_once( __DIR__ . '/el-addons/banner-three.php' );
                require_once( __DIR__ . '/el-addons/corporate-banner.php' );
                require_once( __DIR__ . '/el-addons/features-box.php' );
                require_once( __DIR__ . '/el-addons/separator.php' );
                require_once( __DIR__ . '/el-addons/about-us.php' );
                require_once( __DIR__ . '/el-addons/section.php' );
                require_once( __DIR__ . '/el-addons/services.php' );
                require_once( __DIR__ . '/el-addons/projects.php' );
                require_once( __DIR__ . '/el-addons/testimonials.php' );
                require_once( __DIR__ . '/el-addons/testimonials-slider.php' );
                require_once( __DIR__ . '/el-addons/box-testimonials.php' );
                require_once( __DIR__ . '/el-addons/partner.php' );
                require_once( __DIR__ . '/el-addons/team.php' );
                require_once( __DIR__ . '/el-addons/newsletter.php' );
                require_once( __DIR__ . '/el-addons/blog-posts.php' );
                require_once( __DIR__ . '/el-addons/contact.php' );
                require_once( __DIR__ . '/el-addons/contact-two.php' );
                require_once( __DIR__ . '/el-addons/work-process.php' );
                require_once( __DIR__ . '/el-addons/funfacts.php' );
                require_once( __DIR__ . '/el-addons/why-choose-us.php' );
                require_once( __DIR__ . '/el-addons/services-area.php' );
                require_once( __DIR__ . '/el-addons/testimonials.-two.php' );
                require_once( __DIR__ . '/el-addons/pricing.php' );
            }
        }

    }
    Elementor_Gunter_Extension::instance();

    // Select page for link
    function gunter_toolkit_pages_list_el() {
        $args = wp_parse_args(array(
            'post_type' => 'page',
            'numberposts' => -1,
        ));

        $posts = get_posts($args);
        $post_options = array(esc_html__('--Select Page--', 'gunter-toolkit') => '');

        if ($posts) {
            foreach ($posts as $post) {
                $post_options[$post->post_title] = $post->ID;
            }
        }
        $flipped = array_flip($post_options);
        return $flipped;
    }

    function gunter_toolkit_get_page_services_cat_el() {
        $arg = array(
            'taxonomy' => 'service_cat',
            'orderby' => 'name',
            'order'   => 'ASC'
        );
        $args = get_categories($arg);
        $args_options = array(esc_html__('', 'gunter-toolkit') => '');
        if ($args) {
            foreach ($args as $args) {
                $args_options[$args->name] = $args->slug;
            }
        }
        return $args_options;
    }
}