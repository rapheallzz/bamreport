<?php
vc_map( 
    array(
        "name" => esc_html__( "News Post", "gunter-toolkit" ),
        "base" => "gunter_news",
        "category" => esc_html__( "Gunter", "gunter-toolkit"),
        "icon" => get_template_directory_uri() . "/assets/img/envy.png",
        "params" => array(
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__("Select Style", "gunter-toolkit"),
                "param_name"  => "style",
                "value"       => array(
                    esc_html("Style One", "gunter-toolkit")             => 1,
                    esc_html("Style Two", "gunter-toolkit")             => 2,
                ),
                "std"         => 1, // Your default value
            ),
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__("Order", "gunter-toolkit"),
                "param_name"  => "order",
                "value"       => array(
                    'ASC' => 'ASC',
                    'DESC' => 'DESC'
                ),
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Category", "gunter-toolkit" ),
                "param_name" => "cat",
                "description" => esc_html__( "Enter the category slugs separated by commas (Eg. cat1, cat2)", "gunter-toolkit" )
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Count", "gunter-toolkit" ),
                "param_name" => "count",
                "description" => esc_html__( "If you want to see all posts, type -1", "gunter-toolkit" )
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Read More Text", "gunter-toolkit" ),
                "param_name" => "btntext",
                "description" => esc_html__( "Read more text", "gunter-toolkit" )
            ),
        )
    )   
);