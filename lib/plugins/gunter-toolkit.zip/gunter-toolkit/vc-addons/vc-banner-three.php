<?php

vc_map( 
    array(
        "name" => esc_html__( "Banner Three", "gunter-toolkit" ),
        "base" => "gunter_banner_three",
        "category" => esc_html__( "Gunter", "gunter-toolkit"),
        "icon" => get_template_directory_uri() . "/assets/img/envy.png",
        "params" => array(
            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Choice Version", "gunter-toolkit" ),
                "param_name" => "section_ver",
                "std" => esc_html__( "1", "gunter-toolkit" ),
                "value" => array(
                    esc_html("Light", "gunter-toolkit")     => 1,
                    esc_html("Dark", "gunter-toolkit")      => 2,
                ),
                "description" => esc_html__( "", "gunter-toolkit" ),
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Title", "gunter-toolkit" ),
                "param_name" => "title",
                "description" => esc_html__( "banner title", "gunter-toolkit" ),
            ),
            array(
                "type" => "textarea",
                "heading" => esc_html__( "Description", "gunter-toolkit" ),
                "param_name" => "desc",
                "description" => esc_html__( "banner description", "gunter-toolkit" ),
            ),
            array(
                "type" => "attach_image",
                "heading" => esc_html__( "Banner image", "gunter-toolkit" ),
                "param_name" => "img",
            ),
            array(
                "type" => "textfield",
				"heading" => esc_html__( "Left Button", "gunter-toolkit" ),
                "param_name" => "btn1",
				"description" => esc_html__( "Button Name", "gunter-toolkit" )
            ),
			array(
                "type" => "dropdown",
                "heading" => esc_html__( "Link Type", "gunter-toolkit" ),
                "param_name" => "link_type",
                "std" => esc_html__( "1", "gunter-toolkit" ),
                "value" => array(
                    'Link to page'  => 1,
                    'External link' => 2,
                ),
                "description" => esc_html__( "", "gunter-toolkit" ),
            ),
            
            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Link Page", "gunter-toolkit" ),
                "param_name" => "link_to_page",
                "value" => gunter_toolkit_get_page_as_list(),
                "description" => esc_html__( "", "gunter-toolkit" ),
                'dependency' => array(
                    "element" => "link_type",
                    "value" => array("1"),
                )
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "External Link", "gunter-toolkit" ),
                "param_name" => "external_link",
                "description" => esc_html__( "", "gunter-toolkit" ),
                'dependency' => array(
                    "element" => "link_type",
                    "value" => array("2"),
                )
            ),

            array(
                "type" => "textfield",
				"heading" => esc_html__( "Right Button", "gunter-toolkit" ),
                "param_name" => "right_btn",
				"description" => esc_html__( "Button Name", "gunter-toolkit" )
            ),
			array(
                "type" => "dropdown",
                "heading" => esc_html__( "Link Type", "gunter-toolkit" ),
                "param_name" => "right_link_type",
                "std" => esc_html__( "1", "gunter-toolkit" ),
                "value" => array(
                    'Link to page'  => 1,
                    'External link' => 2,
                ),
                "description" => esc_html__( "", "gunter-toolkit" ),
            ),
            
            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Link Page", "gunter-toolkit" ),
                "param_name" => "right_link_to_page",
                "value" => gunter_toolkit_get_page_as_list(),
                "description" => esc_html__( "", "gunter-toolkit" ),
                'dependency' => array(
                    "element" => "right_link_type",
                    "value" => array("1"),
                )
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "External Link", "gunter-toolkit" ),
                "param_name" => "right_external_link",
                "description" => esc_html__( "", "gunter-toolkit" ),
                'dependency' => array(
                    "element" => "right_link_type",
                    "value" => array("2"),
                )
            ),
        )  
    )
);