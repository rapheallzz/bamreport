<?php

vc_map( 
    array(
        "name" => esc_html__( "Map", "gunter-toolkit" ),
        "base" => "gunter_map",
        "category" => esc_html__( "Gunter", "gunter-toolkit"),
        "icon" => get_template_directory_uri() . "/assets/img/envy.png",
        "params" => array(
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__("Select Map Version", "gunter-toolkit"),
                "param_name"  => "select",
                "value"       => array(
                    esc_html("Light", "gunter-toolkit")     => "one",
                    esc_html("Dark", "gunter-toolkit")      => "two",
                ),
                "std"         => "two", // Your default value
                "description" => esc_html__("Choose Option"),
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__("Location One Title", "gunter-toolkit"),
                "param_name"  => "location1_title",
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__("Location One Link", "gunter-toolkit"),
                "param_name"  => "location1_link",
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__("Location One Content", "gunter-toolkit"),
                "param_name"  => "location1_content",
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__("Location Two Title", "gunter-toolkit"),
                "param_name"  => "location2_title",
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__("Location One Link", "gunter-toolkit"),
                "param_name"  => "location2_link",
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__("Location Two Content", "gunter-toolkit"),
                "param_name"  => "location2_content",
            ),
        )  
    )
);
