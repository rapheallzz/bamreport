<?php

vc_map( 
    array(
        "name" => esc_html__( "Section", "gunter-toolkit" ),
        "base" => "gunter_section",
        "category" => esc_html__( "Gunter", "gunter-toolkit"),
        "icon" => get_template_directory_uri() . "/assets/img/envy.png",
        "params" => array(
            array(
                "type" => "checkbox",
                "heading" => __( "Content Align Center", "gunter-toolkit" ),
                "param_name" => "center",
                "value" => __( "", "gunter-toolkit" ),
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__("Section Top Title", "gunter-toolkit"),
                "param_name"  => "top_title",
                "description" => esc_html__("Section section top title(small title)"),
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__("Section Title", "gunter-toolkit"),
                "param_name"  => "title",
                "description" => esc_html__("Section section title(big title)"),
            ),
            array(
                "type" => "textfield",
				"heading" => esc_html__( "Section Button", "gunter-toolkit" ),
                "param_name" => "btn1",
				"description" => esc_html__( "Button Name", "gunter-toolkit" )
            ),
			array(
                "type" => "dropdown",
                "heading" => esc_html__( "Link Type", "gunter-toolkit" ),
                "param_name" => "type",
                "std" => esc_html__( "1", "gunter-toolkit" ),
                "value" => array(
                    'Link to page' => 1,
                    'External link' => 2,
                ),
                "description" => esc_html__( "", "gunter-toolkit" ),
            ),
            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Link Page", "gunter-toolkit" ),
                "param_name" => "link_to_page",
                "value" => gunter_toolkit_get_page_as_list(),
                "description" => esc_html__( "", "gunter-toolkit" ),
                'dependency' => array(
                    "element" => "type",
                    "value" => array("1"),
                )
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "External Link", "gunter-toolkit" ),
                "param_name" => "external_link",
                "description" => esc_html__( "", "gunter-toolkit" ),
                'dependency' => array(
                    "element" => "type",
                    "value" => array("2"),
                )
            ),
        )  
    )
);
