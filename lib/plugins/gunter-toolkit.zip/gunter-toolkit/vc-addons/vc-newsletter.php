<?php

vc_map( 
    array(
        "name" => esc_html__( "Newsletter", "gunter-toolkit" ),
        "base" => "gunter_newsletter",
        "category" => esc_html__( "Gunter", "gunter-toolkit"),
        "icon" => get_template_directory_uri() . "/assets/img/envy.png",
        "params" => array(
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__("Select Newsletter Version", "gunter-toolkit"),
                "param_name"  => "select",
                "value"       => array(
                esc_html("Light", "gunter-toolkit")     => "one",
                esc_html("Dark", "gunter-toolkit")      => "two",
                ),
                "std"         => "two", // Your default value
                "description" => __("Choose Version"),
            ),
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__("Select Style", "gunter-toolkit"),
                "param_name"  => "style",
                "value"       => array(
                    esc_html("Style One", "gunter-toolkit")             => 1,
                    esc_html("Style Two", "gunter-toolkit")             => 2,
                ),
                "std"         => 1, // Your default value
            ),
            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Newsletter Option", "gunter-toolkit" ),
                "param_name" => "select_mod",
                "std" => esc_html__( "2", "gunter-toolkit" ),
                "value" => array(
                    'Mailchimp' 	        => 1,
                    'Newsletter Plugin' 	=> 2,
                    
                ),
            ),
            array(
				'type'  => "textfield",
                "heading" => esc_html__( "Action URL", "gunter-toolkit" ),
                "param_name" => "action_url",
                'description' => __( 'Enter here your MailChimp action URL. <a href="https://www.docs.envytheme.com/docs/gunter-theme-documentation/tips-guides-troubleshoots/get-mailchimp-newsletter-form-action-url/" target="_blank"> How to </a>', 'gunter-toolkit' ),
                'dependency' => array(
                    "element" => "select_mod",
                    "value" => array("1"),
                )
            ),
            
            array(
                "type" => "attach_image",
                "heading" => esc_html__( "Background Image", "gunter-toolkit" ),
                "param_name" => "bg_img",
                'dependency' => array(
                    "element" => "style",
                    "value" => array("2"),
                )
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Newsletter Title", "gunter-toolkit" ),
                "param_name" => "top_title",
                'dependency' => array(
                    "element" => "style",
                    "value" => array("2"),
                )
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Newsletter Title", "gunter-toolkit" ),
                "param_name" => "title",
            ),
            array(
                "type" => "textarea",
                "heading" => esc_html__( "Newsletter Description", "gunter-toolkit" ),
                "param_name" => "description",
                'dependency' => array(
                    "element" => "style",
                    "value" => array("2"),
                )
            ),
            array(
                "type" => "textarea",
                "heading" => esc_html__( "Newsletter Placeholder", "gunter-toolkit" ),
                "param_name" => "placeholder",
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Newsletter button text", "gunter-toolkit" ),
                "param_name" => "btn_text",
                "description" => esc_html__( "Add Newsletter button text", "gunter-toolkit" )
            ),
        )
    )   
);