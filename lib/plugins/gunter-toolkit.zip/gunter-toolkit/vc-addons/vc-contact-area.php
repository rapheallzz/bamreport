<?php
vc_map( 
    array(
        "name" => esc_html__( "Contact Area", "gunter-toolkit" ),
        "base" => "gunter_contact_area",
        "category" => esc_html__( "Gunter", "gunter-toolkit"),
        "icon" => get_template_directory_uri() . "/assets/img/envy.png",
        "params" => array(
            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Choice Version", "gunter-toolkit" ),
                "param_name" => "type",
                "std" => esc_html__( "1", "gunter-toolkit" ),
                "value" => array(
                    esc_html("Light", "gunter-toolkit")     => 1,
                    esc_html("Dark", "gunter-toolkit")      => 2,
                ),
                "description" => esc_html__( "", "gunter-toolkit" ),
            ),
            array(
                "type" => "attach_image",
                "heading" => esc_html__( "Section Image", "gunter-toolkit" ),
                "param_name" => "img",

            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Location Title", "gunter-toolkit" ),
                "param_name" => "location_title",

            ),
            array(
                'type' => 'param_group',
                'param_name' => 'group_info', 
                'params' => array(
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Item Label Title", "gunter-toolkit" ),
                        "param_name" => "label_title",
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Value", "gunter-toolkit" ),
                        "param_name" => "value",
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Value Link", "gunter-toolkit" ),
                        "param_name" => "value_link",
                    )
                )
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Top Title", "gunter-toolkit" ),
                "param_name" => "top_title",
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Title", "gunter-toolkit" ),
                "param_name" => "title",

            ),
            array(
                "type" => "textarea_html",
                "heading" => esc_html__( "Contact From Shortcode", "gunter-toolkit" ),
                "param_name" => "content",

            ),
        )
    )   
);