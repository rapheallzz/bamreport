<?php

vc_map( 
    array(
        "name" => esc_html__( "Section Separator", "gunter-toolkit" ),
        "base" => "gunter_separator",
        "category" => esc_html__( "Gunter", "gunter-toolkit"),
        "icon" => get_template_directory_uri() . "/assets/img/envy.png",
        "params" => array(
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__("Select Separator Version", "gunter-toolkit"),
                "param_name"  => "select",
                "value"       => array(
                esc_html("Light", "gunter-toolkit")     => "one",
                esc_html("Dark", "gunter-toolkit")      => "two",
                ),
                "std"         => "two", // Your default value
                "description" => esc_html__("Choose Option", "gunter-toolkit"),
            ),
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__("Style", "gunter-toolkit"),
                "param_name"  => "style",
                "value"       => array(
                esc_html("One", "gunter-toolkit")     => 1,
                esc_html("Two", "gunter-toolkit")     => 2,
                ),
                "std"         => 1, // Your default value
                "description" => esc_html__("Choose Option", "gunter-toolkit"),
            ),
        )  
    )
);