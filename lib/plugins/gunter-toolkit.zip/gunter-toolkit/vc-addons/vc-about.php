<?php

vc_map( 
    array(
        "name" => esc_html__( "About US", "gunter-toolkit" ),
        "base" => "gunter_about",
        "category" => esc_html__( "Gunter", "gunter-toolkit"),
        "icon" => get_template_directory_uri() . "/assets/img/envy.png",
        "params" => array(
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__("Select Style", "gunter-toolkit"),
                "param_name"  => "select_style",
                "value"       => array(
                    esc_html__("Style One", "gunter-toolkit")       => "one",
                    esc_html__("Style Two", "gunter-toolkit")       => "two",
                ),
                "std"         => "one", // Your default value
                "description" => esc_html__("Choose Option", "gunter-toolkit"),
            ),
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__("Select About Version", "gunter-toolkit"),
                "param_name"  => "select",
                "value"       => array(
                    esc_html("Light", "gunter-toolkit")     => "one",
                    esc_html("Dark", "gunter-toolkit")      => "two",
                ),
                "std"         => "two", // Your default value
                "description" => esc_html__("Choose Option", "gunter-toolkit"),
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__("About Top Title", "gunter-toolkit"),
                "param_name"  => "top_title",
                "description" => esc_html__("About section top title(small title)"),
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__("About Title", "gunter-toolkit"),
                "param_name"  => "title",
                "description" => esc_html__("About section title(big title)"),
            ),
            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Icon Type", "gunter-toolkit" ),
                "param_name" => "icon_type",
                "std" => esc_html__( "1", "gunter-toolkit" ),
                "value" => array(
                    'Font awesome'  => 1,
                    'Flat icon'     => 2,
                ),
            ),
            array(
                "type" => "iconpicker",
                "heading" => esc_html__( "Font Awesome", "gunter-toolkit" ),
                "param_name" => "fa_icon",
                'dependency' => array(
                    "element" => "icon_type",
                    "value" => array("1"),
                )
            ),
            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Flat Icon", "gunter-toolkit" ),
                "param_name" => "flaticon",
                'dependency' => array(
                    "element" => "icon_type",
                    "value" => array("2"),
                ),
                "value" => array( 
                    'Flaticon-Quality' => 'flaticon-quality' ,
                    'Flaticon-Domain-Registration' => 'flaticon-domain-registration' ,
                    'Flaticon-Targeting' => 'flaticon-targeting' ,
                    'Flaticon-Search-Engine' => 'flaticon-search-engine' ,
                    'Flaticon-Idea' => 'flaticon-idea' ,
                    'Flaticon-Pay-Per-Click' => 'flaticon-pay-per-click' ,
                    'Flaticon-Analytics-1' => 'flaticon-analytics' ,
                    'Flaticon-Analytics-2' => 'flaticon-analytics-1' ,
                    'Flaticon-Link' => 'flaticon-link' ,
                    'Flaticon-Translation' => 'flaticon-translation' ,
                    'Flaticon-Bug' => 'flaticon-bug' ,
                    'Flaticon-Mail' => 'flaticon-mail' ,
                    'Flaticon-Magnifying-Glass' => 'flaticon-magnifying-glass' ,
                    'Flaticon-Think' => 'flaticon-think' ,
                    'Flaticon-Shout' => 'flaticon-shout' ,
                    'Flaticon-UX-Design' => 'flaticon-ux-design' ,
                    'Flaticon-Camera' => 'flaticon-camera' ,
                    'Flaticon-Data' => 'flaticon-data' ,
                    'Flaticon-Chat' => 'flaticon-chat' ,
                    'Flaticon-Stats' => 'flaticon-stats' ,
                    'Flaticon-Project' => 'flaticon-project' ,
                    'Flaticon-Quote' => 'flaticon-quote' ,
                    'Flaticon-Facebook' => 'flaticon-logo' ,
                    'Flaticon-Instagram' => 'flaticon-logo-1' ,
                    'Flaticon-Twitter' => 'flaticon-twitter' ,
                    'Flaticon-linkedin' => 'flaticon-linkedin' ,
                    'Flaticon-Down-Arrow' => 'flaticon-down-arrow' ,
                    'Flaticon-Back' => 'flaticon-back' ,
                    'Flaticon-Multimedia' => 'flaticon-multimedia' ,
                    'Flaticon-Search' => 'flaticon-search' ,
                    'Flaticon-Edit' => 'flaticon-edit' ,
                    'Flaticon-Plus' => 'flaticon-plus' ,
                    'Flaticon-Line' => 'flaticon-line' ,
                    'Flaticon-Tick' => 'flaticon-tick' ,
                    'Flaticon-Chevron' => 'flaticon-chevron' ,
                ),
            ),
            array(
                "type" => "textarea_html",
                "heading" => esc_html__( "About Section Content", "turacos-toolkit" ),
                "param_name" => "content",
            ),
            array(
                "type"        => "attach_image",
                "heading"     => esc_html__("About Section Signature Image", "gunter-toolkit"),
                "param_name"  => "img",
                "description" => esc_html__("pick an image for about signature"),
            ),
            array(
                "type"        => "attach_image",
                "heading"     => esc_html__("About Section Right Image", "gunter-toolkit"),
                "param_name"  => "img1",
                "description" => esc_html__("pick an image for about section right side"),
            ),
            array(
                "type"        => "attach_image",
                "heading"     => esc_html__("About Section Left Image", "gunter-toolkit"),
                "param_name"  => "img2",
                "description" => esc_html__("pick an image for about section left side"),
            ),
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__("Shape Image", "gunter-toolkit"),
                "param_name"  => "shape_image",
                "value"       => array(
                    esc_html("Hide", "gunter-toolkit")     => "no",
                    esc_html("Show", "gunter-toolkit")     => "yes",
                ),
                "std"         => "yes", // Your default value
            ),
            array(
                "type" => "textfield",
				"heading" => esc_html__( "Button", "gunter-toolkit" ),
                "param_name" => "btn1",
				"description" => esc_html__( "Button Name", "gunter-toolkit" )
            ),
			array(
                "type" => "dropdown",
                "heading" => esc_html__( "Link Type", "gunter-toolkit" ),
                "param_name" => "type",
                "std" => esc_html__( "1", "gunter-toolkit" ),
                "value" => array(
                    'Link to page' => 1,
                    'External link' => 2,
                ),
                "description" => esc_html__( "", "gunter-toolkit" ),
            ),
            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Link Page", "gunter-toolkit" ),
                "param_name" => "link_to_page",
                "value" => gunter_toolkit_get_page_as_list(),
                "description" => esc_html__( "", "gunter-toolkit" ),
                'dependency' => array(
                    "element" => "type",
                    "value" => array("1"),
                )
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "External Link", "gunter-toolkit" ),
                "param_name" => "external_link",
                "description" => esc_html__( "", "gunter-toolkit" ),
                'dependency' => array(
                    "element" => "type",
                    "value" => array("2"),
                )
            ),
        )  
    )
);