<?php
vc_map( 
    array(
        "name" => esc_html__( "Client Logo", "gunter-toolkit" ),
        "base" => "gunter_client_logo",
        "category" => esc_html__( "Gunter", "gunter-toolkit"),
        "icon" => get_template_directory_uri() . "/assets/img/envy.png",
        "params" => array(
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__("Style", "gunter-toolkit"),
                "param_name"  => "style",
                "value"       => array(
                        "One"     => 1,
                        "Two"     => 2,
                ),
                "std"         => 1, // Your default value
                "description" => esc_html__("Choose Option", "gunter-toolkit"),
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__("Top Title", "gunter-toolkit"),
                "param_name"  => "top_title",
                'dependency' => array(
                    "element" => "style",
                    "value" => array("2"),
                )
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__("Title", "gunter-toolkit"),
                "param_name"  => "title",
                'dependency' => array(
                    "element" => "style",
                    "value" => array("2"),
                )
            ),
            array(
                "type" => "attach_images",
                "heading" => esc_html__( "Add Client Logo", "gunter-toolkit" ),
                "param_name" => "logos",
            ),
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__("Select Client Logo Version", "gunter-toolkit"),
                "param_name"  => "select",
                "value"       => array(
                "Light"     => "one",
                "Dark"      => "two",
                ),
                "std"         => "two", // Your default value
                "description" => esc_html__("Choose Option", "gunter-toolkit"),
            ),
        )
    )   
);