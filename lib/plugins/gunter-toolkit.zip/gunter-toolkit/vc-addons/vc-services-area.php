<?php
vc_map( 
    array(
        "name" => esc_html__( "Services Area", 'gunter-toolkit' ),
        "base" => "gunter_service_area",
        "class" => "",
        "category" => esc_html__( "Gunter", 'gunter-toolkit'),
        "icon" => get_template_directory_uri() . "/assets/img/envy.png",
        "params" => array(
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Title", 'gunter-toolkit' ),
                "param_name" => "title",
            ),
            array(
                'type' => 'param_group',
                'param_name' => 'items', 
                'params' => array(
                    array(
                        "type"        => "dropdown",
                        "heading"     => esc_html__("Icon Type", "gunter-toolkit"),
                        "param_name"  => "icon_type",
                        "value"       => array(
                            __( 'Font Awesome', 'gunter-toolkit' )                      => 'font-awesome',
                            __( 'Uikit Icon Class Name', 'gunter-toolkit' )             => 'uikit',
                            __( 'Icon Class Name', 'gunter-toolkit' )                   => 'icon_class',
                        ),
                        "std"         => "font-awesome", // Your default value
                        "description" => esc_html__("Choose Option", "gunter-toolkit"), 
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Uikit Icon Class Name", "gunter-toolkit" ),
                        "param_name" => "uikit_icon",
                        'dependency' => array(
                            "element" => "icon_type",
                            "value" => array("uikit"),
                        )
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Icon Class Name", "gunter-toolkit" ),
                        "param_name" => "icon_class_name",
                        'dependency' => array(
                            "element" => "icon_type",
                            "value" => array("icon_class"),
                        )
                    ),
                    array(
                        "type" => "iconpicker",
                        "heading" => esc_html__( "Font Awesome Icon", "gunter-toolkit" ),
                        "param_name" => "fa_icon",
                        'dependency' => array(
                            "element" => "icon_type",
                            "value" => array("font-awesome"),
                        )
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Title", "gunter-toolkit" ),
                        "param_name" => "title",
                    ),
                    array(
                        "type" => "textarea",
                        "heading" => esc_html__( "Description", "gunter-toolkit" ),
                        "param_name" => "description",
                    )
                )
            ),
        )
    )   
);