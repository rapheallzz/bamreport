<?php
vc_map( 
    array(
        "name" => esc_html__( "Why Choose Us", "gunter-toolkit" ),
        "base" => "gunter_why_choose_us",
        "category" => esc_html__( "Gunter", "gunter-toolkit"),
        "icon" => get_template_directory_uri() . "/assets/img/envy.png",
        "params" => array(
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Top Title", "gunter-toolkit" ),
                "param_name" => "top_title",
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Title", "gunter-toolkit" ),
                "param_name" => "title",
            ),
            array(
                "type" => "attach_image",
                "heading" => esc_html__( "Section Image", "gunter-toolkit" ),
                "param_name" => "img",
            ),
            array(
                'type' => 'param_group',
                'param_name' => 'group_items', 
                'params' => array(
                    array(
                        "type"        => "dropdown",
                        "heading"     => esc_html__("Icon Type", "gunter-toolkit"),
                        "param_name"  => "icon_type",
                        "value"       => array(
                            __( 'Font Awesome', 'gunter-toolkit' )                   => 'font-awesome',
                            __( 'Flat Icon', 'gunter-toolkit' )          => 'flaticon',
                        ),
                        "std"         => "font-awesome", // Your default value
                        "description" => esc_html__("Choose Option", "gunter-toolkit"),
                    ),
                    array(
                        "type" => "dropdown",
                        "heading" => esc_html__( "Flaticon Icon", "gunter-toolkit" ),
                        "param_name" => "flat-icon",
                        "value"       => array(
                            'flaticon-domain-registration' => 'flaticon-domain-registration',
                            'flaticon-search-engine' => 'flaticon-search-engine',
                            'flaticon-idea' => 'flaticon-idea',
                            'flaticon-pay-per-click' => 'flaticon-pay-per-click',
                            'flaticon-analytics-1' => 'flaticon-analytics-1',
                            'flaticon-analytics-2' => 'flaticon-analytics-2',
                            'flaticon-link' => 'flaticon-link',
                            'flaticon-translation' => 'flaticon-translation',
                            'flaticon-bug' => 'flaticon-bug',
                            'flaticon-mail' => 'flaticon-mail',
                            'flaticon-magnifying-glass' => 'flaticon-magnifying-glass',
                            'flaticon-think' => 'flaticon-think',
                            'flaticon-plan' => 'flaticon-plan',
                            'flaticon-shout' => 'flaticon-shout',
                            'flaticon-ux-design' => 'flaticon-ux-design',
                            'flaticon-camera' => 'flaticon-camera',
                            'flaticon-data' => 'flaticon-data',
                            'flaticon-chat' => 'flaticon-chat',
                            'flaticon-stats' => 'flaticon-stats',
                            'flaticon-project' => 'flaticon-project',
                            'flaticon-quote' => 'flaticon-quote',
                            'flaticon-facebook' => 'flaticon-facebook',
                            'flaticon-instagram' => 'flaticon-instagram',
                            'flaticon-twitter' => 'flaticon-twitter',
                            'flaticon-linkedin' => 'flaticon-linkedin',
                            'flaticon-down-arrow' => 'flaticon-down-arrow',
                            'flaticon-back' => 'flaticon-back',
                            'flaticon-multimedia' => 'flaticon-multimedia',
                            'flaticon-search' => 'flaticon-search',
                            'flaticon-edit' => 'flaticon-edit',
                            'flaticon-plus' => 'flaticon-plus',
                            'flaticon-line' => 'flaticon-line',
                            'flaticon-tick' => 'flaticon-tick',
                            'flaticon-chevron' => 'flaticon-chevron',
                        ),
                        'dependency' => array(
                            "element" => "icon_type",
                            "value" => array("flaticon"),
                        )
                    ),
                    array(
                        "type" => "iconpicker",
                        "heading" => esc_html__( "Font Awesome Icon", "gunter-toolkit" ),
                        "param_name" => "fa_icon",
                        'dependency' => array(
                            "element" => "icon_type",
                            "value" => array("font-awesome"),
                        )
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Title", "gunter-toolkit" ),
                        "param_name" => "title",
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Content", "gunter-toolkit" ),
                        "param_name" => "content",
                    )
                )
            ),
        )
    )   
);