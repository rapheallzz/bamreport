<?php

vc_map( 
    array(
        "name" => esc_html__( "Testimonials Three", "gunter-toolkit" ),
        "base" => "gunter_testimonials_three",
        "category" => esc_html__( "Gunter", "gunter-toolkit"),
        "icon" => get_template_directory_uri() . "/assets/img/envy.png",
        "params" => array(
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__("Select Testimonials Version", "gunter-toolkit"),
                "param_name"  => "select",
                "value"       => array(
                esc_html("Light", "gunter-toolkit")     => "one",
                esc_html("Dark", "gunter-toolkit")      => "two",
                ),
                "std"         => "two", // default value
                "description" => esc_html__("Choose Option", "gunter-toolkit"),
            ),
            array(
                "type"        => "attach_image",
                "heading"     => esc_html__("Shape Image", "gunter-toolkit"),
                "param_name"  => "shape_image",
            ),

            // Testimonial Group
            array(
                'type' => 'param_group',
                'param_name' => 'group_testimonials', 
                'params' => array(
                    array(
                        "type" => "textarea",
                        "heading" => esc_html__( "Feedback", "gunter-toolkit" ),
                        "param_name" => "feed",
                    ),
                    array(
                        "type" => "attach_image",
                        "heading" => esc_html__( "Image", "gunter-toolkit" ),
                        "param_name" => "image",
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Name", "gunter-toolkit" ),
                        "param_name" => "name",
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Designation", "gunter-toolkit" ),
                        "param_name" => "designation",
                    ),
                )
            ),
        )  
    )
);
