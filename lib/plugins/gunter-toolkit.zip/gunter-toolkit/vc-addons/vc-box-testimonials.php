<?php
vc_map( 
    array(
        "name" => esc_html__( "Box Testimonials", "gunter-toolkit" ),
        "base" => "gunter_box_testimonials",
        "category" => esc_html__( "Gunter", "gunter-toolkit"),
        "icon" => get_template_directory_uri() . "/assets/img/envy.png",
        "params" => array(
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__("Select Style", "gunter-toolkit"),
                "param_name"  => "style",
                "value"       => array(
                    esc_html("Style One", "gunter-toolkit")     => 1,
                    esc_html("Style Two", "gunter-toolkit")     => 2,
                ),
            ),

            array(
                "type"        => "attach_image",
                "heading"     => esc_html__("Client Image", "gunter-toolkit"),
                "param_name"  => "img",
            ),
     
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Name", "gunter-toolkit" ),
                "param_name" => "name",
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Designation", "gunter-toolkit" ),
                "param_name" => "designation",
            ),
            array(
                "type" => "textarea",
                "heading" => esc_html__( "Feedback", "gunter-toolkit" ),
                "param_name" => "feed",
            ),
        )  
    )
);
