<?php

vc_map( 
    array(
        "name" => esc_html__( "Feature", "gunter-toolkit" ),
        "base" => "gunter_feature",
        "category" => esc_html__( "Gunter", "gunter-toolkit"),
        "icon" => get_template_directory_uri() . "/assets/img/envy.png",
        "params" => array(
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__("Select Feature Card Position", "gunter-toolkit"),
                "param_name"  => "select",
                "value"       => array(
                    esc_html("Active", "gunter-toolkit")     => "one",
                    esc_html("Normal", "gunter-toolkit")     => "two",
                ),
                "std"         => "two", // Your default value
                "description" => esc_html__("Choose Option", "gunter-toolkit"),
            ),
            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Icon Type", "gunter-toolkit" ),
                "param_name" => "type",
                "std" => esc_html__( "1", "gunter-toolkit" ),
                "value" => array(
                    esc_html('Font awesome', 'gunter-toolkit')     => 1,
                    esc_html('Flat icon', 'gunter-toolkit')      => 2,
                ),
            ),
            array(
                "type" => "iconpicker",
                "heading" => esc_html__( "Font Awesome", "gunter-toolkit" ),
                "param_name" => "fa_icon",
                'dependency' => array(
                    "element" => "type",
                    "value" => array("1"),
                )
            ),
            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Flat Icon", "gunter-toolkit" ),
                "param_name" => "flaticon",
                'dependency' => array(
                    "element" => "type",
                    "value" => array("2"),
                ),
                "value" => array( 
                    'Flaticon-Quality' => 'flaticon-quality' ,
                    'Flaticon-Domain-Registration' => 'flaticon-domain-registration' ,
                    'Flaticon-Targeting' => 'flaticon-targeting' ,
                    'Flaticon-Search-Engine' => 'flaticon-search-engine' ,
                    'Flaticon-Idea' => 'flaticon-idea' ,
                    'Flaticon-Pay-Per-Click' => 'flaticon-pay-per-click' ,
                    'Flaticon-Analytics-1' => 'flaticon-analytics' ,
                    'Flaticon-Analytics-2' => 'flaticon-analytics-1' ,
                    'Flaticon-Link' => 'flaticon-link' ,
                    'Flaticon-Translation' => 'flaticon-translation' ,
                    'Flaticon-Bug' => 'flaticon-bug' ,
                    'Flaticon-Mail' => 'flaticon-mail' ,
                    'Flaticon-Magnifying-Glass' => 'flaticon-magnifying-glass' ,
                    'Flaticon-Think' => 'flaticon-think' ,
                    'Flaticon-Shout' => 'flaticon-shout' ,
                    'Flaticon-UX-Design' => 'flaticon-ux-design' ,
                    'Flaticon-Camera' => 'flaticon-camera' ,
                    'Flaticon-Data' => 'flaticon-data' ,
                    'Flaticon-Chat' => 'flaticon-chat' ,
                    'Flaticon-Stats' => 'flaticon-stats' ,
                    'Flaticon-Project' => 'flaticon-project' ,
                    'Flaticon-Quote' => 'flaticon-quote' ,
                    'Flaticon-Facebook' => 'flaticon-logo' ,
                    'Flaticon-Instagram' => 'flaticon-logo-1' ,
                    'Flaticon-Twitter' => 'flaticon-twitter' ,
                    'Flaticon-linkedin' => 'flaticon-linkedin' ,
                    'Flaticon-Down-Arrow' => 'flaticon-down-arrow' ,
                    'Flaticon-Back' => 'flaticon-back' ,
                    'Flaticon-Multimedia' => 'flaticon-multimedia' ,
                    'Flaticon-Search' => 'flaticon-search' ,
                    'Flaticon-Edit' => 'flaticon-edit' ,
                    'Flaticon-Plus' => 'flaticon-plus' ,
                    'Flaticon-Line' => 'flaticon-line' ,
                    'Flaticon-Tick' => 'flaticon-tick' ,
                    'Flaticon-Chevron' => 'flaticon-chevron' ,
                ),
            ),
			array(
                "type" => "textfield",
                "heading" => esc_html__( "Feature Title", "gunter-toolkit" ),
                "param_name" => "title",
                "description" => esc_html__( "Feature Title", "gunter-toolkit" ),
            ),
            array(
                "type" => "textarea",
                "heading" => esc_html__( "Content", "gunter-toolkit" ),
                "param_name" => "desc",
                "description" => esc_html__( "Feature Content", "gunter-toolkit" ),
            ),
            array(
                "type" => "checkbox",
                "heading" => esc_html__( "Hide Hover Shape Images", "gunter-toolkit" ),
                "param_name" => "shape",
            ),
        )  
    )
);