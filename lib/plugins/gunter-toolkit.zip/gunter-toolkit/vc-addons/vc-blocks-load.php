<?php
if(!defined('ABSPATH')){
    die('-1');
}
// Class Started
class gunterVCExtendAddonClass{
    function __construct(){
        // We safely integrate with VC with this hook
        add_action('init', array($this, 'gunterIntegrateWithVC'));
    }
    public function gunterIntegrateWithVC(){

        // Check if visual composer is not installed 
        if(! defined('WPB_VC_VERSION')){
            add_action('admin_notices', array($this, 'gunterShowVcVersionNotice'));
            return;
        }  
        // VC Addons
        include GUNTER_ACC_PATH . '/vc-addons/vc-banner.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-banner-two.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-banner-three.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-banner-slider.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-banner-lead.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-section.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-feature.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-separator.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-about.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-services.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-project.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-testimonials.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-testimonials-two.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-box-testimonials.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-client-logo.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-team.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-newsletter.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-news.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-map.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-work-process.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-funfacts.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-contact-area.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-why-choose-us.php';

        include GUNTER_ACC_PATH . '/vc-addons/vc-corporate-banner.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-services-area.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-testimonials-three.php';
        include GUNTER_ACC_PATH . '/vc-addons/vc-pricing-plan.php';
    }
	
    // Show VC Version
    public function gunterShowVcVersionNotice(){
        $theme_data = wp_get_theme();
        echo '
        <div class="notice notice-warning">
            <p>' .sprintf(__('<strong>%s</strong> recommends <strong>
                <a href="'.site_url().' /wp-admin/themes.php?page=tgmpa-install-plugins" target="_blank">Visual Composer</a></strong> Plugin to be installed & activate on your site.', 'gunter-toolkit'), $theme_data->get('Name')).'</p>
       </div>';
    }
}
new gunterVCExtendAddonClass();