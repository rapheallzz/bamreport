<?php
vc_map( 
    array(
        "name" => esc_html__( "Team", "gunter-toolkit" ),
        "base" => "gunter_team",
        "category" => esc_html__( "Gunter", "gunter-toolkit"),
        "icon" => get_template_directory_uri() . "/assets/img/envy.png",
        "params" => array(
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__("Select Style", "gunter-toolkit"),
                "param_name"  => "style",
                "value"       => array(
                    esc_html("Slider Style", "gunter-toolkit")     => 1,
                    esc_html("Box Two", "gunter-toolkit")     => 2,
                    esc_html("Box Three", "gunter-toolkit")     => 3,
                ),
            ),
            array(
                'type' => 'param_group',
                'param_name' => 'group_teams', 
                'params' => array(
                    array(
                        "type" => "attach_image",
                        "heading" => esc_html__( "Team Member Image", "gunter-toolkit" ),
                        "param_name" => "img",
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Name", "gunter-toolkit" ),
                        "param_name" => "name",
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Designation", "gunter-toolkit" ),
                        "param_name" => "designation",
                    ),
                    array(
                        'type' => 'param_group',
                        'param_name' => 'group_social', 
                        'params' => array(

                            array(
                                "type" => "textfield",
                                "heading" => esc_html__( "Social Link", "gunter-toolkit" ),
                                "param_name" => "link",
                            ),
                            array(
                                "type" => "iconpicker",
                                "heading" => esc_html__( "Social Icon", "gunter-toolkit" ),
                                "param_name" => "socialicon",
                            ),

                        ),
                    )
                )
            ),
        )
    )   
);