<?php

vc_map( 
    array(
        "name" => esc_html__( "Services", "gunter-toolkit" ),
        "base" => "gunter_services",
        "category" => esc_html__( "Gunter", "gunter-toolkit"),
        "icon" => get_template_directory_uri() . "/assets/img/envy.png",
        "params" => array(
            array(
                "type"        => "textfield",
                "heading"     => esc_html__("Count", "gunter-toolkit"),
                "param_name"  => "count",
                "description" => esc_html__("Select services count. If you want to show unlimited items, type -1."),
            ),
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__("Select Style", "gunter-toolkit"),
                "param_name"  => "style",
                "value"       => array(
                    esc_html("Style One", "gunter-toolkit")     => 1,
                    esc_html("Style Two", "gunter-toolkit")     => 2,
                    esc_html("Style Three", "gunter-toolkit")   => 3,
                    esc_html("Style Four", "gunter-toolkit")    => 4,
                    esc_html("Style Five", "gunter-toolkit")    => 5,
                    esc_html("Style Six", "gunter-toolkit")    => 6,
                    esc_html("Style Seven", "gunter-toolkit")    => 7,
                ),
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__("Top Title", "gunter-toolkit"),
                "param_name"  => "top_title",
                'dependency' => array(
                    "element" => "style",
                    "value" => array("6","7"),
                )
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__("Title", "gunter-toolkit"),
                "param_name"  => "title",
                'dependency' => array(
                    "element" => "style",
                    "value" => array("6","7"),
                )
            ),
            array(
                "type"        => "attach_image",
                "heading"     => esc_html__("Section Image", "gunter-toolkit"),
                "param_name"  => "img",
                'dependency' => array(
                    "element" => "style",
                    "value" => array("6","7"),
                )
            ),
            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Link Show / Hide?", "gunter-toolkit" ),
                "param_name" => "link_type",
                "std" => esc_html__( "1", "gunter-toolkit" ),
                "value" => array(
                    'Show'                  => 'show',
                    'Hide'                  => 'hide',
                ),
                'dependency' => array(
                    "element" => "style",
                    "value" => array("1"),
                )
            ),
            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Select Category", "gunter-toolkit" ),
                "param_name" => "cat_name",
                "value" => gunter_toolkit_get_services_as_list(),
                "description" => esc_html__( "", "gunter-toolkit" ),
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__("Read More Text", "gunter-toolkit"),
                "param_name"  => "read_more",
                'dependency' => array(
                    "element" => "style",
                    "value" => array("2"),
                )
            ),
            array(
                "type" => "checkbox",
                "heading" => esc_html__( "Hide Post Pagination", "gunter-toolkit" ),
                "param_name" => "pagination",
                "description" => esc_html__( "Pagination Not Working On Home Page!!", "gunter-toolkit" ),
                'dependency' => array(
                    "element" => "style",
                    "value" => array("2"),
                )
            ),
            array(
                "type" => "checkbox",
                "heading" => esc_html__( "Hide Hover Animation Images", "gunter-toolkit" ),
                "param_name" => "animation",
                'dependency' => array(
                    "element" => "style",
                    "value" => array("2"),
                )
            ),
        )  
    )
);
