<?php

vc_map( 
    array(
        "name" => esc_html__( "Slider Testimonials", "gunter-toolkit" ),
        "base" => "gunter_testimonials",
        "category" => esc_html__( "Gunter", "gunter-toolkit"),
        "icon" => get_template_directory_uri() . "/assets/img/envy.png",
        "params" => array(
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__("Select Testimonials Version", "gunter-toolkit"),
                "param_name"  => "select",
                "value"       => array(
                esc_html("Light", "gunter-toolkit")     => "one",
                esc_html("Dark", "gunter-toolkit")      => "two",
                ),
                "std"         => "two", // default value
                "description" => esc_html__("Choose Option", "gunter-toolkit"),
            ),
            array(
                "type"        => "attach_image",
                "heading"     => esc_html__("Testimonial Section Image", "gunter-toolkit"),
                "param_name"  => "img",
                "description" => esc_html__("choice testimonial section image(585x597)"),
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__("Testimonial Section Top Title", "gunter-toolkit"),
                "param_name"  => "top_title",
                "description" => esc_html__("Testimonial Section section top title(small title)"),
            ),
            array(
                "type"        => "textfield",
                "heading"     => esc_html__("Testimonial Section Title", "gunter-toolkit"),
                "param_name"  => "title",
                "description" => esc_html__("Testimonial Section section title(big title)"),
            ),
            array(
                "type" => "textfield",
				"heading" => esc_html__( "Video Button", "gunter-toolkit" ),
                "param_name" => "video_btn",
				"description" => esc_html__( "Testimonial Video Button Name", "gunter-toolkit" )
            ),
            array(
                "type" => "textfield",
				"heading" => esc_html__( "Video Button Link", "gunter-toolkit" ),
                "param_name" => "video_link",
				"description" => esc_html__( "Testimonial Video Button Link", "gunter-toolkit" )
            ),

            //Testimonial Group
            array(
                'type' => 'param_group',
                'param_name' => 'group_testimonials', 
                'params' => array(
                    array(
                        "type" => "textarea",
                        "heading" => esc_html__( "Feedback", "gunter-toolkit" ),
                        "param_name" => "feed",
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Name", "gunter-toolkit" ),
                        "param_name" => "name",
                    ),
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Designation", "gunter-toolkit" ),
                        "param_name" => "designation",
                    ),
                )
            ),
        )  
    )
);
