<?php
vc_map( 
    array(
        "name" => esc_html__( "Project", "gunter-toolkit" ),
        "base" => "gunter_project",
        "class" => "",
        "category" => esc_html__( "Gunter", "gunter-toolkit"),
        "icon" => get_template_directory_uri() . "/assets/img/envy.png",
        "params" => array(
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Count", "gunter-toolkit" ),
                "param_name" => "count",
                "description" => esc_html__( "Select project count. If you want to show unlimited items, type -1. ", "gunter-toolkit" )

            ),
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__("Select Style", "gunter-toolkit"),
                "param_name"  => "style",
                "value"       => array(
                    esc_html("Slider Style", "gunter-toolkit")          => 1,
                    esc_html("Box Style One", "gunter-toolkit")         => 2,
                    esc_html("Box Style Two", "gunter-toolkit")         => 3,
                    esc_html("Style Three", "gunter-toolkit")           => 4,
                ),
            ),

            array(
                "type"        => "dropdown",
                "heading"     => esc_html__("Order", "gunter-toolkit"),
                "param_name"  => "order",
                "value"       => array(
                    'ASC' => 'ASC',
                    'DESC' => 'DESC'
                ),
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Category", "gunter-toolkit" ),
                "param_name" => "cat",
                "description" => esc_html__( "Enter the category slugs separated by commas (Eg. cat1, cat2)", "gunter-toolkit" )
            ),
            array(
                "type" => "checkbox",
                "heading" => esc_html__( "Hide Post Pagination", "gunter-toolkit" ),
                "param_name" => "pagination",
                "description" => esc_html__( "Pagination Not Working On Home Page!!", "gunter-toolkit" ),
                'dependency' => array(
                    "element" => "style",
                    "value" => array("2"),
                )
            ),
            array(
                "type"        => "dropdown",
                "heading"     => esc_html__("Select Project Version", "gunter-toolkit"),
                "param_name"  => "select",
                "value"       => array(
                esc_html("Light", "gunter-toolkit")     => "one",
                esc_html("Dark", "gunter-toolkit")      => "two",
                ),
                "std"         => "two", // Your default value
                "description" => esc_html__("Choose Option", "gunter-toolkit"),
                'dependency' => array(
                    "element" => "style",
                    "value" => array("1"),
                )
            ),
            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Link Show / Hide?", "gunter-toolkit" ),
                "param_name" => "link_type",
                "std" => esc_html__( "1", "gunter-toolkit" ),
                "value" => array(
                    'Show'                  => 'show',
                    'Hide'                  => 'hide',
                ),
            ),
        )
    )   
);