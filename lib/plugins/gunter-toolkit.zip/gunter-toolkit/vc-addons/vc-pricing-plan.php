<?php
vc_map( 
    array(
        "name" => esc_html__( "Pricing Plan", 'gunter-toolkit' ),
        "base" => "gunter_pricing_plan",
        "class" => "",
        "category" => esc_html__( "Gunter", 'gunter-toolkit'),
        "icon" => get_template_directory_uri() . "/assets/img/envy.png",
        "params" => array(
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Package Name", 'gunter-toolkit' ),
                "param_name" => "name",
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Package Icon Class Name", 'gunter-toolkit' ),
                "param_name" => "icon",
            ),
            array(
                "type" => "colorpicker",
                "heading" => esc_html__( "Package Icon Color", 'gunter-toolkit' ),
                "param_name" => "icon_color",
            ),
            array(
                "type" => "attach_image",
                "heading" => esc_html__( "Package Icon Shape Image", 'gunter-toolkit' ),
                "param_name" => "shape_image",
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Package Price", 'gunter-toolkit' ),
                "param_name" => "price",
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Package Duration", 'gunter-toolkit' ),
                "param_name" => "duration",
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "Button Name", 'gunter-toolkit' ),
                "param_name" => "btnname",
            ),

            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Button Link Type", 'gunter-toolkit' ),
                "param_name" => "type",
                "std" => esc_html__( "1", 'gunter-toolkit' ),
                "value" => array(
                    'Link to page' => 1,
                    'External link' => 2,
                ),
            ),
            array(
                "type" => "dropdown",
                "heading" => esc_html__( "Link Page", 'gunter-toolkit' ),
                "param_name" => "link_to_page",
                "value" => gunter_toolkit_get_page_as_list(),
                'dependency' => array(
                    "element" => "type",
                    "value" => array("1"),
                )
            ),
            array(
                "type" => "textfield",
                "heading" => esc_html__( "External Link", 'gunter-toolkit' ),
                "param_name" => "external_link",
                'dependency' => array(
                    "element" => "type",
                    "value" => array("2"),
                )
            ),

            array(
                "type" => "colorpicker",
                "heading" => esc_html__( "Package Button Background Color", 'gunter-toolkit' ),
                "param_name" => "button_bg",
            ),

            array(
                'type' => 'param_group',
                'param_name' => 'group_package_features', 
                'params' => array(
                    array(
                        "type" => "textfield",
                        "heading" => esc_html__( "Package Feature Name", 'gunter-toolkit' ),
                        "param_name" => "feature",
                    ),
                )
            ),
        )
    )   
);